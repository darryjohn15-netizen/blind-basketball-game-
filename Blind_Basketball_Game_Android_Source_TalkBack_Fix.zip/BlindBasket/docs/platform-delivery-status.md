# Platform delivery status — Blind Basketball Game

**Source version:** 1.0.2 · **Built:** 2026-10-30 · **Engine:** Godot 4.7.2

## Native downloads

- **Windows single-file installer:** `dist/native/Blind_Basketball_Game_Windows_Setup_1.0.2.exe` — 40,500,657 bytes (40.50 MB decimal). It is a per-user NSIS self-extracting setup for the 64-bit standalone game; no administrator rights are required. The installed embedded-data game EXE is 131,576,824 bytes, so the under-90-MB target is met for the download, not for extracted disk usage. The installer is unsigned and may trigger Windows SmartScreen's unknown-publisher warning.
- **Android single APK:** `dist/native/Blind Basketball Game.apk` — 81,610,386 bytes (81.61 MB decimal). The manifest reports app name **Blind Basketball Game**, package `com.darryjohn.blindbasketballgame`, version 1.0.2, minimum API 24, target API 36, and ARM64 + ARM32 libraries. It is configured for portrait orientation. `aapt` identity inspection and `apksigner verify` succeeded. The APK is signed with a sandbox-generated debug certificate, not a creator-owned Play Store/release key.

Both download files are below the requested 90 MB limit. SHA-256:

- Windows setup: `8c1070dca2e5eb41747b9b03fd5938a3300ab7a656780aa214ee0546922a1c67`
- Android APK: `e6940e9695891b546db42d61bba2ee15340273bcaa10a829d518e8edab6a5dce`

## Verification actually performed

- Dedicated Godot basketball test suite: `godot --headless --path . --script res://tests/basketball_checks.gd` — **PASS: 70 checks**.
- Android export completed and APK signing verification succeeded with APK Signature Scheme v2/v3; both `arm64-v8a` and `armeabi-v7a` are included.
- Windows export is an x86-64 PE executable with embedded Godot PCK data. The setup output is a PE32 NSIS self-extracting installer.
- `npm run check` returned `ok: true`; its Godot font checks reported zero errors and zero missing glyphs. The WebDev visual-coverage audit remains **incomplete: 0/5 roles fulfilled**, with all five approved roles marked unresolved and `visualQuality: requires_agent_review`. The art assets are in the project and the used runtime sprites are registered, but this audit was not accepted as complete; changing group labels alone did not clear it.
- No Windows machine or physical Android device/emulator was available for an install-and-launch test. The packaged files and signatures were inspected, but target-device runtime behavior remains unverified.

## Accessibility and device testing limits

Android portrait layout, 64-unit minimum controls, semantic names/descriptions, and explicit row-major focus links are present in source. Windows `Ctrl+H`, keyboard controls and spoken status (`V`) are implemented. **NVDA, Narrator and TalkBack have not been tested on physical target devices.** The project must not claim compatibility with every screen reader until device-level acceptance testing confirms swipe order, focus, activation, speech and touch behavior.

## Game, audio and credits

The source test suite covers 2-on-2, 3-on-3 and 5-on-5 flows, saves, cross-league setup and user-selectable starters. The app preserves **Darry John Sarmiento** and the About/community URL `https://t.me/gwapokobay1639`. Checked on 2026-10-30, the public Telegram page resolved as “File for visually impaired official telegram channel” and displayed 1,312 subscribers; this confirms the page exists, not who operates it. The same dated, qualified check is shown in About. The named synthetic cast is Abby (courtside reporter), Adam, Michael and Andrei (commentators), and Lisa and Jamie (halftime analysts); no identifiable person's voice is cloned.

## Roster research and historical feature

The prior broad current-roster workflow was cancelled/stopped before all teams were covered. The source contains two retained research records: Dallas Mavericks (18 players, complete for 2026–27 as of 2026-10-25) and Barangay Ginebra San Miguel (17 player cards, explicitly incomplete because the official page did not identify its season), plus the user's supplied TNT and Philippines 2025 FIBA Asia Cup data. Other NBA, PBA, MPBL, PBL and current FIBA Asia club rosters are not represented as verified. The user's requested one representative championship lineup per decade has not been researched or implemented. No new research was launched after the user's instruction to cancel research.

## Sources and build notes

Separate Windows and Android source archives are prepared alongside the native downloads. Their source includes the Godot project, platform export settings, guides and original user-supplied source references; it excludes editor caches, native outputs, SDKs and signing keys. Build steps and signing caveats are in `WINDOWS_SOURCE_GUIDE.md` and `ANDROID_SOURCE_GUIDE.md`; toolchain facts are in `native-toolchain-notes.md`.

The Android export printed a non-blocking notice that Godot used Build-Tools 35.0.1 for Target SDK 36. Export and signature checks completed successfully. The debug signing key is stored outside the project and is not present in either source archive.

The current canonical managed checkpoint status must be read back from the WebDev release flow; local ZIPs and binaries are not proof of a saved remote checkpoint.
