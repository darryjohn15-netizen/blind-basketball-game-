# Windows install and source guide

## Ready-to-use Windows download

Download and run `dist/native/Blind_Basketball_Game_Windows_Setup_1.0.2.exe` (40,500,657 bytes / 40.50 MB). The installer is a single self-extracting EXE, installs per-user without administrator access, and can create Start Menu/Desktop shortcuts. The installed game is a standalone 64-bit Windows executable. The installer is not digitally signed, so Windows SmartScreen may show an unknown-publisher warning. Verify the SHA-256 before opening it:

`8c1070dca2e5eb41747b9b03fd5938a3300ab7a656780aa214ee0546922a1c67`

The installer download is below 90 MB. Its extracted game executable is 131,576,824 bytes, so allow at least 132 MB of installed space.

## Build the Windows release from source

1. Install Godot **4.7.2** for Windows, including the matching Windows Desktop export template, and open the extracted `BlindBasket` folder (`project.godot`).
2. Export the embedded-data game executable using the `Windows Desktop` preset, either from Godot's Export dialog or with:

   ```sh
   godot --headless --path . --export-release "Windows Desktop" "dist/native/Blind Basketball Game.exe"
   ```

3. To recreate the one-file installer, install NSIS 3 and run `makensis -V2 windows_installer.nsi` from the project root. The script expects the Godot EXE at `dist/native/Blind Basketball Game.exe`.

## Controls and accessibility

Use **WASD / arrow keys** to move, **Shift** to sprint, **Space** to pass, **Enter / J** to shoot, **F** to defend, **Tab** to switch player, **T** for timeout, **B** for substitution, **V** to speak match status, **Esc** to pause, and **Ctrl+H** to open help. Menus support keyboard focus and Enter/Space activation.

The UI includes semantic control labels and explicit focus order. It has **not** been tested on a physical Windows PC with NVDA or Narrator, so universal screen-reader compatibility is not claimed.

## Project notes

The game is offline. Local career/profile data and match saves are stored in the user's Godot data directory. Creator credit **Darry John Sarmiento** and the About/community link `https://t.me/gwapokobay1639` remain in the game. See `platform-delivery-status.md` for build and validation limits.
