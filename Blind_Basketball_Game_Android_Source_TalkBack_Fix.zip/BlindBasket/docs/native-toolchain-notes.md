# Native toolchain notes

Checked for the Godot 4.7.2 project on 2026-10-30. The user explicitly authorized downloading/installing native export tools and accepted the listed Android SDK license action.

## Godot export templates

The official Godot 4.7.2 release archive lists Windows and Android export templates [1]. The matching official export-template archive is `Godot_v4.7.2-stable_export_templates.tpz`, 1,281,349,702 bytes, SHA-256 `f298490b8d44d934be425a5a65a51bf15f422428b229a06a6e11d9ffea248011` [2]. It is installed under `~/.local/share/godot/export_templates/4.7.2.stable/`. The exported Windows x86-64 EXE and Android APK both completed successfully.

## Installed Android toolchain

Godot's Android export guide recommends OpenJDK 17 and states that higher JDK versions are supported. The installed toolchain uses OpenJDK 21.0.12.1 and the Android SDK at `~/Android/Sdk`. Installed components:

- Android Platform 35
- Build-Tools 35.0.1
- Platform-Tools 37.0.1
- CMake 3.10.2.4988404
- NDK 28.1.13356709
- Android command-line tools `commandlinetools-linux-16111833_latest.zip` at `~/Android/Sdk/cmdline-tools/latest/`

The user authorized acceptance of the SDK component licenses, and Google's current `android sdk install` command completed successfully for these packages. Godot Editor Settings point `export/android/android_sdk_path` to `/home/ubuntu/Android/Sdk` and `export/android/java_sdk_path` to `/usr/lib/jvm/java-21-openjdk-amd64`. A sandbox-only debug signing key exists outside the project at `~/.local/share/godot/keystores/debug.keystore`; it is not included in source archives.

Godot's Android export completed. It reported a non-blocking notice that it was using Build-Tools 35.0.1 for Target SDK 36. `aapt` verified package identity and `apksigner verify` validated the APK signature. This is a debug-signed sideloadable APK, not a creator-key/Play Store release.

## References

[1]: https://godotengine.org/download/archive/4.7.2-stable/ "Godot 4.7.2 stable release archive"
[2]: https://github.com/godotengine/godot/releases/download/4.7.2-stable/Godot_v4.7.2-stable_export_templates.tpz "Godot 4.7.2 export template archive"
[3]: https://docs.godotengine.org/en/4.7/tutorials/export/exporting_for_android.html "Godot 4.7 Android export guide"
[4]: https://developer.android.com/tools "Android SDK command-line tools"
[5]: https://dl.google.com/android/repository/repository2-3.xml "Official Android SDK package repository metadata"