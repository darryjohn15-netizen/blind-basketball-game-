# TalkBack bridge (Android)

## Problem
Godot renders every Control itself. On Android the game is one surface, so TalkBack found no buttons to read or focus even though each Control had `accessibility_name`/`accessibility_description` set.

## Fix
`autoload/android_accessibility_bridge.gd` (autoload `AndroidA11y`, registered in `project.godot`) runs only on Android and only while touch exploration is enabled. About four times a second it:

1. Walks the visible Control tree and builds a list of readable items: buttons, toggles, option selectors, sliders, text fields, labels, the progress bar and the court view.
2. Sorts them in reading order: top to bottom by row, left to right inside a row.
3. Mirrors them as invisible native views over the game surface (Button, CheckBox, SeekBar, TextView, content description set, explicit traversal order).
4. Sends TalkBack actions back to the real controls on the main thread.

It uses Godot's built-in `JavaClassWrapper` and `AndroidRuntime` (Godot 4.4+), so there is no Gradle build, plugin or AAR to maintain.

## How each control behaves with TalkBack on
- Buttons: swipe to hear the name and description; double tap presses the button. Shortcut text such as "Pass · Space" is spoken as "Pass", and Windows-only shortcut sentences are dropped.
- Direction and Sprint buttons: double tap holds the direction for 0.35 s (one step) or sprint for 3 s, because a double tap cannot hold a button.
- Toggles (Settings, starters): announce checked or not checked.
- Option selectors (mode, league, team): double tap cycles to the next option and speaks it.
- Sliders (Settings): adjust with swipe up/down or the volume keys; the spoken value comes from the on-screen readout.
- Player name: double tap opens the field and the keyboard.
- Controls scrolled off screen stay in the swipe order; double tapping one scrolls it into view first.

## Switching it off
Set `ENABLED := false` at the top of the bridge script. If a future Godot version exposes controls to TalkBack natively and you hear every item twice, do this.

## Not yet verified
This was written without a device or Godot build available. Test on a phone with TalkBack: swipe order on each screen, double tap on every button, the match HUD, and Settings sliders. Logcat lines are prefixed `[a11y-bridge]`.
