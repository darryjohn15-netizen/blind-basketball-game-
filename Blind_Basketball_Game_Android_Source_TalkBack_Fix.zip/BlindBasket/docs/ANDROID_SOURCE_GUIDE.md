# Android APK and source guide

## Ready-to-use Android download

The single sideloadable APK is `dist/native/Blind Basketball Game.apk` (81,610,386 bytes / 81.61 MB). Its SHA-256 is:

`e6940e9695891b546db42d61bba2ee15340273bcaa10a829d518e8edab6a5dce`

Verified APK identity: **Blind Basketball Game**, package `com.darryjohn.blindbasketballgame`, version **1.0.2**. It supports ARM64 and ARM32 devices, requires Android API 24 or later, targets API 36, and requests portrait orientation. The package signature verifies successfully.

This APK is signed with a sandbox-generated **debug certificate**, not a release certificate owned by the creator. It is suitable for sideload testing, not a Play Store release. Android may block installation as an update if a different signing key was used for an earlier install; installing this build may require uninstalling the old copy first, which can erase its local saves. The signing key is not included in the source archive.

To install, download the APK to the device, permit installs from the browser or file manager if Android prompts, open the APK, and follow Android's installer. On first launch, the game opens in portrait mode. The app is offline.

## Build from source

Use Godot **4.7.2** with its matching Android export template, JDK 17 or later, and Android SDK packages. The verified build machine used OpenJDK 21, Android Platform 35, Build-Tools 35.0.1, Platform-Tools 37.0.1, CMake 3.10.2.4988404, and NDK 28.1.13356709. Configure Java and Android SDK paths in Godot Editor Settings, then export with the `Android APK` preset:

```sh
godot --headless --path . --export-debug "Android APK" "dist/native/Blind Basketball Game.apk"
```

The debug export uses the machine's Godot debug keystore. For an updateable creator release or Play Store submission, configure and protect a creator-owned signing key instead. Godot printed a non-blocking notice that it was using Build-Tools 35.0.1 for Target SDK 36; export and APK signature verification completed.

## Controls and accessibility

Use the large on-screen directional and action controls. Spoken match status is available from the Read Status control; the project also assigns semantic control names, a row-major accessibility flow, and 64-unit minimum interactive targets.

**TalkBack fix (this source revision).** Godot's Android view does not expose Control nodes to TalkBack, so the `accessibility_name` metadata alone never reached the screen reader and the buttons were silent. `autoload/android_accessibility_bridge.gd` now mirrors every visible control as an invisible native Android view (Button, CheckBox, SeekBar, TextView) so TalkBack reads each label, swipes through them in left-to-right then top-to-bottom order, and double tap activates the real Godot control. It needs no Gradle build, plugin or extra export option, and does nothing unless Android touch exploration is on. See `docs/TALKBACK_BRIDGE.md`.

**Physical-device TalkBack testing has not been performed.** Godot/platform screen-reader integration is not verified here, so compatibility with TalkBack or all Android screen readers is not guaranteed. Verify swiping, focus, activation, orientation, audio and haptics on representative devices before claiming universal accessibility.

## Project notes

The project preserves creator credit **Darry John Sarmiento** and the About/community link `https://t.me/gwapokobay1639`. See `platform-delivery-status.md` for the full verification and remaining research status.
