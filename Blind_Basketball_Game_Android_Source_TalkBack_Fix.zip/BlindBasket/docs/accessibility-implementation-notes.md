# Accessibility and portrait implementation notes

Research checked 2026-10-28 against the official Godot 4.7 documentation and Android developer guidance.

## Screen-reader behavior

- Godot 4.7 `Control` exposes `accessibility_name`, `accessibility_description`, `accessibility_flow_to_nodes` and focus-neighbor properties. Use concise names, actionable descriptions and an explicit reading flow that follows the visible controls in left-to-right row order and top-to-bottom row order. Every interactive button must retain visible text, keyboard focus and a real callback.
- Godot's official 4.5 release notes describe AccessKit-based screen-reader support for `Control` nodes and screen-reader bindings, but state that the integration is experimental. The retrieved 4.7 `AccessibilityServer` and `Control` documentation does not explicitly confirm Android/TalkBack support. Therefore, this project must not claim universal screen-reader compatibility based only on setting Control metadata.
- The game will set semantic labels/descriptions and explicit flow for supported accessibility backends, retain Windows keyboard navigation and its own spoken match-status fallback, and require real-device verification with Windows Narrator/NVDA and Android TalkBack before claiming those combinations as verified.

## Android TalkBack bridge

Control metadata is not enough on Android: the Godot view exposes no accessibility nodes to TalkBack. `autoload/android_accessibility_bridge.gd` supplies them as native overlay views. See `docs/TALKBACK_BRIDGE.md`. Device verification is still required.

## Android portrait and responsive UI

- Godot 4.7 `DisplayServer.ScreenOrientation.SCREEN_PORTRAIT` is value `1`; `display/window/handheld/orientation` uses this orientation enum.
- Portrait orientation does not automatically swap the project viewport width and height. Set the logical resolution deliberately. The official multiple-resolution guide recommends a 720 x 1280 portrait base, `canvas_items` stretch, `expand` aspect for varying phone ratios, and responsive Control anchors/containers.
- Google's Android form-factor guide also recommends accounting for varied phone/tablet aspect ratios and input methods; test the vertical menu, touch buttons, court and text on portrait phones and narrower/wider portrait layouts.

## Sources

1. Godot 4.7 `Control` class: https://docs.godotengine.org/en/4.7/classes/class_control.html
2. Godot `AccessibilityServer` class: https://docs.godotengine.org/en/stable/classes/class_accessibilityserver.html
3. Godot 4.5 release notes, “Screen reader support”: https://godotengine.org/releases/4.5/
4. Godot 4.7 `DisplayServer` class, `ScreenOrientation`: https://docs.godotengine.org/en/4.7/classes/class_displayserver.html
5. Godot `ProjectSettings` class: https://docs.godotengine.org/en/stable/classes/class_projectsettings.html
6. Godot multiple resolutions, “Mobile game in portrait mode”: https://docs.godotengine.org/en/stable/tutorials/rendering/multiple_resolutions.html
7. Android Developers, Godot form factors: https://developer.android.com/games/engines/godot/godot-formfactor
