# Blind Basketball Game 1.0.2 — Android source package

This archive contains the complete Blind Basketball Game Godot source tree from commit 52747755389309a39eaa65da756a6f0982ec6b8b.
Native compiled downloads are separate files and are not embedded in this source ZIP.
No Android signing key, SDK, Godot export templates, editor cache, or native executable is included.
See docs/platform-delivery-status.md for verified package sizes and untested device/accessibility limits.
Build the ARM64/ARM32 debug-signed APK using Godot 4.7.2, its Android export template, JDK 17+, and the Android SDK. Configure Android SDK/JDK paths in Editor Settings and export with the `Android APK` preset. The ready-to-sideload APK is distributed separately as `Blind Basketball Game.apk`; it uses a sandbox debug certificate, not a creator-owned release/Play Store key. Read `docs/ANDROID_SOURCE_GUIDE.md` for exact export and installation steps.
