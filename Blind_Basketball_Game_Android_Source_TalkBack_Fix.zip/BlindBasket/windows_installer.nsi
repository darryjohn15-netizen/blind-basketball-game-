Unicode true

!include "MUI2.nsh"

Name "Blind Basketball Game"
OutFile "dist/native/Blind_Basketball_Game_Windows_Setup_1.0.2.exe"
InstallDir "$LOCALAPPDATA\Programs\Blind Basketball Game"
RequestExecutionLevel user
SetCompressor /SOLID lzma
SetCompressorDictSize 64
ShowInstDetails nevershow
ShowUninstDetails nevershow

VIProductVersion "1.0.2.0"
VIAddVersionKey "ProductName" "Blind Basketball Game"
VIAddVersionKey "CompanyName" "Darry John Sarmiento"
VIAddVersionKey "FileDescription" "Blind Basketball Game Windows Setup"
VIAddVersionKey "FileVersion" "1.0.2.0"
VIAddVersionKey "ProductVersion" "1.0.2"
VIAddVersionKey "LegalCopyright" "Created by Darry John Sarmiento"

!define MUI_ABORTWARNING
!define MUI_FINISHPAGE_RUN "$INSTDIR\Blind Basketball Game.exe"
!define MUI_FINISHPAGE_RUN_TEXT "Launch Blind Basketball Game"

!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH

!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_UNPAGE_FINISH

!insertmacro MUI_LANGUAGE "English"

Section "Blind Basketball Game" SEC_GAME
  SectionIn RO
  SetShellVarContext current
  SetOutPath "$INSTDIR"
  File "dist/native/Blind Basketball Game.exe"
  WriteUninstaller "$INSTDIR\Uninstall.exe"

  CreateDirectory "$SMPROGRAMS\Blind Basketball Game"
  CreateShortcut "$SMPROGRAMS\Blind Basketball Game\Blind Basketball Game.lnk" "$INSTDIR\Blind Basketball Game.exe"
  CreateShortcut "$SMPROGRAMS\Blind Basketball Game\Uninstall.lnk" "$INSTDIR\Uninstall.exe"
  CreateShortcut "$DESKTOP\Blind Basketball Game.lnk" "$INSTDIR\Blind Basketball Game.exe"

  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\BlindBasketballGame" "DisplayName" "Blind Basketball Game"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\BlindBasketballGame" "DisplayVersion" "1.0.2"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\BlindBasketballGame" "Publisher" "Darry John Sarmiento"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\BlindBasketballGame" "InstallLocation" "$INSTDIR"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\BlindBasketballGame" "UninstallString" '"$INSTDIR\Uninstall.exe"'
SectionEnd

Section "Uninstall"
  SetShellVarContext current
  Delete "$DESKTOP\Blind Basketball Game.lnk"
  Delete "$SMPROGRAMS\Blind Basketball Game\Blind Basketball Game.lnk"
  Delete "$SMPROGRAMS\Blind Basketball Game\Uninstall.lnk"
  RMDir "$SMPROGRAMS\Blind Basketball Game"
  Delete "$INSTDIR\Blind Basketball Game.exe"
  Delete "$INSTDIR\Uninstall.exe"
  RMDir "$INSTDIR"
  DeleteRegKey HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\BlindBasketballGame"
SectionEnd
