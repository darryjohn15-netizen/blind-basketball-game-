# Phoenix (PBA) — Season 50 Governors’ Cup roster audit

**As of / retrieved:** 2026-10-25. **Team and competition:** Phoenix Super LPG Fuel Masters, PBA Season 50 Governors’ Cup (2026). The official team page identifies the team as “PHOENIX”; official league reports explicitly identify the contemporaneous competition as the Season 50 Governors’ Cup. [1][2]

The newest dated official game report located, for the Oct. 23 elimination game, names these Phoenix players in its box score: Marcellus St. Clair Earlington, Gian Robert Mamuyac, Francis Gabriel Escandor, Ricci Paolo Rivero, Kenneth James Tuffin, Justin Shaun Chua, Kainoa Bryson Ballungay, Bryan Santos, Jose Carlos Cullar, John Louisse De Los Santos, Arnold Dave Ando, and Christian Tyler Tio. [3] The Oct. 24 official league preview says Jason Perkins and Will Gozum were sidelined by injuries; the official team page lists both as Phoenix players. [1][4] The jersey numbers and positions below follow the labels on that official team page, not inferred assignments.

The official team page is not a reliable dated snapshot by itself: it also retains Robert Johnson III (BJ Johnson), while the league reported Oct. 15 that Phoenix brought in Cellus Earlington “in lieu of BJ Johnson.” [1][2] The Oct. 23 score and Oct. 24 team report support Earlington, not Johnson, as the replacement import. The team page does not state its roster’s effective date, and the latest dated game box score does not establish whether players who did not appear in that game remain rostered. Accordingly, this audit includes only the 12 players in the latest box score plus Perkins and Gozum, whose injuries are explicitly reported, and sets `roster_complete=false`; other current roster membership cannot be fully verified from the available dated official evidence. Names are reported in the official team-page roster order, not as starters.

## References

[1]: https://pba.ph/teams/phoenix "PHOENIX - Teams | PBA - The Official Website"
[2]: https://www.pba.ph/news/earlington-to-the-rescue-for-phoenix-vs-meralco "Earlington to the rescue for Phoenix vs Meralco, Oct. 15, 2026"
[3]: https://www.pba.ph/news/ros-blasts-phoenix-sets-up-quarterfinals-duel-vs-converge "ROS blasts Phoenix, sets up quarterfinals duel vs Converge, Oct. 23, 2026"
[4]: https://www.pba.ph/news/tiu-says-phoenix-will-have-to-play-a-lot-better-to-beat-nlex-in-game-1 "Tiu says Phoenix will have to play a lot better to beat NLEX in Game 1, Oct. 24, 2026"
