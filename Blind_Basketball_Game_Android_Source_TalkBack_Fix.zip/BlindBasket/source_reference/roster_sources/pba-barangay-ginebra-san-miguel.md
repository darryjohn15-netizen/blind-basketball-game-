# Barangay Ginebra San Miguel — roster source audit

**League/team:** PBA — Barangay Ginebra San Miguel  
**Requested season:** Season 50 Governors’ Cup (2026)  
**As of / retrieved:** 2026-10-25

The official PBA team profile confirms the exact team name and exposes an “Official Roster” section. Its roster cards list 17 players, with jersey numbers and positions, and the page’s team statistics show 10 conference games. The visible profile does not name the conference or season, however, so it does not by itself prove that its full roster is specifically the Season 50 Governors’ Cup roster. The cards and statistics are consistent with the current-season context, but I conservatively mark the roster incomplete pending a season-labelled official roster source. [1]

The PBA’s October 10 report explicitly identifies the current competition as the Governors’ Cup and says Ginebra was using replacement import Jordan Murphy while Justin Brownlee was absent. This supports Murphy’s inclusion in the current roster context, but is not a complete lineup list. [2] The official schedule confirms Ginebra’s October 23 game against Blackwater. [3] ABS-CBN’s dated report gives that game’s 13-player scoring list, which corroborates a subset of names in the official team profile but cannot establish the full roster. [4]

The reported order below follows the official profile’s roster-card order; it does not identify starters. Jersey numbers and positions are included only as displayed on that profile. No unsupported roster members are added. `roster_complete=false` reflects the missing season/conference label on the official full roster page.

## References

[1]: https://www.pba.ph/teams/barangay-ginebra-san-miguel "Barangay Ginebra San Miguel — Teams, PBA official website"
[2]: https://pba.ph/news/with-or-without-jb-ginebra-remains-dangerous-says-tenorio "With or without JB, Ginebra remains dangerous, says Tenorio — PBA, October 10, 2026"
[3]: https://www.pba.ph/schedule "Schedule — PBA official website"
[4]: https://www.abs-cbn.com/sports/basketball/2026/10/23/pba-ginebra-holds-on-to-defeat-blackwater-completes-govs-cup-quarterfinals-cast-2130 "PBA: Ginebra holds on to defeat Blackwater, completes Govs' Cup quarterfinals cast — ABS-CBN News, October 23, 2026"
