# Minnesota Timberwolves roster audit

**League/team:** NBA — Minnesota Timberwolves. **Season:** 2026–27. **As-of date:** 2026-10-25. **Retrieved:** 2026-10-25 (UTC+08:00).

The supplied [NBA.com Timberwolves roster page](https://www.nba.com/timberwolves/roster) is for the Minnesota Timberwolves, but its title/body do not identify a season or an as-of date. The season-specific source is the team's [October 19, 2026 opening-night roster announcement](https://timberwolves.com/news/timberwolves-finalize-2026-27-opening-night-roster), which states that the 2026–27 opening roster stands at 16 players and links the [dated printable roster sheet](https://events.wolveslynx.com/rs/055-RNL-339/images/TW2627-Final-Roster.pdf). That sheet is headed “2026-27 Timberwolves Roster (as of October 19, 2026)” and gives the following player order, jersey numbers and positions. Its footnote marks Zyon Pullin and Rocco Zikarsky as two-way players; the other listed players are not marked two-way.[1][2]

| # | Player | Position | Classification |
|---:|---|:---:|---|
| 1 | LaMelo Ball | G | Standard |
| 19 | Joan Beringer | C | Standard |
| 7 | Jaylen Clark | G | Standard |
| 0 | Donte DiVincenzo | G | Standard |
| 13 | Ayo Dosunmu | G | Standard |
| 5 | Anthony Edwards | G | Standard |
| 33 | Isaiah Evans | G | Standard |
| 27 | Rudy Gobert | C | Standard |
| 8 | Bones Hyland | G | Standard |
| 24 | Jonathan Kuminga | F | Standard |
| 41 | Trey Lyles | F | Standard |
| 3 | Jaden McDaniels | F | Standard |
| 15 | Zyon Pullin | G | Two-way |
| 4 | Terrence Shannon Jr | G | Standard |
| 9 | Cody Williams | G | Standard |
| 44 | Rocco Zikarsky | C | Two-way |

**Completeness limitation:** `roster_complete=false` for the requested October 25 snapshot. The official NBA.com roster page retrieved on October 25 still displayed Antonio Reeves, Enrique Freeman, KJ Martin, Norchad Omier and Drew Timme, while the club's October 17 announcement explicitly says it waived those five players.[3] The NBA G League's 2026–27 two-way tracker also lists Enrique Freeman with Minnesota, despite that waiver announcement and his omission from the October 19 finalized roster sheet.[4] The dated opening-night sheet is the latest season-specific finalized team roster located, but this conflict among official pages means I cannot verify whether it remained a complete current roster on October 25. I therefore return only the 16 players on that dated finalized sheet and do not infer any later roster moves. The displayed order is roster order, not a confirmed starting lineup.

## References

[1]: https://timberwolves.com/news/timberwolves-finalize-2026-27-opening-night-roster "Timberwolves Finalize 2026-27 Opening Night Roster"
[2]: https://events.wolveslynx.com/rs/055-RNL-339/images/TW2627-Final-Roster.pdf "2026-27 Timberwolves Roster as of October 19, 2026"
[3]: https://timberwolves.com/news/timberwolves-waive-five-players "Timberwolves Waive Five Players"
[4]: https://gleague.nba.com/twowayplayers "Two-Way Tracker NBA Players Signed to Two-Way Contracts"
[5]: https://www.nba.com/timberwolves/roster "Roster Minnesota Timberwolves"
