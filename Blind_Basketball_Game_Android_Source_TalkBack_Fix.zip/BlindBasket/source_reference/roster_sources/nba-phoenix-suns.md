# Phoenix Suns roster audit — 2026–27

**As of / retrieved:** 2026-10-25. The supplied candidate page is the official Phoenix Suns roster page: its title and team branding identify the Phoenix Suns. The official Suns 2026–27 schedule page corroborates that the club site is presenting the requested season. The roster page’s player cards reflect current-season activity and list 17 players; a current opening-roster report independently calls the roster finalized and supplies the same 17 names. The NBA's 2026–27 opening-night rosters article confirms the season context and includes Phoenix, although its retrieved page does not expose the team player list.[1][2][3]

The official roster page supplies jersey numbers and positions. Drew Timme is listed there as No. 17, while a contemporaneous roster report identifies him as No. 2; his number is therefore left unreported here. That report, current NBA player-page transaction notes, and reporting on Pat Spencer identify Timme, Duop Reath, and Spencer as two-way players. The official Suns roster page itself does not mark contract classification, so the classifications below rely on those reports rather than an official classification label.[1][4][5][6]

The NBA G League two-way tracker was not used to establish the current two-way set: despite its 2026–27 heading, its Phoenix entries include Koby Brea and CJ Huntley, whom the Oct. 20 roster report says were waived, and omit Reath and Timme. Roster order below is copied from the official page and is **not** a starter designation. Timme's jersey number is intentionally blank because of the conflict.[4][7]

## Verified roster

| Player | Jersey | Position | Classification |
|---|---:|---|---|
| Ryan Dunn | 0 | Forward | Standard |
| Dillon Brooks | 3 | Guard-Forward | Standard |
| Jalen Green | 4 | Guard | Standard |
| Luke Kennard | 8 | Guard | Standard |
| Khaman Maluach | 10 | Center | Standard |
| Oso Ighodaro | 11 | Forward | Standard |
| Collin Gillespie | 12 | Guard | Standard |
| Devin Booker | 15 | Guard | Standard |
| Jamaree Bouyea | 17 | Guard | Standard |
| Drew Timme |  | Forward | Two-way |
| Koa Peat | 18 | Forward | Standard |
| Rasheer Fleming | 20 | Forward | Standard |
| Miles Bridges | 22 | Forward | Standard |
| Jordan Goodwin | 23 | Guard | Standard |
| Mark Williams | 25 | Center | Standard |
| Duop Reath | 26 | Center | Two-way |
| Pat Spencer | 61 | Guard | Two-way |

## References

[1]: https://www.nba.com/suns/roster "Phoenix Suns official roster"
[2]: https://www.nba.com/suns/schedule2627 "Phoenix Suns 2026–27 schedule"
[3]: https://www.nba.com/news/nba-rosters-set-for-2026-27-regular-season "NBA rosters set for 2026–27 regular season"
[4]: https://sports.yahoo.com/articles/suns-finalize-2026-27-regular-231322329.html "Suns Finalize 2026-27 Regular Season Roster, republished from SI"
[5]: https://www.nba.com/player/1641871/duop-reath "Duop Reath NBA player page"
[6]: https://arizonasports.com/nba/phoenix-suns/suns-2-way-contract-g-pat-spencer-official "Suns officially agree to two-way contract with Pat Spencer"
[7]: https://gleague.nba.com/twowayplayers "NBA G League Two-Way Tracker"
[8]: https://sports.yahoo.com/articles/2-way-contract-drew-timme-170250636.html "Two-way contract Drew Timme will wear No. 2"
