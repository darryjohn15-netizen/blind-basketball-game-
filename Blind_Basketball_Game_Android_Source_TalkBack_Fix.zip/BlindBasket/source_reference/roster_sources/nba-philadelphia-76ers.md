# Philadelphia 76ers (NBA), 2026–27 roster

**As of / retrieved:** 2026-10-25. The supplied official candidate page is the Philadelphia 76ers roster page: its title identifies the team and 2026–27 season, its Sixers page branding and roster banner match the team, and its footer links the 2026–27 schedule. It lists 16 player cards. Names and jersey numbers below follow the page’s roster order, not a starters ranking. The page does not provide positions in its accessible roster details, so positions are unreported here. [1]

| Roster order | Player | Jersey | Classification |
|---:|---|---:|---|
| 1 | Labaron Philon | 00 | Standard |
| 2 | Tyrese Maxey | 0 | Standard |
| 3 | Kentavious Caldwell-Pope | 1 | Standard |
| 4 | Anfernee Simons | 5 | Standard |
| 5 | Jaylen Brown | 7 | Standard |
| 6 | Caleb Love | 8 | Two-way |
| 7 | Justin Edwards | 11 | Standard |
| 8 | Rayan Rupert | 12 | Two-way |
| 9 | Joel Embiid | 21 | Standard |
| 10 | LeBron James | 23 | Standard |
| 11 | Dominick Barlow | 25 | Standard |
| 12 | Adem Bona | 30 | Standard |
| 13 | Jabari Walker | 33 | Standard |
| 14 | Dean Wade | 45 | Standard |
| 15 | Ariel Hukporti | 55 | Standard |
| 16 | VJ Edgecombe | 77 | Standard |

The official team’s new-player explainer identifies Caleb Love and Rayan Rupert as two-way-contract additions; Rupert’s separate official signing release also confirms his two-way contract and No. 12. [2] [3] Jersey numbers are read from the number graphics on the current roster cards. [1]

**Completeness and limitation:** `roster_complete=true` for the 16 players listed on the live official team roster page at retrieval. The roster page’s player-stat modules still say “2025–26 season averages,” although the page title, October 2026 banner asset, and schedule navigation reflect 2026–27. I therefore treat the page’s roster cards—not those season-average labels—as the current roster evidence. No positions are stated because they were not verifiable on the official roster page. Standard classification for players other than the two identified two-way players reflects their placement on the official roster and the official report’s explicit two-way identifications; the roster page itself does not label contract type. [1] [2]

## References

[1]: https://www.nba.com/sixers/roster "Philadelphia 76ers 2026-27 Roster | Sixers Basketball"
[2]: https://sixers.com/news/meet-the-new-sixers-bios-stats-and-quick-facts "Meet the New Sixers: Bios, Stats and Quick Facts"
[3]: https://www.nba.com/sixers/news/philadelphia-76erssign-rayan-rupert-to-two-way-contract "Philadelphia 76ers Sign Rayan Rupert to Two-Way Contract"
