# Meralco Bolts — PBA Season 50 Governors’ Cup roster audit

**As of / retrieved:** 2026-10-25. **League/team/season:** PBA / Meralco Bolts / Season 50 Governors’ Cup (2026).

The candidate page is the official PBA team page headed **MERALCO BOLTS**; the PBA teams directory also lists Meralco Bolts as a current league team.[1][2] The page’s current team statistics show 10 games, consistent with Meralco’s 4–6 Governors’ Cup finish reported by the PBA on October 16, 2026; that report explicitly identifies the competition as the PBA Season 50 Governors’ Cup and lists players appearing for Meralco.[1][3] The official roster page provides the jersey numbers, positions, and roster order below. Order is reproduced as listed and does **not** denote starters.[1]

| Roster order | Player | No. | Position | Classification |
|---:|---|---:|---|---|
| 1 | Raymond Almazan | 20 | C | Local |
| 2 | Christopher Clark Banchero | 6 | PG | Local |
| 3 | Brandon Matthew Bates | 33 | C | Local |
| 4 | Norman Aaron Black | 1 | SG | Local |
| 5 | Jason Alexander Brickman | 5 | PG | Local |
| 6 | Crispin John Cansino | 71 | SF | Local |
| 7 | Antonio Jose Caram | 17 | PG | Local |
| 8 | Jefferson Comia | 29 | PG | Local |
| 9 | Clifford Marion Hodge | 7 | PF | Local |
| 10 | Vince Magbuhos | 93 | SF | Local |
| 11 | Allein Gail Maliksi | 22 | SF | Local |
| 12 | Javee Mocon | 10 | SF | Local |
| 13 | Christopher Elijah Newsome | 11 | SG | Local |
| 14 | Kyle Nicholas Pascual | 32 | C | Local |
| 15 | Kier John Quinto | 19 | SF | Local |
| 16 | Jansen Rios | 27 | SF | Local |
| 17 | Jordon Varnado | 23 | PF | Import |

**Completeness: not fully verifiable (`roster_complete=false`).** The official team page’s “Team Roster” also includes Antonio Hester (#9, PF), but the PBA described Hester on July 16 as a replacement for injured Varnado “for the moment”; on August 14 it reported Varnado’s return and said he took over import duties from stand-in Hester.[4][5] The page therefore appears to retain a conference participant alongside the later import, and does not label its roster with a season or an update date. I exclude Hester from the current roster, but the live page’s inclusion of a former temporary import means a complete active roster cannot be certified from the available official evidence. The names above are supported by the official roster page; the PBA’s October 16 box score independently confirms Varnado, Cansino, Quinto, Brickman, Newsome, Hodge, Banchero, Bates, and Mocon appearing at the end of the eliminations.[1][3]

## References

[1]: https://www.pba.ph/teams/meralco-bolts "Meralco Bolts - Official PBA team page"
[2]: https://www.pba.ph/teams "Teams - Official PBA directory"
[3]: https://www.pba.ph/news/phoenix-fights-back-boots-way-to-governors-cup-playoffs "Phoenix fights back, boots way to Governors’ Cup playoffs"
[4]: https://www.pba.ph/news/meralco-not-taking-chances "Meralco not taking chances"
[5]: https://www.pba.ph/news/worth-the-wait-jordon-varnado-drops-31-in-explosive-meralco-debut-to-ground-ginebra "Worth the Wait: Jordon Varnado Drops 31 in Explosive Meralco Debut to Ground Ginebra"
