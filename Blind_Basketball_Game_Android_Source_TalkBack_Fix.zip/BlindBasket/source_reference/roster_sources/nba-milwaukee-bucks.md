# Milwaukee Bucks roster audit — 2026–27

**As of / retrieved:** 2026-10-25. The candidate page is the official NBA Milwaukee Bucks roster page (title, team branding, and `/bucks/roster` path confirm the team). It displays 18 players, their jersey numbers and positions, and current-season statistics. The page itself does not print a season label, so its season attribution is cross-checked against the Bucks’ official October 19 announcement explicitly titled “Milwaukee Bucks Finalize 2026-27 Opening Night Roster.” That announcement lists 18 players; all 18 names match the NBA roster page retrieved on October 25. The team release marks Kam Jones, Cormac Ryan, and Pete Nance with asterisks and defines the asterisk as a two-way contract. [1] [2]

The names, jersey numbers, and positions below follow the live NBA roster page’s display and order as retrieved. “Standard” is the remainder of the 18-player team list after applying the team release’s three two-way markers. Roster order is not a starter designation.

| Roster order | Player | No. | Position | Classification |
|---:|---|---:|---|---|
| 1 | Brayden Burries | 0 | Guard | Standard |
| 2 | Jericho Sims | 00 | Center | Standard |
| 3 | Myles Turner | 3 | Center-Forward | Standard |
| 4 | Gary Trent Jr. | 5 | Guard | Standard |
| 5 | Kel'el Ware | 9 | Center | Standard |
| 6 | Tyler Herro | 11 | Guard | Standard |
| 7 | Caris LeVert | 12 | Guard | Standard |
| 8 | Ryan Rollins | 13 | Guard | Standard |
| 9 | Nate Ament | 15 | Forward | Standard |
| 10 | Kyle Kuzma | 18 | Forward | Standard |
| 11 | Kam Jones | 19 | Guard | Two-way |
| 12 | AJ Green | 20 | Guard | Standard |
| 13 | Ousmane Dieng | 21 | Forward | Standard |
| 14 | Bogoljub Marković | 23 | Forward | Standard |
| 15 | Jaime Jaquez Jr. | 24 | Guard | Standard |
| 16 | Kasparas Jakučionis | 25 | Guard | Standard |
| 17 | Cormac Ryan | 30 | Guard | Two-way |
| 18 | Pete Nance | 35 | Forward | Two-way |

**Completeness:** `roster_complete=true` for the snapshot date. The official opening-night roster announcement gives a complete 18-player roster and classification markers; the live official NBA roster page retrieved on October 25 lists the same 18 players. This is a dated snapshot, not a guarantee against subsequent transactions.

## References

[1]: https://www.nba.com/bucks/roster "Roster | Milwaukee Bucks"
[2]: https://bucks.com/news/milwaukee-bucks-finalize-2026-27-opening-night-roster "Milwaukee Bucks Finalize 2026-27 Opening Night Roster" (published October 19, 2026)
