# New York Knicks roster source audit

**As of / retrieved:** 2026-10-25. The supplied URL is the official NBA page for the **New York Knicks**, so the team identity is exact. It is a live team roster page, not a season-archived page; its extracted text does not itself label a season. The NBA’s 2026–27 key-dates page identifies October 20, 2026 as the regular-season start and October 19 as the opening-day roster deadline, and the league’s 2026–27 Knicks preview corroborates the season context. [1] [2] [3]

The live roster page lists the following players in page order, with jersey number and position as shown: Jordan Clarkson (00, Guard); Andre Drummond (0, Center); Miles McBride (2, Guard); Josh Hart (3, Guard); Pacôme Dadiet (4, Forward); Jose Alvarado (5, Guard); OG Anunoby (8, Forward-Guard); Kevin McCullar Jr. (9, Guard); Bruce Brown (11, Guard-Forward); Jalen Brunson (11, Guard); James Wiseman (11, Center); Tony Bradley (13, Center-Forward); Tyler Kolek (13, Guard); Drew Eubanks (17, Forward-Center); Mikal Bridges (25, Guard-Forward); Ochai Agbaji (30, Guard); Karl-Anthony Towns (32, Center-Forward); Landry Shamet (44, Guard); Mohamed Diawara (51, Forward); Tyler Nickel (55, Forward); and Jaden Akins (jersey not shown, Guard). The page gives no roster-order or starter designation, and does not classify most players by contract type. [1]

The official Knicks announcements identify Tyler Nickel and Jaden Akins as two-way signings. On October 23, the Knicks also announced Dalton Knecht’s two-way signing, but Knecht does not appear on the live NBA roster page. ESPN reported that Knecht’s addition required waiving a two-way player and that the three slots had been occupied by Akins, McCullar Jr. and Nickel; the Knicks announcement does not identify a waived player. The official page still lists McCullar Jr. and the newest official signing release adds Knecht, leaving the exact post-transaction roster unresolved. [4] [5] [6] [7]

**Completeness:** `roster_complete=false`. The live official roster page is not demonstrably synchronized with the October 23 transaction, and the available official release does not identify the displaced player. Names, positions, numbers and contract classes beyond the evidence above should not be inferred. Retrieval date is October 25, 2026.

## References

[1]: https://www.nba.com/knicks/roster "New York Knicks official roster"
[2]: https://www.nba.com/news/key-dates "NBA 2026-27 key dates"
[3]: https://www.nba.com/news/2026-27-season-preview-nyk "NBA 2026-27 season preview: New York Knicks"
[4]: https://www.nba.com/knicks/news/new-york-knicks-sign-tyler-nickel-to "Knicks sign Tyler Nickel to two-way contract, September 26, 2026"
[5]: https://knicks.com/news/new-york-knicks-sign-jaden-akins-totwo-way-contract "Knicks sign Jaden Akins to two-way contract, September 30, 2026"
[6]: https://knicks.com/news/new-york-knicks-sign-dalton-knecht-totwo-way-contract "Knicks sign Dalton Knecht to two-way contract, October 23, 2026"
[7]: https://www.espn.com/nba/story/_/id/50258464/ex-laker-knecht-joins-knicks-two-way-contract "ESPN report on Knecht signing and two-way slot, October 23, 2026"
