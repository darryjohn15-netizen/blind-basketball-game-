# Toronto Raptors roster source audit

**Scope:** Toronto Raptors, NBA, 2026–27 season. **As-of and retrieval date:** 2026-10-25.

The supplied [NBA.com Raptors roster page](https://www.nba.com/raptors/roster) is an official Toronto Raptors team roster page and its team identity is clear. Its rendered player list overlaps with the 2026–27 team roster, but the page does not itself state the season and includes additional names absent from the team’s dated opening-night roster. It therefore cannot independently establish the exact current contracted roster for the requested season. [1]

The clearest season-specific official source is the Raptors’ opening-night announcement, which labels its list “2026-27 Toronto Raptors roster” and dates it “as of October 19, 2026.” It lists 16 players with jersey numbers and positions; asterisks identify Nate Bittle and Malachi Smith as two-way players. The other 14 are reported as standard players. [2] A separate team transaction announcement confirms Bittle’s two-way conversion and says Toronto waived Nimari Burnett and Tyreke Key, among others. [3]

The NBA.com page lists five names not on the dated 16-player opening-night list: Chucky Hepburn, Trey Jemison III, Nimari Burnett, Tyson Degenhart, and Tyreke Key. The team had explicitly announced waivers for Burnett, Degenhart, and Key. The retrieved sources do not resolve the page’s remaining additional names or provide a newer dated complete roster. Accordingly, the 16 names from the October 19 official roster are the supported roster as of the latest dated full list found, but **roster completeness as of October 25 is not verified**; the machine-readable result uses `roster_complete: false`. No players are presented as starters; the order follows the team’s alphabetical roster table.

## References

[1]: https://www.nba.com/raptors/roster "Roster | Toronto Raptors"
[2]: https://raptors.com/news/raptors-set-opening-night-roster-3 "Raptors Set Opening Night Roster"
[3]: https://raptors.com/news/raptors-convert-bittle-to-two-way-contract-waive-five "Raptors Convert Bittle to Two-Way Contract, Waive Five"
