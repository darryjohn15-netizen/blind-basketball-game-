# Charlotte Hornets 2026–27 roster audit

**As of:** 2026-10-25. **Retrieved:** 2026-10-25. **League/team:** NBA, Charlotte Hornets.

The requested official candidate page, [Charlotte Hornets roster](https://www.nba.com/hornets/roster), is for the correct team. Its page title identifies the Hornets, and the linked team context is Charlotte. The page itself does not identify a season or provide a season selector in the extracted view, so the 2026–27 season is independently confirmed by the team's dated 2026–27 training-camp release.[1][2]

The latest roster-finalization evidence located is a post-preseason report dated October 18, which states Charlotte finalized an 18-player roster (15 standard contracts and three two-way contracts) and names the players in each classification.[3] A separate season-guide report published October 21 presents the opening-night roster and two-way players, with jersey numbers for most players.[4] Official training-camp information supplies player numbers and positions for the camp roster, while the October 16 official waiver notice confirms Pat Connaughton was waived.[2][5]

The official live roster page appears stale for this audit: it still shows Pat Connaughton, Wyatt Fricks, and Jarkel Joiner, who were subsequently waived, and also includes Michael Ajayi and Kylan Boswell without jersey numbers. It lists Naz Reid as No. 11, conflicting with the dated training-camp roster and the October 21 opening-night report, both of which list him as No. 0.[1][2][3][4] Accordingly, the current-season player list is supported by the two dated secondary reports, but a fully authoritative official roster snapshot as of October 25 could not be verified. **Roster completeness is therefore set to false.** The following are the supported current-season names; roster order is not a statement of starter status.

## References

[1]: https://www.nba.com/hornets/roster "Roster | Charlotte Hornets"
[2]: https://hornets.com/news/charlotte-hornets-announce-2026-27-training-camp-roster "Charlotte Hornets Announce 2026-27 Training Camp Roster"
[3]: https://therookiewire.usatoday.com/story/sports/nba/rookie/2026/10/18/hornets-finalize-18-man-roster-following-final-preseason-game/92315985007/ "Charlotte Hornets finalize 18-man roster following final preseason game"
[4]: https://sports.yahoo.com/articles/2026-27-charlotte-hornets-season-185609719.html "2026-27 Charlotte Hornets Season Guide: Roster, Schedule, Storylines and Key Dates"
[5]: https://hornets.com/news/charlotte-hornets-waive-pat-connaughton "Charlotte Hornets Waive Pat Connaughton"
