# Brooklyn Nets roster audit — 2026–27

**As of:** 2026-10-25 (retrieved 2026-10-25). **Team/season verification:** The candidate is the Brooklyn Nets' official team roster page, and the NBA's official Nets season preview explicitly covers Brooklyn's 2026–27 season. [1] [2]

## Finding

The supported current roster is the 18-player list below: 15 standard-contract players and three two-way players. Names, jersey numbers, and positions follow the official Nets roster page; its order is preserved as roster order only, not a statement about starters. The current secondary 2026–27 roster page independently lists these 18 players and marks Chaney Johnson, Tyler Bilodeau, and Grant Nelson as two-way. [1] [3]

| Player | # | Position | Classification |
|---|---:|---|---|
| Mikel Brown Jr. | 0 | Guard | Standard |
| Josh Minott | 00 | Forward | Standard |
| Keon Ellis | 1 | Guard | Standard |
| Danny Wolf | 2 | Forward | Standard |
| Drake Powell | 4 | Guard-Forward | Standard |
| Egor Dëmin | 8 | Guard | Standard |
| Joshua Jefferson | 9 | Forward | Standard |
| Nolan Traoré | 10 | Guard | Standard |
| Moritz Wagner | 13 | Forward-Center | Standard |
| Terance Mann | 14 | Guard-Forward | Standard |
| Grant Nelson | 16 | Forward | Two-way |
| Michael Porter Jr. | 17 | Forward | Standard |
| Day'Ron Sharpe | 20 | Center | Standard |
| Noah Clowney | 21 | Forward-Center | Standard |
| Julius Randle | 30 | Forward-Center | Standard |
| Chaney Johnson | 31 | Guard-Forward | Two-way |
| Tyler Bilodeau | 34 | Forward | Two-way |
| Ben Saraf | 77 | Guard | Standard |

## Limitation

`roster_complete` is set to **false** conservatively. The candidate official Nets roster page still includes Ben Humrichous and Dain Dainja, although NBA player updates report Humrichous was waived on October 15 and Dainja was waived before the regular season. [4] [5] The NBA G League's current 2026–27 tracker and official team contract announcements support the Nets' three two-way players. [6] [7] [8] The list above is cross-checked against Basketball-Reference's 2026–27 roster as retrieved October 25, but a clean, current complete 18-player list was not exposed by the official team/league roster feed in this retrieval; therefore completeness is not asserted as fully verified from the official roster source. [3]

## References

[1]: https://www.nba.com/nets/roster "Brooklyn Nets official roster page"
[2]: https://www.nba.com/news/2026-27-season-preview-bkn "NBA 2026–27 Season Preview: Brooklyn Nets"
[3]: https://www.basketball-reference.com/teams/BRK/2027.html "2026–27 Brooklyn Nets Roster and Stats"
[4]: https://www.nba.com/player/1643750/ben-humrichous "NBA player profile: Ben Humrichous"
[5]: https://www.nba.com/nets/player/1643120/dain-dainja "NBA Nets player page: Dain Dainja"
[6]: https://gleague.nba.com/twowayplayers "NBA G League Two-Way Tracker, 2026–27"
[7]: https://brooklynnets.com/news/brooklyn-nets-sign-grant-nelson-to-two-way-contract "Brooklyn Nets sign Grant Nelson to two-way contract"
[8]: https://brooklynnets.com/news/brooklyn-nets-sign-mikel-brown-jr-and-tyler-bilodeau "Brooklyn Nets sign Mikel Brown Jr. and Tyler Bilodeau"
[9]: https://brooklynnets.com/news/brooklyn-nets-announce-2026-summer-league-roster "Brooklyn Nets announce 2026 Summer League roster"
