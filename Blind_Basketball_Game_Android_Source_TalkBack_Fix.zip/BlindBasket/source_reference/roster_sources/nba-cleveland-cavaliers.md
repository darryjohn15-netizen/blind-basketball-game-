# Cleveland Cavaliers 2026–27 roster audit

**As of / retrieved:** October 25, 2026. The official NBA page identifies the Cleveland Cavaliers and displays its 2026–27 roster view (“26–27 printable”). Its displayed names, numbers, and positions are in page order below; page order is not a statement about starters. The Cavaliers’ September 24 training-camp release identifies three two-way players with an asterisk: Tristan Enaruna, Riley Minix, and Ernest Udeh Jr. [1] [2]

The NBA roster page is not fully current: it still includes Rashaun Agee, Zack Austin, and Noam Yaacov. An October 19 report says Cleveland waived those three and Tre’Von Spillers, and that Cleveland then had 14 standard-contract players plus three two-way players. [3] The 17 names below are the NBA-page roster names after excluding the three displayed waived players; the camp announcement and October report corroborate the roster pool and contract count. Because the official roster page remains stale and no revised post-waiver official roster was located, **roster completeness is not independently confirmed (roster_complete=false)**. Player jersey and position values below follow the official NBA roster page, including its current listing of Udeh as No. 88; the earlier camp list showed No. 39. [1] [2]

| Roster order | Player | Jersey | Position | Classification |
|---:|---|---:|---|---|
| 1 | James Harden | 1 | Guard | Standard |
| 2 | Thomas Bryant | 3 | Center-Forward | Standard |
| 3 | Evan Mobley | 4 | Center | Standard |
| 4 | Sam Merrill | 5 | Guard | Standard |
| 5 | Peyton Watson | 8 | Guard | Standard |
| 6 | Craig Porter Jr. | 9 | Guard | Standard |
| 7 | Riley Minix | 12 | Forward | Two-way |
| 8 | Meleek Thomas | 15 | Guard | Standard |
| 9 | Khalifa Diop | 18 | Center | Standard |
| 10 | Jaylon Tyson | 20 | Guard-Forward | Standard |
| 11 | Tristan Enaruna | 21 | Forward | Two-way |
| 12 | Tyrese Proctor | 24 | Guard | Standard |
| 13 | Jarrett Allen | 31 | Center | Standard |
| 14 | Mario Hezonja | 33 | Forward-Guard | Standard |
| 15 | Nae'Qwan Tomlin | 35 | Forward | Standard |
| 16 | Donovan Mitchell | 45 | Guard | Standard |
| 17 | Ernest Udeh Jr. | 88 | Center | Two-way |

## References

[1]: https://www.nba.com/cavaliers/roster "Cleveland Cavaliers official roster"
[2]: https://cavs.com/news/releases-training-camp-roster-260924 "Cavaliers announce 2026 training camp roster"
[3]: https://sports.yahoo.com/articles/cavaliers-waive-four-exhibit-10-201103511.html "Cavaliers waive four Exhibit 10 players, leaving roster at 14 before opening night"