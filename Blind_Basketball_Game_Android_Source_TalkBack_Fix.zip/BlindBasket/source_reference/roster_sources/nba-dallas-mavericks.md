# Dallas Mavericks roster audit — 2026–27

**As of / retrieved:** 2026-10-25. **Team and season:** Dallas Mavericks, NBA, 2026–27. The supplied NBA.com roster URL is the official Dallas Mavericks roster page. It lists the team’s player names, jersey numbers, and positions; its displayed 17-player list aligns with the dated official 2026–27 team roster and subsequent official transactions. The season is independently confirmed by the official 2026–27 training-camp roster PDF and dated team announcements. [1] [2]

The NBA.com roster page currently lists 17 players but omits Walter Clayton Jr. The Mavericks announced on Oct. 21, 2026 that they signed Clayton to a two-way contract, so he is included as an additional current player; the announcement identifies him as a guard but does not give a jersey number. The official roster page therefore appears not to have incorporated that latest signing as of retrieval. [1] [3] The team’s Oct. 19 announcement said its roster then stood at 17, including two two-way players; Clayton’s later signing brings the evidenced count to 18. [4] The camp roster PDF is explicitly dated Sept. 26 and marks Jett Howard, Tobi Lawal, and John Poulakidas as two-way at that point. The team subsequently announced it waived John Poulakidas, and Clayton’s later two-way signing identifies the replacement; Jett Howard and Tobi Lawal remain on the official roster page. [2] [5] [3]

The roster below follows the order displayed on the official NBA roster page, with Clayton appended because the signing announcement does not specify roster order. No starters are inferred. Jersey and position fields are left blank only for Clayton where the official signing announcement gives no jersey number and the NBA roster page has not yet added him. The roster is treated as complete based on the 17 names in the official roster page plus the subsequent official two-way signing; the stated page-update gap is the material caveat.

## References

[1]: https://www.nba.com/mavericks/roster "Roster | Dallas Mavericks"
[2]: https://cdn.nba.com/teams/uploads/sites/1610612742/2026/09/2026-27-Dallas-Mavericks-Training-Camp-Roster.pdf "2026-27 Dallas Mavericks Training Camp Roster"
[3]: https://www.nba.com/mavs/news/mavericks-sign-walter-clayton-jr-to-two-way-contract "Mavericks Sign Walter Clayton Jr. to Two-Way Contract"
[4]: https://www.nba.com/mavs/news/mavericks-waive-dwight-powell "Mavericks Waive Dwight Powell"
[5]: https://www.nba.com/mavs/news/mavericks-waive-seth-lundy-and-john-poulakidas "Mavericks Waive Seth Lundy and John Poulakidas"
