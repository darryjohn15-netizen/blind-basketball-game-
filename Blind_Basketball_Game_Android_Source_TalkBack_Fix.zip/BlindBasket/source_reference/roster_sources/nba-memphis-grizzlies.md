# Memphis Grizzlies roster audit — NBA, 2026–27

**As of:** 2026-10-25 (retrieved 2026-10-25). **Team:** Memphis Grizzlies. **Season:** 2026–27.

The supplied NBA roster URL is the official Memphis Grizzlies team roster page, so the team identity is confirmed. The page itself does not identify a season-specific snapshot. Its displayed roster includes Walter Clayton Jr. and Micah Peavy, while the team's official 2026–27 opening-night announcement says Memphis waived both players to finalize its opening roster. Thus, the supplied page is stale for the current opening roster. [1] [2]

The latest full, season-specific roster list verified in an official team source is the team's 2026–27 Opening Night roster announcement, published October 20, 2026. It lists 18 players, identifies positions and jersey numbers, and marks Carson Cooper, Jahmai Mashack, and Javon Small as two-way players. The NBA.com team profile also displayed an older October 15 snapshot containing the two subsequently waived players, reinforcing that the undated roster views are not reliable current snapshots. [2] [3]

**Roster in official announcement order** (not a starter designation): Cameron Boozer (#27, F); Carson Cooper (#20, C, two-way); Cedric Coward (#23, W); Zach Edey (#14, C); Jerami Grant (#3, F); Taylor Hendricks (#22, F); GG Jackson II (#45, F); Ty Jerome (#2, G); Karim López (#35, F); Jahmai Mashack (#21, G, two-way); Kris Murray (#17, F); Scotty Pippen Jr. (#1, G); Quinten Post (#41, C); Olivier-Maxence Prosper (#18, F); Javon Small (#10, G, two-way); Cam Spencer (#24, G); Isaiah Stewart (#28, C); Jaylen Wells (#0, W). Position abbreviations reproduce the announcement.

**Completeness limitation:** `roster_complete=false`. The 18 names above are the complete roster in the dated October 20 official announcement, but the supplied current roster page remains inconsistent with it, and no later dated official full-roster snapshot was verified as of October 25. Accordingly, this is the latest fully supported list, not a claim that the official live roster page is current on the retrieval date.

## References

[1]: https://www.nba.com/grizzlies/roster "Memphis Grizzlies Roster"
[2]: https://grizzlies.com/news/grizzlies-finalize-202627-opening-night-roster "Grizzlies Finalize 2026–27 Opening Night Roster"
[3]: https://www.nba.com/team/1610612763/grizzlies "Memphis Grizzlies Team Info and News"
