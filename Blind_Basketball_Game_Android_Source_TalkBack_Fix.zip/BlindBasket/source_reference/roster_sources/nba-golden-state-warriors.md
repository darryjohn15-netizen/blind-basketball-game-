# Golden State Warriors (NBA) — roster source audit

**As-of and retrieval date:** 2026-10-25. **Season:** 2026–27.

The official NBA.com Warriors roster page identifies the team as the Golden State Warriors and, when retrieved on 2026-10-25, listed 18 players in roster order. It provides each listed name, position, and jersey number, and explicitly marks LJ Cryer, Malevy Leons, and Graham Ike as two-way players. I treat the remaining listed players as standard roster players. [1]

The season is corroborated by the Warriors’ official “Warriors Announce 2026-27 Opening Night Roster” announcement, dated October 19/20, 2026, which was the team’s contemporaneous roster-finalization notice. The club had stated on October 17 that its roster stood at 18 players and that the Opening Night roster would be finalized by October 19. [2] [3]

**Completeness and limitation:** The live NBA.com team roster page returned the 18 current player entries, with no season selector/season label visible in the extracted page text. The opening-night announcement’s current article body is dynamically updated with game coverage and no longer exposes its roster table in the readable page text; its title and indexed official announcement establish the 2026–27 opening-night context, but do not independently expose every roster row in the page extraction. Accordingly, the 18 names and their fields below are taken from the current official roster page as retrieved on the as-of date, with season corroborated by the dated team announcement. Player order is page roster order only, not a statement about starters.

## Current roster in official roster-page order

| Name | Jersey | Position | Classification |
|---|---:|---|---|
| Gary Payton II | 0 | Guard | Standard |
| Yaxel Lendeborg | 1 | Forward | Standard |
| Brandin Podziemski | 2 | Guard | Standard |
| Will Richard | 3 | Guard | Standard |
| Moses Moody | 4 | Guard | Standard |
| Kristaps Porziņģis | 7 | Forward-Center | Standard |
| De'Anthony Melton | 8 | Guard | Standard |
| Jimmy Butler III | 10 | Forward | Standard |
| Brandon Williams | 12 | Guard | Standard |
| Gui Santos | 15 | Forward | Standard |
| LJ Cryer | 18 | Guard | Two-way |
| Al Horford | 20 | Center | Standard |
| Draymond Green | 23 | Forward-Center | Standard |
| Charles Bassey | 28 | Forward-Center | Standard |
| Stephen Curry | 30 | Guard | Standard |
| Georges Niang | 32 | Forward | Standard |
| Malevy Leons | 33 | Forward | Two-way |
| Graham Ike | 45 | Forward-Center | Two-way |

## References

[1]: https://www.nba.com/warriors/roster "Golden State Warriors Roster, official NBA.com team page, retrieved October 25, 2026"
[2]: https://warriors.com/news/warriors-announce-2026-27-opening-night-roster-20261019 "Warriors Announce 2026-27 Opening Night Roster, official team announcement"
[3]: https://warriors.com/news/warriors-waive-tyler-burton-dalen-terry-alex-toohey-20261017 "Warriors Waive Tyler Burton, Dalen Terry & Alex Toohey, October 17, 2026"
