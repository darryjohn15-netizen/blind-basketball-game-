# Denver Nuggets roster audit — 2026–27

**As of / retrieved:** 2026-10-25. The candidate is the Denver Nuggets’ official NBA roster page. It lists the players below; the team’s official schedule identifies Denver and labels its schedule 2026–27, corroborating the season at the retrieval date. The season was underway by this date, with the schedule listing the Oct. 22 opener. [1] [2]

The official roster page lists 17 players in the order below. The official NBA G League two-way tracker is headed as covering the 2026–27 season, and current Denver signing announcements establish the three two-way contracts: Bryce Hopkins, Cam Whitmore, and Ryan Nembhard. The remaining 14 listed players are classified here as standard roster players. [1] [3] [4] [5] [6]

| Roster order | Player | Jersey | Position | Classification |
|---:|---|---:|---|---|
| 1 | Christian Braun | 0 | Guard | Standard |
| 2 | Julian Strawther | 1 | Guard | Standard |
| 3 | Cam Whitmore | — | Forward | Two-way |
| 4 | Marvin Bagley III | 3 | Forward | Standard |
| 5 | Tyus Jones | 5 | Guard | Standard |
| 6 | Trevon Brazile | 7 | Forward | Standard |
| 7 | Ryan Nembhard | 9 | Guard | Two-way |
| 8 | DeMar DeRozan | 10 | Guard-Forward | Standard |
| 9 | Alpha Diallo | 11 | Guard | Standard |
| 10 | Bryce Hopkins | 13 | Forward | Two-way |
| 11 | DaRon Holmes II | 14 | Forward | Standard |
| 12 | Nikola Jokić | 15 | Center | Standard |
| 13 | Spencer Jones | 21 | Forward | Standard |
| 14 | Zeke Nnaji | 22 | Forward-Center | Standard |
| 15 | Cameron Johnson | 23 | Forward | Standard |
| 16 | Jamal Murray | 27 | Guard | Standard |
| 17 | Aaron Gordon | 32 | Forward | Standard |

This is roster order only, not a confirmed-starters list. The jersey field for Cam Whitmore is left blank because the current roster page displays “1” while the September 22 team signing announcement says he would wear “#00”; the available official sources conflict, so neither number is treated as verified current. [1] [5]

**References**

[1]: https://www.nba.com/nuggets/roster "Denver Nuggets Roster"
[2]: https://www.nba.com/nuggets/schedule "Denver Nuggets Schedule 2026-27"
[3]: https://gleague.nba.com/twowayplayers "Two-Way Tracker: NBA Players Signed to Two-Way Contracts"
[4]: https://nuggets.com/news/nuggets-ryan-nembhard-two-way-contract "Nuggets Sign Ryan Nembhard to Two-Way Contract"
[5]: https://nuggets.com/news/nuggets-sign-cam-whitmore-to-two-way-contract "Nuggets Sign Cam Whitmore to Two-Way Contract"
[6]: https://nuggets.com/news/nuggets-sign-bryce-hopkins-to-two-way-contract "Nuggets Sign Bryce Hopkins to Two-Way Contract"
