# Converge FiberXers — roster source audit

**League:** Philippine Basketball Association (PBA)  
**Team:** Converge FiberXers  
**Season/conference:** PBA 50th Season Governors’ Cup (2026)  
**Retrieved / as of:** 2026-10-25

The supplied official candidate page is for the exact **CONVERGE FIBERXERS** team and has a named **Team Roster** section with jersey numbers and positions. Its roster page does not itself identify a conference, so I cross-checked the season against the official PBA statistics page, whose conference selector includes “50th Season Governors’ Cup,” and the October 18 PBA report, which says Converge completed its Governors’ Cup elimination campaign with an 8–4 record. These establish that the requested season is the current context, rather than an older team roster.[1][2][3]

The official team page lists the following 17 players in its roster order. Jersey numbers and positions below are taken from that page. “Local” and “import” are roster classifications; the PBA’s August transaction report and October coverage identify Cameron Clark as the import.[1][3][4] Roster order is not a starter designation.

| Roster order | Player | No. | Position | Classification |
|---:|---|---:|---|---|
| 1 | Calvin Abueva | 8 | PF | Local |
| 2 | Justin Arana | 15 | C | Local |
| 3 | Justine Baltazar | 19 | PF | Local |
| 4 | Cameron Clark | 23 | PF | Import |
| 5 | John Lloyd Clemente | 9 | SG | Local |
| 6 | Archie Concepcion | 2 | SG | Local |
| 7 | Jhaymo Eguilos | 21 | C | Local |
| 8 | Michael Jeffrey Garcia | 11 | PG | Local |
| 9 | Juan Gerardo Gomez de Liano | 1 | PG | Local |
| 10 | Jalen Andreas Hudson | 5 | SF | Local |
| 11 | Ladis Lepalam | 27 | C | Local |
| 12 | Larry Muyang | 20 | C | Local |
| 13 | Jonnel Policarpio | 16 | PF | Local |
| 14 | Ronan Santos | 24 | C | Local |
| 15 | Alec June Stockton | 12 | SG | Local |
| 16 | Frederick Tungcab | 3 | SF | Local |
| 17 | Michael Kurtiz Williams | 10 | SG | Local |

The official PBA transaction page records Converge’s August 10 signing of Cameron Clark in place of Jamaal Franklin, who was placed on the injured/reserve list. That aligns the displayed import with the Governors’ Cup roster. The October 18 PBA box-score report lists Converge players including Clark, Gomez de Liano, Baltazar, Stockton, Policarpio, Abueva, Arana, Williams, Garcia, Tungcab and Concepcion; the October 11 report additionally lists Clemente and Santos.[3][4][5]

**Completeness:** `roster_complete=true` based on the official PBA team page’s full Team Roster section retrieved October 25, 2026, with no later Converge transaction found on the official transactions page. The team page has no visible publication/update timestamp and does not label injured/reserve status in its roster display; treat it as the league’s current roster listing, not a game-active list. The official October reports corroborate game participation, not starters or the whole roster.[1][3][4][5]

## References

[1]: https://www.pba.ph/teams/converge-fiberxers "Converge FiberXers - PBA Teams"
[2]: https://pba.ph/stats "All Stats - PBA"
[3]: https://www.pba.ph/news/converge-turns-to-stockton-to-beat-tnt-in-overtime "Converge turns to Stockton to beat TNT in overtime"
[4]: https://www.pba.ph/transaction "Transactions - PBA"
[5]: https://www.pba.ph/news/gdl-s-triple-double-clark-s-30-point-effort-send-converge-to-quarters "GDL's triple-double, Clark's 30-point effort send Converge to quarters"
