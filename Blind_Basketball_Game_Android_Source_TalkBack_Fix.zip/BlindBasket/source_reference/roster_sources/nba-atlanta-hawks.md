# Atlanta Hawks roster audit — 2026–27

**Team/season verification.** The supplied page is the official NBA Atlanta Hawks team roster: its page title is “Official NBA Team Roster - Atlanta Hawks” and its contents are headed “Atlanta Hawks — Roster” [1]. The team’s official guide identifies itself as “Get to Know the 2026 - 27 Hawks” and refers to “this season’s roster” [2]; the NBA’s official 2026–27 season preview independently identifies the Hawks and discusses their 2026–27 season [3]. Retrieved October 25, 2026 (as-of date: 2026-10-25).

**Current roster.** The live official roster page displayed these 18 players in this order; jersey numbers and positions below are transcribed from that page [1]. Classification uses the Hawks’ September 25, 2026 training-camp announcement, whose asterisks and explicit “*Two-way contract” footnote identify RayJ Dennis, Keshon Gilbert, and Jalen Wilson as two-way players; the remaining rostered players were unstarred [4]. The training-camp list is preliminary, not the final current roster: for example, Isaac McKneely appeared on that list but is absent from the live roster page. The live page, not the older camp list, is used for roster membership and current jersey/position display.

| Order | Player | Jersey | Position | Classification |
|---:|---|---:|---|---|
| 1 | Nickeil Alexander-Walker | 7 | Guard | Standard |
| 2 | Dyson Daniels | 5 | Guard | Standard |
| 3 | RayJ Dennis | 10 | Guard | Two-way |
| 4 | Luguentz Dort | 0 | Guard | Standard |
| 5 | Zuby Ejiofor | 20 | Forward | Standard |
| 6 | Dorian Finney-Smith | 8 | Forward | Standard |
| 7 | Kingston Flemings | 4 | Guard | Standard |
| 8 | Keshon Gilbert | 00 | Guard | Two-way |
| 9 | Mouhamed Gueye | 18 | Forward | Standard |
| 10 | Jalen Johnson | 1 | Forward | Standard |
| 11 | Corey Kispert | 24 | Forward | Standard |
| 12 | Jock Landale | 31 | Center | Standard |
| 13 | CJ McCollum | 3 | Guard | Standard |
| 14 | Asa Newell | 14 | Forward | Standard |
| 15 | Onyeka Okongwu | 17 | Forward-Center | Standard |
| 16 | Henri Veesaar | 13 | Center | Standard |
| 17 | Aaron Wiggins | 2 | Guard | Standard |
| 18 | Jalen Wilson | 22 | Forward | Two-way |

**Completeness and interpretation.** `roster_complete=true` for the current official roster listing retrieved on 2026-10-25. The page provides no explicit standard/two-way labels or publication timestamp; two-way status is inferred from the official camp announcement’s asterisk notation and footnote. The 2026–27 NBA preview contains projected lineup/options language, which is not used to designate starters; the list above preserves the roster page’s order only. Jerseys and positions reflect the live official roster page even where they differ from the earlier camp announcement.

## References

[1]: https://www.nba.com/hawks/roster "Official NBA Team Roster - Atlanta Hawks"
[2]: https://www.nba.com/hawks/check-out-the-team "Get to Know the 2026 - 27 Hawks"
[3]: https://www.nba.com/news/2026-27-season-preview-atl "2026-27 Season Preview: Atlanta Hawks"
[4]: https://hawks.com/news/atlanta-hawks-announce-2026-training-camp-roster "Atlanta Hawks Announce 2026 Training Camp Roster"
