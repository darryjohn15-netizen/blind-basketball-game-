# Detroit Pistons 2026–27 roster audit

**As of / retrieved:** 2026-10-25. The supplied candidate page is the NBA’s Detroit Pistons team roster, and the NBA’s 2026–27 opening-season announcement identifies Detroit as one of the teams whose rosters were set for the season. The roster page itself does not show a season label in its extracted content, so the season identification is cross-checked against the league’s 2026–27 announcement and current 2026–27 team coverage.[1][2]

The NBA roster page lists player names, positions and jersey numbers. It also still displays John Ukomadu and Brice Williams, but a Detroit-area report published October 18 says the team announced it waived both on October 17, and gives the anticipated opening-night roster as 15 standard players and three two-way players. Accordingly, those two stale page entries are excluded. The same report lists the opening-night roster; the NBA G League’s current 2026–27 two-way tracker independently confirms Detroit’s three two-way players: Elijah Harkless, Isaac Jones and Ugonna Onyenso.[3][4]

The roster below follows the order of current players on the official roster page after removing the two reported waivers. It is roster order only, not a claim about starters. Jersey numbers and positions are included only as shown on the official roster page. On the evidence available as of the retrieval date, the combined official page and reported final cuts support a complete opening roster of 15 standard and three two-way players.

## Evidence

[1]: https://www.nba.com/pistons/roster "Roster | Detroit Pistons"  
[2]: https://www.nba.com/news/nba-rosters-set-for-2026-27-regular-season "NBA rosters set for 2026-27 regular season"  
[3]: https://www.mlive.com/pistons/2026/10/pistons-make-two-cuts-to-roster-following-final-preseason-game.html "Pistons make two cuts to roster following final preseason game"  
[4]: https://gleague.nba.com/twowayplayers "Two-Way Tracker: NBA Players Signed to Two-Way Contracts"
