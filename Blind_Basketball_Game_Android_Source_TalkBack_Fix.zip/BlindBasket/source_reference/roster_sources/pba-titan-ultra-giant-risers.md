# Titan Ultra Giant Risers (PBA) — roster source audit

**As-of / retrieval date:** 2026-10-25. **Season requested:** PBA Season 50 Governors’ Cup (2026).

The supplied official PBA page is titled **TITAN ULTRA GIANT RISERS** and its team section is labeled **Team Roster**. It lists the 18 players below with jersey numbers and positions. Its conference totals show 12 games. The official PBA’s Oct. 16 preview identifies Titan Ultra’s Governors’ Cup campaign as ending the following day with a 3–9 record; the official Oct. 17 report confirms that final game and names Titan players who appeared. These details are consistent with the team page reflecting the 2026 Governors’ Cup rather than an unrelated team or old season. [1] [2] [3]

| Roster order | Player | Jersey | Position |
|---:|---|---:|---|
| 1 | John Anthony Amores | 13 | SF |
| 2 | Jerrick Balanza | 7 | SF |
| 3 | Tirrell Dwayne Brown II | 32 | PF |
| 4 | King Danielle Caralipio | 27 | SF |
| 5 | Damie Cuntapay | 10 | C |
| 6 | Ralph Jeffrey Deles | 28 | SG |
| 7 | Aristotle Dionisio | 57 | PF |
| 8 | Ryan Roose Garcia | 1 | PG |
| 9 | Alejandrino Antonio Iñigo | 26 | PG |
| 10 | Marc Paolo Javillonar | 9 | PF |
| 11 | Joshua Eugene Munzon | 24 | SF |
| 12 | Mark Denver Omega | 23 | PF |
| 13 | Von Rolfe Pessumal | 19 | SG |
| 14 | John Bryan Sajonia | 4 | SG |
| 15 | Shej Roi Sumang | 12 | PG |
| 16 | Renato Ular | 5 | C |
| 17 | Denzel Jansen Wong | 8 | PG |
| 18 | Fran Louie Yu | 3 | PG |

**Completeness:** Not conclusively verifiable (`roster_complete=false`). The official team roster page has no publication or update date and does not itself label the roster “Season 50 Governors’ Cup.” Although its 12-game conference figures align with the contemporaneous Governors’ Cup reporting, the available official sources do not establish that its displayed player list is the complete registered roster as of 2026-10-25. The Oct. 16 preview also discusses Cade Flores as a possible return if recovered, without establishing that he was on the active registered roster. Accordingly, the list above includes only names actually displayed on the official team roster page; do not infer starters from its order. Jersey numbers and positions are copied only where displayed there.

## References

[1]: https://www.pba.ph/teams/titan-ultra-giant-risers "Titan Ultra Giant Risers — PBA team page"
[2]: https://www.pba.ph/news/terrafirma-titan-ultra-look-to-end-campaign-on-winning-note "Terrafirma, Titan Ultra look to end campaign on winning note — PBA, Oct. 16, 2026"
[3]: https://www.pba.ph/news/terrafirma-dumps-titan-ultra-ends-campaign-on-high-note "Terrafirma dumps Titan Ultra, ends campaign on high note — PBA, Oct. 17, 2026"
