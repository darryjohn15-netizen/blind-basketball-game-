# San Antonio Spurs roster audit

**League/team:** NBA — San Antonio Spurs (team ID 1610612759)  
**Season:** 2026–27  
**Retrieved/as of:** 2026-10-25

The candidate page is the official San Antonio Spurs roster page, but it does not identify a season or last-updated date. I verified the team and season against the NBA Stats `CommonTeamRoster` endpoint queried with `TeamID=1610612759` and `Season=2026-27`; its response identifies those parameters and returns 17 players, with jersey number and position for each. The official NBA schedule announcement independently confirms that San Antonio’s current season is 2026–27 and began October 20, 2026. [1] [2] [4]

The NBA Stats roster marks three players with `SUPPLEMENTAL_STATUS=1`; the NBA G League’s 2026–27 Two-Way Tracker independently lists those same Spurs as two-way players. I classify the remaining 14 roster-feed players as standard. [2] [3]

The candidate team roster page also displayed Taelon Peter, Terry Taylor, Jon Elmore, and Malik Williams, but those four do not appear in the season-specific NBA Stats roster response. Because the page has no season label and conflicts with the explicit 2026–27 feed, I have not counted those additional entries as verified current NBA roster players. The names below follow NBA Stats roster order, not a starters order. On this evidence, the season-specific official roster is complete for the as-of date.

## Verified roster

| Player | Jersey | Position | Classification |
|---|---:|---|---|
| Jordan McLaughlin | 0 | G | Standard |
| Victor Wembanyama | 1 | F-C | Standard |
| Dylan Harper | 2 | G | Standard |
| Keldon Johnson | 3 | F-G | Standard |
| De'Aaron Fox | 4 | G | Standard |
| Stephon Castle | 5 | G | Standard |
| Luke Kornet | 7 | C-F | Standard |
| Tarris Reed Jr. | 10 | C | Standard |
| Carter Bryant | 11 | F | Standard |
| Maliq Brown | 15 | F | Two-way |
| Ja'Kobi Gillespie | 17 | G | Two-way |
| Jayden Quaintance | 22 | F | Standard |
| Tobias Harris | 23 | F | Standard |
| Devin Vassell | 24 | G-F | Standard |
| David Jones Garcia | 25 | G | Two-way |
| Julian Champagnie | 30 | F | Standard |
| Harrison Barnes | 40 | F | Standard |

## References

[1]: https://www.nba.com/spurs/roster "Roster | San Antonio Spurs"
[2]: https://stats.nba.com/stats/commonteamroster?LeagueID=00&Season=2026-27&TeamID=1610612759 "NBA Stats CommonTeamRoster, San Antonio Spurs, 2026-27"
[3]: https://gleague.nba.com/twowayplayers "Two-Way Tracker: NBA Players Signed to Two-Way Contracts"
[4]: https://www.nba.com/spurs/news/san-antonio-spurs-announce-2026-27-season-schedule "San Antonio Spurs Announce 2026-27 Season Schedule"
