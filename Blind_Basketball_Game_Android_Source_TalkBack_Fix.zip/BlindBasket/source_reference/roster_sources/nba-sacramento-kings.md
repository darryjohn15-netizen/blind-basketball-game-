# Sacramento Kings roster audit — 2026–27

**As of:** 2026-10-25 (retrieved 2026-10-25). **Team/season verification:** the candidate page is the official Sacramento Kings roster page, and the official Kings opening-night announcement explicitly identifies the roster as 2026–27.[1][2]

The official opening-night announcement lists 16 players and marks Leaky Black and Jonathan Mogbo with an asterisk, defined as a two-way contract.[2] The Kings' official transaction notice says Adam Flagler was waived on October 19 and reports a Sean Pedulla two-way signing on October 23.[3] Accordingly, the supported current names are the 16 opening-night players other than waived Flagler, plus Pedulla. Jersey numbers and positions below follow the opening-night list; Pedulla's position is given as guard in the transaction notice, and no jersey number was verified.[2][3] Names are presented in the opening-night announcement's roster order, with the later signing last; this is not a starters designation.

| Player | Jersey | Position | Classification |
|---|---:|---|---|
| Precious Achiuwa | 9 | F | Standard contract |
| Darius Acuff Jr. | 5 | G | Standard contract |
| Leaky Black | 19 | F | Two-way contract |
| Dylan Cardwell | 32 | C | Standard contract |
| Nique Clifford | 10 | G/F | Standard contract |
| De'Andre Hunter | 15 | F | Standard contract |
| Alex Karaban | 33 | F | Standard contract |
| Zach LaVine | 8 | G | Standard contract |
| Jonathan Mogbo | 22 | F | Two-way contract |
| Malik Monk | 0 | G | Standard contract |
| Keegan Murray | 13 | F | Standard contract |
| Daeqwon Plowden | 29 | G/F | Standard contract |
| Maxime Raynaud | 42 | C | Standard contract |
| Domantas Sabonis | 11 | C | Standard contract |
| Emanuel Sharp | 34 | G | Standard contract |
| Ben Simmons | 25 | G/F | Standard contract |
| Sean Pedulla | — | Guard | Two-way contract |

**Completeness limitation:** `roster_complete=false`. At retrieval, the official live roster page still showed Adam Flagler and did not show Sean Pedulla, despite the official waiver/signing transaction notice.[1][3] The dated opening-night list and later transaction support the names above, but no single official roster page refreshed after Pedulla's signing was available to independently confirm the entire roster as of October 25. The live page's listed jersey/position data is not treated as current evidence for Flagler's membership.

## References

[1]: https://www.nba.com/kings/roster "Sacramento Kings official roster page"
[2]: https://www.nba.com/kings/news/kings-announce-2026-27-opening-night-roster "Kings Announce 2026-27 Opening Night Roster"
[3]: https://kings.com/news/sacramento-kings-waive-adam-flagler "Sacramento Kings roster transactions: Adam Flagler waiver and Sean Pedulla signing"