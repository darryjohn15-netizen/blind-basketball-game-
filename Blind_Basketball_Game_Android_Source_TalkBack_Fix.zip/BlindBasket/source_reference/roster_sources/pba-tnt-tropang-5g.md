# TNT Tropang 5G — PBA Season 50 Governors’ Cup roster audit

**Retrieved:** 2026-10-25. The supplied candidate page identifies the team as **TNT TROPANG 5G** and exposes a 23-player roster with jersey numbers and positions, but does not identify a season or roster-effective date. The PBA standings and its October 24 report place TNT in the PBA Season 50 Governors’ Cup quarterfinals. The October 24 report says Rondae Hollis-Jefferson was activated in place of temporary import Nick Hornsby; October 13 coverage records RHJ playing for TNT. Accordingly, the response uses the team-page roster order and fields, excludes the displaced temporary imports Darius Days and Rahlir Hollis-Jefferson, and includes current import RHJ. The PBA team-filtered player directory also lists Avan Nava (#27, PG), who is absent from the team page; his current Governors’ Cup status is not independently established by a dated report, so roster completeness is **false** and the directory discrepancy is disclosed. The order is roster order, not a starters designation. [1] [2] [3] [4] [5]

## References

[1]: https://www.pba.ph/teams/tnt-tropang-5g "TNT Tropang 5G official team roster"
[2]: https://www.pba.ph/players?team=TNT "PBA Players directory filtered for TNT"
[3]: https://www.pba.ph/news/magnolia-tnt-top-seed-vs-sleeping-giant "Magnolia-TNT: Top seed vs sleeping giant"
[4]: https://www.pba.ph/news/jalalon-tallies-triple-double-as-tropang-5g-dump-giant-pandas "Jalalon tallies triple-double as Tropang 5G dump Giant Pandas"
[5]: https://www.pba.ph/standings "PBA standings"
