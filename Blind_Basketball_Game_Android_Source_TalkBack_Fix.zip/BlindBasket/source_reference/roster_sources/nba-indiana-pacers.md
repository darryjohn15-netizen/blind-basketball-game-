# Indiana Pacers 2026–27 roster audit

**As of / retrieved:** 2026-10-25. The official NBA Pacers roster page identifies the team as the Indiana Pacers and lists 17 players with jersey numbers and positions. The official schedule page explicitly displays the 2026–27 season; the official season-opener preview also identifies the Pacers’ 2026–27 opener. I use the live roster page for player order and listed details, not as a starters list. [1] [2] [3]

The roster page order is: Tyrese Haliburton (#0, Guard; standard); Obi Toppin (#1, Forward; standard); Andrew Nembhard (#2, Guard-Forward; standard); Braden Smith (#3, Guard; two-way); Jarace Walker (#5, Forward; standard); T.J. McConnell (#9, Guard; standard); Kelly Oubre Jr. (#10, Forward-Guard; standard); Johnny Furphy (#12, Guard; standard); Jalen Slawson (#18, Forward; two-way); Larry Nance Jr. (#22, Forward-Center; standard); Aaron Nesmith (#23, Guard-Forward; standard); Kobe Brown (#24, Forward; standard); Ben Sheppard (#26, Guard; standard); Quenton Jackson (#29, Guard; standard); Jay Huff (#32, Center; standard); Ivica Zubac (#40, Center; standard); Pascal Siakam (#43, Forward; standard). Listed numbers and positions are from [1]. Pacers-affiliate announcements confirm two-way contracts for Smith and Slawson. [4] [5]

**Completeness and caveat:** `roster_complete=true` for the official current team roster page as retrieved on 2026-10-25. The roster page itself does not display a season selector or contract-type labels for every player; the 2026–27 attribution is cross-checked against the official schedule and season-opener preview. The two two-way labels are directly confirmed by official announcements; the other 15 players are treated as standard roster players by exclusion from the 17-player roster and the two confirmed two-way slots. The page’s order is reported only as roster order, not as a ranking or confirmation of starters.

## Sources

[1]: https://www.nba.com/pacers/roster "Roster | Indiana Pacers"
[2]: https://www.nba.com/pacers/schedule "Schedule | Indiana Pacers"
[3]: https://pacers.com/news/preview-pacers-pelicans-261021 "Pacers at Pelicans: Season Opener Preview"
[4]: https://noblesville.gleague.nba.com/news/braden-smith-signs-two-way-contract-with-indiana-pacers "Braden Smith Signs Two-Way Contract With Indiana Pacers"
[5]: https://noblesville.gleague.nba.com/news/jalen-slawson-signs-two-way-contract-with-indiana-pacers "Jalen Slawson Signs Two-Way Contract With Indiana Pacers"
