# Macau Giant Pandas (PBA) — Season 50 Governors’ Cup roster audit

**As of / retrieved:** 2026-10-25. The requested candidate is the official PBA **MACAU GIANT PANDAS** team page. It confirms the exact team identity and displays a team roster with jersey numbers and positions, but it is not season-dated and contains players later reported to have left during the conference. It therefore cannot establish a complete current roster on its own. [1] [2]

The newest official PBA game report located is dated **2026-10-16**, the Macau–Converge game that closed Macau’s Governors’ Cup campaign. Its Macau box score names Lam, Lopez, Chao, Sun, Liu, Chen, Zhang, Lu, and Zhu; Macau’s final-game and 2–10 status are corroborated by contemporaneous reporting. The official PBA report dated 2026-10-13 also records a Macau box score including Lao, but he is not in the final-game box score, so he is not included as a final-game-verified player here. [3] [4] [5]

For the eight final-game players whose identities match uniquely to the official team page, the page’s displayed jersey number and position are recorded below. The final-game report identifies one additional player only as **“Zhang”**; the official team page lists two different Zhang entries, so the specific player and corresponding number/position cannot be verified and are left unresolved rather than guessed. [1] [3]

| Supported final-game name | Jersey | Position |
|---|---:|---|
| Kobey Ketavong Lam | 22 | SG |
| Oscar Lopez Jr. | 24 | PF |
| Xingzhao Chao | 0 | PG |
| Meng Sun | 25 | PF |
| Xucheng Liu | 6 | C |
| Li-hsing Chen | 77 | SF |
| Zijie Lu | 28 | C |
| Zhaojing Zhu | 1 | SF |
| Zhang (first name unresolved) |  |  |

**Completeness limitation:** roster completeness is **not verified**. The team page is undated and stale: ESPN reported that De’Vondre Perry, Damian Chongqui, Ramon Cao, and Jenning Leung left during the break, while Oscar Lopez replaced Perry. The latest official game box score is evidence of players in Macau’s last game, not a dated formal roster register; it does not establish a complete post-campaign roster as of 2026-10-25. [1] [2] [3] [6]

## References

[1]: https://www.pba.ph/teams/macau-giant-pandas "Macau Giant Pandas - PBA Teams"
[2]: https://www.pba.ph/news/bolts-dyip-giant-pandas-banking-on-new-imports "Bolts, Dyip, Giant Pandas banking on new imports"
[3]: https://www.pba.ph/news/clark-jgdl-shine-as-converge-dismantle-macau-for-fourth-straight-win "Clark, JGDL shine as Converge dismantle Macau for fourth straight win"
[4]: https://www.pba.ph/news/jalalon-tallies-triple-double-as-tropang-5g-dump-giant-pandas "Jalalon tallies triple-double as Tropang 5G dump Giant Pandas"
[5]: https://sports.inquirer.net/701851/pba-converge-sends-macau-off-with-54-point-beating "PBA: Converge sends Macau off with 54-point beating"
[6]: https://www.espn.com/basketball/pba/story/_/id/50130095/pba-governors-cup-macau-giant-pandas-pba-stint-hits-new-low-historic-60-point-loss "Macau Giant Pandas' PBA stint hits new low with historic 60-point loss"
