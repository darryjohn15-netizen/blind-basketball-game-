# Magnolia Chicken Timplados Hotshots — roster audit

**As of / retrieved:** 2026-10-25. **League/season:** Philippine Basketball Association (PBA), Season 50 Governors’ Cup (2026).

The supplied official team page is headed **MAGNOLIA CHICKEN TIMPLADOS HOTSHOTS**, confirming the exact team, and its Team Roster section lists the players below with jersey numbers and positions. The page’s roster block is not explicitly dated or labeled with a conference, so I cross-checked it against current official league coverage: the October 21, 2026 Governors’ Cup game report identifies the current Magnolia squad, states Zavier Lucero was absent, and lists 14 Magnolia players in its box score. That box score matches the roster-page names other than Lucero (explicitly absent) and Paul John Lee (not in that game’s box score). The October 24 official preview confirms Magnolia’s Season 50 Governors’ Cup quarterfinal context. On balance, the live official roster listing and current game evidence support a complete roster list; this is roster order, **not** a starter designation. [1] [2] [3]

## Official team-page roster order

- Pedro Alfaro III — #17, PG
- Yukien Andrada — #21, SF
- Andy Mark Barroca — #14, PG
- Kenyon Joseph Buffen — #1, SF; current league coverage identifies Buffen as Magnolia’s import. [2]
- Rome Adler Dela Rosa — #19, SF
- Vince John Gabriel Gomez — #13, PG
- Javier Joaquin Gomez de Liano — #2, SG
- Clifford Jopia — #23, C
- Christopher Tomas Koon — #6, PF
- James Laput — #42, C
- Jerom Lastimosa — #30, PG
- Paul John Lee — #3, SG
- Zavier Lucero — #22, SF
- Ian Paul Sangalang — #10, C
- Juan Paolo Taha — #0, SG
- Rafael Lorenzo Verano — #41, SF

All names, jersey numbers, and positions above follow the official team page. [1]

## References

[1]: https://www.pba.ph/teams/magnolia-chicken-timplados-hotshots "MAGNOLIA CHICKEN TIMPLADOS HOTSHOTS - Teams"
[2]: https://pba.ph/news/magnolia-beats-rain-or-shine-to-clinch-group-b-top-spot "Magnolia beats Rain or Shine to clinch Group B top spot"
[3]: https://pba.ph/news/magnolia-tnt-top-seed-vs-sleeping-giant "Magnolia-TNT: Top seed vs sleeping giant"
