# Portland Trail Blazers — 2026–27 roster audit

**As of / retrieved:** October 25, 2026. The official team announcement explicitly labels its list “Trail Blazers 2026-27 Training Camp Roster,” identifying the franchise and season. It gives names, jersey numbers, and listed positions, and marks Jayson Kent, John Tonje, and Chris Youngblood as two-way players [1]. On October 17, the team announced Jeremy Sochan’s waiver and stated that the roster stood at 17, including three two-way players [2]. The current 2026–27 Basketball-Reference team roster independently lists the same 17 players after Sochan’s release [3]. I preserve the order of the official camp list, omitting the waived player; this is roster order, not a starter designation.

| No. | Player | Position | Classification |
|---|---|---|---|
| 8 | Deni Avdija | F | Standard |
| 33 | Toumani Camara | F | Standard |
| 10 | Branden Carlson | C | Standard |
| 91 | Sidy Cissoko | F | Standard |
| 23 | Donovan Clingan | C | Standard |
| 00 | Scoot Henderson | G | Standard |
| 5 | Jrue Holiday | G | Standard |
| 29 | Jayson Kent | F | Two-way |
| 27 | Vit Krejčí | F | Standard |
| 0 | Damian Lillard | G | Standard |
| 1 | Ja Morant | G | Standard |
| 9 | Micah Potter | F/C | Standard |
| 17 | Shaedon Sharpe | G | Standard |
| 2 | John Tonje | G | Two-way |
| 35 | Robert Williams III | C | Standard |
| 16 | Yang Hansen | C | Standard |
| 11 | Chris Youngblood | G | Two-way |

**Completeness and limitation.** The official team sources establish the season, player details, October 17 roster count, three two-way contracts, and Sochan’s removal. The live secondary roster corroborates the resulting 17 names as the season begins. The requested NBA.com candidate page (`nba.com/trailblazers/roster`) returned “Content Unavailable” on retrieval, and the alternate NBA team-branded roster route exposed only staff in its extracted text; neither provided a usable official current player roster [4] [5]. Thus, completeness is based on the dated team releases reconciled with the contemporaneous live roster listing, not a successfully loaded NBA.com player roster.

## References

[1]: https://blazers.com/news/trail-blazers-announce-2026-27-training-camp-roster "Trail Blazers Announce 2026-27 Training Camp Roster"
[2]: https://blazers.com/news/trail-blazerswaivejeremy-sochan "Trail Blazers Waive Jeremy Sochan"
[3]: https://www.basketball-reference.com/teams/POR/2027.html "2026-27 Portland Trail Blazers Roster and Stats"
[4]: https://www.nba.com/trailblazers/roster "Portland Trail Blazers roster page supplied for verification"
[5]: https://www.nba.com/blazers/roster "Portland Trail Blazers roster page"
