# Washington Wizards roster source audit — 2026–27

**As of / retrieved:** 2026-10-25. The candidate page is the NBA’s official Washington Wizards team roster page. Its team identity is confirmed by the Washington Wizards site branding and team route; the current-season context is supported by the team’s October 19, 2026, 2026–27 opening-night release. That release says the opening-night roster has 18 players, including three two-way players, but does not name them. [1] [2]

The official NBA roster page lists jersey numbers and positions for the 18 names below, but also lists Trevor Keels, Skal Labissiere, and Chris Livingston. The current ESPN roster page lists 18 names and omits those three. Because the official player page and the October release do not provide a name-by-name list reconciling this discrepancy, the 18 ESPN-listed names are reported as supported current names, but **roster completeness is not fully verified**. The official team announcement confirms three two-way contracts but does not identify those players; individual standard/two-way classifications are therefore left blank rather than inferred. [1] [2] [3]

Jersey numbers and positions below are transcribed from the official NBA roster page; ESPN independently corroborates the current 18-name list. Roster order is source order only and does not indicate starters. [1] [3]

## Supported current names

| Player | Jersey | Position | Contract classification |
|---|---:|---|---|
| Deandre Ayton | 8 | Center | |
| Reece Beekman | 26 | Guard | |
| Bub Carrington | 7 | Guard | |
| Justin Champagnie | 9 | Guard-Forward | |
| Bilal Coulibaly | 0 | Guard | |
| Anthony Davis | 23 | Forward-Center | |
| AJ Dybantsa | 4 | Forward | |
| Kyshawn George | 18 | Forward | |
| Anthony Gill | 16 | Forward | |
| Tre Johnson | 12 | Guard | |
| Tre Mann | 1 | Guard | |
| Khris Middleton | 22 | Forward | |
| Felix Okpara | 34 | Center | |
| Will Riley | 27 | Forward | |
| Alex Sarr | 20 | Center | |
| Tristan Vukcevic | 00 | Forward | |
| Jamir Watkins | 5 | Forward | |
| Trae Young | 3 | Guard | |

## References

[1]: https://www.nba.com/wizards/roster "Official NBA.com Washington Wizards roster"
[2]: https://www.nba.com/wizards/news/wizards-announce-2026-27-opening-night-roster "Wizards announce 2026-27 opening night roster, October 19, 2026"
[3]: https://www.espn.com/nba/team/roster/_/name/wsh/washington-wizards "ESPN Washington Wizards roster"
