# Terrafirma Dyip — PBA Season 50 Governors’ Cup (2026)

**Retrieved/as of:** 2026-10-25. The requested official team page identifies **TERRAFIRMA DYIP** and has a dedicated “Team Roster” section. Its current rendering lists 15 players in the order below, with jersey number and position for each. It also shows “Conference Average” values for listed players. The PBA’s official current statistics page includes Season 50 Governors’ Cup among its conference choices, while the official schedule places Terrafirma in an October 17, 2026 game; the official recap index identifies that game as the **PBA 50th Season Governors’ Cup**. Together these establish the current roster page’s team identity and the active-season context.[1][2][3][4]

| Roster order | Player | No. | Position |
|---:|---|---:|---|
| 1 | Benedict Adamos | 88 | C |
| 2 | Maverick Ahanmisi | 13 | PG |
| 3 | John Matthew Bravo | 26 | PF |
| 4 | Conrad Joey Catapusan | 9 | SF |
| 5 | Shaun Geoffrey Chiu | 18 | C |
| 6 | Joseph Emmanuel Eriobu | 23 | SF |
| 7 | Paul Garcia | 3 | PG |
| 8 | Ahmad Didat Hanapi | 30 | SG |
| 9 | Aljon Mariano | 10 | SF |
| 10 | Christopher Miller | 55 | PG |
| 11 | Brent Paraiso | 38 | SG |
| 12 | Justin Anthony Strings | 1 | PF |
| 13 | Juan Miguel Tiongson | 33 | PG |
| 14 | Shawn Michael Umali | 28 | C |
| 15 | Keith Zaldivar | 5 | C |

This is roster order, **not** a claim about starters. The first extraction of the official team URL returned an older, conflicting set of names and historical game data. I treated that rendering as stale and used the subsequent current page content, which contains the explicit roster and conference averages; the official stats page independently reflects the same names and current averages (for example, J. Strings and J. Tiongson).[1][2] No jersey or position has been inferred. The live official roster is treated as complete because it is the page’s current “Team Roster” list; PBA does not label the team page itself with the conference name, so the season linkage is established from contemporaneous official schedule/recap and conference-stat context rather than an explicit season heading on the roster page.[2][3][4]

## References

[1]: https://www.pba.ph/teams/terrafirma-dyip "Terrafirma Dyip official team page and roster"
[2]: https://pba.ph/stats "PBA official player statistics and conference selector"
[3]: https://www.pba.ph/schedule "PBA official schedule, October 2026"
[4]: https://www.pba.ph/recap?match=587 "PBA official recap, Terrafirma Dyip game on October 17, 2026"
