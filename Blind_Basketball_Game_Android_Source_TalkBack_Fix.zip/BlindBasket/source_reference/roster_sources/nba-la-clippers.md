# LA Clippers roster source audit

**Target:** LA Clippers (NBA), 2026–27 season. **As of / retrieved:** 2026-10-25.

The official Clippers Instagram post dated October 20 says “Your 2026-27 Clippers roster,” confirming the club and season, though its graphic does not provide a readable roster list.[4] The user-designated NBA roster page is the official Clippers page, but its fetched content does not state a season and its player list conflicts with the October 19 roster preview: it lists Blake Wesley, Jahmyl Telfort, and Yuki Kawamura, while omitting Cam Christie.[1][3] The club’s September 28 training-camp announcement is an earlier baseline, not proof of final roster membership.[2]

Accordingly, **roster_complete=false**. The 18 names below are the players named in the most recent full roster preview located (October 19); they are not represented as a fully verified official final roster. Names and the three two-way classifications are supported by that preview; positions and most jersey numbers are from the official camp announcement. Jalen Pickett’s jersey is left blank because the camp announcement says 21 while the current NBA page says 24. The source order below is roster order only, not a starters designation.[1][2][3]

- Bradley Beal — #3, G — standard
- Cam Christie — #24, G — two-way
- Gradey Dick — #9, G — standard
- Kris Dunn — #8, G — standard
- Darius Garland — #10, G — standard
- Rui Hachimura — #28, F — standard
- Brandon Ingram — #7, F — standard
- Isaiah Jackson — #23, F-C — standard
- Derrick Jones Jr. — #5, G-F — standard
- Brook Lopez — #11, C — standard
- Nick Martinelli — #12, F — two-way
- Baba Miller — #18, F — standard
- Jordan Miller — #22, G-F — standard
- Yanic Konan Niederhäuser — #14, C — standard
- Jalen Pickett — jersey not verified, G — two-way
- Kobe Sanders — #4, G-F — standard
- Max Strus — #31, G-F — standard
- Keaton Wagler — #1, G — standard

## References

[1]: https://www.ocregister.com/2026/10/19/clippers-season-preview-a-closer-look-at-the-2026-27-roster/ "Clippers season preview: A closer look at the 2026-27 roster"
[2]: https://clippers.com/news/la-clippers-announce-2026-27-training-camp-roster "LA Clippers announce 2026-27 training camp roster"
[3]: https://www.nba.com/clippers/roster "LA Clippers roster"
[4]: https://www.instagram.com/p/Deu0i7dhXV1/ "LA Clippers official roster post dated October 20, 2026"
