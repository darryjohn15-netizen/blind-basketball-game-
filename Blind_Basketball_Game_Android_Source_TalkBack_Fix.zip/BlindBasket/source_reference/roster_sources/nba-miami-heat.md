# Miami Heat roster audit — 2026–27

**As of / retrieved:** 2026-10-25. The supplied NBA.com candidate is the official Miami HEAT roster page and displays 17 players, with jersey numbers, positions, and three players explicitly tagged “Two-Way.” Its page does not itself print a season label or update timestamp. I verified team/season context against Miami’s official 2026–27 schedule and its October 6 announcement describing the event as showcasing the franchise’s 2026–27 roster; official October preseason coverage also names players from the current group. On that basis, the live roster page is treated as the current 2026–27 roster, not a prior-season roster. [1] [2] [3] [4]

The following is the order shown on the roster page, **not a starter designation**. “Standard” denotes players not marked Two-Way on that page.

| Roster order | Player | Jersey | Position | Classification |
|---:|---|---:|---|---|
| 1 | Bam Adebayo | 13 | Center-Forward | Standard |
| 2 | Giannis Antetokounmpo | 7 | Forward | Standard |
| 3 | Ryan Conwell | 4 | Guard | Standard |
| 4 | Tre Donaldson | 24 | Guard | Two-Way |
| 5 | Simone Fontecchio | 0 | Forward | Standard |
| 6 | Myron Gardner | 15 | Forward | Standard |
| 7 | Vladislav Goldin | 50 | Center | Two-Way |
| 8 | Tim Hardaway Jr. | 10 | Guard | Standard |
| 9 | Keshad Johnson | 16 | Forward | Two-Way |
| 10 | Nikola Jović | 5 | Forward | Standard |
| 11 | Pelle Larsson | 9 | Guard | Standard |
| 12 | Davion Mitchell | 2 | Guard | Standard |
| 13 | Bobby Portis Jr. | 95 | Forward | Standard |
| 14 | Nick Richards | 8 | Center | Standard |
| 15 | Dru Smith | 12 | Guard | Standard |
| 16 | Klay Thompson | 11 | Guard-Forward | Standard |
| 17 | Andrew Wiggins | 22 | Forward | Standard |

**Completeness:** `roster_complete=true` for the live official list retrieved on the stated as-of date. It lists 14 untagged roster entries plus three explicitly labeled Two-Way entries. Team announcements independently confirm the 2026–27 roster context; the Giannis Antetokounmpo/Bobby Portis Jr. acquisition notice confirms their Miami transaction and jersey numbers, and the club separately announced Tre Donaldson’s Two-Way contract. [1] [2] [3] [5] [6]

## References

[1]: https://www.nba.com/heat/roster "Roster - Miami HEAT"
[2]: https://heat.com/news/heat-announce-2026-27-regular-season-schedule "HEAT Announce 2026-27 Regular Season Schedule"
[3]: https://heat.com/news/heat-to-host-annual-red-white-pink-game-at-kaseya-center "HEAT Red, White & Pink Game at Kaseya Center"
[4]: https://heat.com/news/coups-takeaways-conwell-gardner-larsson-jovic-clutch-minnesota-preseason "Coup’s Takeaways: Conwell, Gardner, Larsson, Jović Clutch vs. Minnesota"
[5]: https://heat.com/news/heat-acquire-giannis-antetokounmpo-and-bobby-portis-jr "HEAT Acquire Giannis Antetokounmpo and Bobby Portis Jr."
[6]: https://heat.com/news/heat-sign-tre-donaldson-to-two-way-contract "Miami HEAT Sign Guard Tre Donaldson to Two-Way Contract"
