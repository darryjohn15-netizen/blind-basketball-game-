# New Orleans Pelicans — 2026–27 roster audit

**As of / retrieved:** 2026-10-25. The requested candidate page is the official New Orleans Pelicans team roster page. It currently lists 18 players; that player set matches the team’s dated announcement of its 2026–27 opening-night roster, published October 19, 2026. The announcement explicitly identifies the team, season, and opening-night roster, and marks Malik Dia, Jaron Pierre Jr., and Julian Reese as two-way players. I therefore treat the roster as complete as of retrieval; the current roster page itself does not display a season label. [1] [2]

The roster below follows the order in the official announcement, not a starter designation. Jersey numbers and positions are taken from its roster table. “Standard” means the player was not marked with the announcement’s two-way asterisk. [1]

- 41 — Saddiq Bey — F — Standard
- 8 — Malik Dia — F/C — Two-way
- 0 — Jeremiah Fears — G — Standard
- 14 — AJ Johnson — G — Standard
- 2 — Herb Jones — G/F — Standard
- 6 — DeAndre Jordan — C — Standard
- 24 — Bennedict Mathurin — G/F — Standard
- 17 — Karlo Matković — F/C — Standard
- 11 — Bryce McGowens — G — Standard
- 21 — Yves Missi — C — Standard
- 25 — Trey Murphy III — F — Standard
- 5 — Dejounte Murray — G — Standard
- 10 — Jaron Pierre Jr. — G — Two-way
- 3 — Jordan Poole — G — Standard
- 22 — Derik Queen — F/C — Standard
- 13 — Julian Reese — F — Two-way
- 9 — Trendon Watford — F — Standard
- 1 — Zion Williamson — F — Standard

## References

[1]: https://www.nba.com/pelicans/news/2026-27-opening-night-roster-pelicans-vs-pacers-nba-season "New Orleans Pelicans announce 2026-27 opening night roster"
[2]: https://www.nba.com/pelicans/roster "Roster | New Orleans Pelicans"
