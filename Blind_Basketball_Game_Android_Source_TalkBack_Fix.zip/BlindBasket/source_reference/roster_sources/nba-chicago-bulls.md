# Chicago Bulls roster source audit

**As of / retrieved:** 2026-10-25. **Target:** Chicago Bulls, NBA, 2026–27. The supplied NBA URL is the Chicago Bulls team roster page, and the official Bulls schedule explicitly labels its current schedule “2026-27”; the roster page itself does not display a season label. [1] [2]

The NBA roster page lists the 20 names below and displays the positions and numbers shown. The Bulls’ October 6 official announcement confirms Jordan Hawkins signed a two-way contract, and the NBA’s release says Chicago then had three two-way players: Tobe Awaka, Hawkins, and Jaylin Sellers. The Bulls’ October 21 team-hosted 2026–27 preview also names those three as two-ways. [1] [3] [4]

**Roster entries supported by the sources** (order follows the NBA roster page; not a starter ranking):

- Noa Essengue — No. 2, Forward; NBA roster page, contract classification not specified.
- Josh Giddey — No. 3, Guard; NBA roster page, contract classification not specified.
- Dailyn Swain — No. 5, Forward; NBA roster page, contract classification not specified.
- Orlando Robinson — No. 7, Center; NBA roster page, contract classification not specified.
- Buddy Hield — No. 8, Guard; NBA roster page, contract classification not specified.
- Caleb Wilson — No. 8, Forward; NBA roster page, contract classification not specified.
- Nic Claxton — No. 9, Center; NBA roster page, contract classification not specified.
- Drew Peterson — No. 9, Forward; NBA roster page, contract classification not specified.
- Brandon Boston — No. 11, Guard; NBA roster page, contract classification not specified.
- Leonard Miller — No. 11, Forward; NBA roster page, contract classification not specified.
- Zach Collins — No. 12, Forward-Center; NBA roster page, contract classification not specified.
- Matas Buzelis — No. 14, Forward; NBA roster page, contract classification not specified.
- Jalen Bridges — No. 15, Forward; NBA roster page, contract classification not specified.
- Norman Powell — No. 24, Guard; NBA roster page, contract classification not specified.
- Jalen Smith — No. 25, Forward-Center; NBA roster page, contract classification not specified.
- Tre Jones — No. 30, Guard; NBA roster page, contract classification not specified.
- Isaac Okoro — No. 35, Forward-Guard; NBA roster page, contract classification not specified.
- Patrick Williams — No. 44, Forward; NBA roster page, contract classification not specified.
- Tobe Awaka — number not listed, Forward; two-way, per NBA release.
- Jaylin Sellers — number and position not listed; two-way, per NBA release.
- Jordan Hawkins — number not listed here, Guard-Forward; two-way, per NBA release and team-hosted preview.

**Limitation:** `roster_complete=false`. The roster page does not state its season and does not list Hawkins, whom official October 2026 sources identify as a current two-way signing. It also lists Jalen Bridges as No. 15 while the NBA’s Hawkins signing release says Hawkins will wear No. 15. As a result, the complete 2026–27 roster and Hawkins’s current jersey assignment cannot be reconciled from these sources. Numbers or positions not shown by the NBA roster page are left unspecified above; the source releases establish contract class but do not supply all missing roster-page fields. The team-hosted season preview is expressly accompanied by a disclaimer that its contents were not reviewed or endorsed by the Bulls, so it is supplementary rather than controlling roster evidence. [1] [3] [4]

## References

[1]: https://www.nba.com/bulls/roster "Chicago Bulls Roster, NBA.com"
[2]: https://www.nba.com/bulls/schedule "Chicago Bulls Schedule 2026-27, NBA.com"
[3]: https://www.nba.com/news/chicago-bulls-sign-jordan-hawkins-to-two-way-contract "Chicago Bulls Sign Jordan Hawkins to Two-Way Contract, NBA.com"
[4]: https://bulls.com/news/get-to-know-the-2026-27-chicago-bulls "Get to Know the 2026-27 Chicago Bulls, Bulls.com"
