# Los Angeles Lakers — roster source audit

**League / season:** NBA, 2026–27. **As of / retrieved:** 2026-10-25.

The supplied [official Lakers roster page](https://www.nba.com/lakers/roster) does not provide a verifiable 2026–27 roster snapshot: its extracted roster still includes LeBron James and Deandre Ayton and is not labeled with the requested season. By contrast, the official [NBA Lakers schedule](https://www.nba.com/lakers/schedule) explicitly labels the 2026–27 season and lists games beginning October 23, confirming the team/season context, not the roster.

The current-season ESPN roster page identifies the Lakers as a 2026–27 roster, but its extracted text omits player names. The Fox Sports roster page supplies names and jerseys, but its heading still says 2025–26 and it includes Dalton Knecht; ESPN transaction search results report Knecht waived October 19, 2026. These records support a working list of 18 names after excluding Knecht, but do not amount to a clean, official post-cut roster publication. The names below should therefore be treated as supported candidates, not a certified complete roster. Current jersey numbers, positions, and standard/two-way classifications are left blank rather than carried over from potentially stale pages.

**Supported player names (roster order not starter status):** Cameron Carr; Luka Dončić; Quentin Grimes; Jaden Hardy; Bronny James; Chris Mañon; Austin Reaves; Collin Sexton; Matisse Thybulle; Arthur Kaluma; Jake LaRavia; Sandro Mamukelashvili; AK Okereke; Adou Thiero; Jarred Vanderbilt; Ziaire Williams; Walker Kessler; Kevon Looney.

The official NBA [2026 offseason deals roundup](https://www.nba.com/news/nba-offseason-deals-2026) corroborates several major Lakers additions and departures. The Lakers’ official [2026 Summer League announcement](https://lakers.com/news/lakers-announce-2026-summer-league-schedule-and-roster) confirms several names as summer-league participants, but does not establish their regular-season contract status. ESPN’s [2026–27 preview](https://www.espn.com/nba/story/_/id/50061973/nba-preview-2026-27-bobby-marks-training-camp-guide-duren-pistons-lebron-76ers-30-teams) says the team had 16 guaranteed contracts and three two-way contracts at training-camp preview time, before subsequent cuts; it is not a final roster.

## References

[1]: https://www.nba.com/lakers/roster "Los Angeles Lakers Official Roster"
[2]: https://www.nba.com/lakers/schedule "Los Angeles Lakers Schedule 2026–27"
[3]: https://www.espn.com/nba/team/roster/_/name/lal/los-angeles-lakers "Los Angeles Lakers Roster, ESPN"
[4]: https://www.foxsports.com/nba/los-angeles-lakers-team-roster "Los Angeles Lakers Team Roster, FOX Sports"
[5]: https://www.espn.com/nba/team/transactions/_/name/lal/los-angeles-lakers "Los Angeles Lakers Transactions, ESPN"
[6]: https://www.nba.com/news/nba-offseason-deals-2026 "NBA Offseason Deals 2026"
[7]: https://lakers.com/news/lakers-announce-2026-summer-league-schedule-and-roster "Los Angeles Lakers 2026 Summer League"
[8]: https://www.espn.com/nba/story/_/id/50061973/nba-preview-2026-27-bobby-marks-training-camp-guide-duren-pistons-lebron-76ers-30-teams "NBA Preview 2026–27: Training Camp Guide"
