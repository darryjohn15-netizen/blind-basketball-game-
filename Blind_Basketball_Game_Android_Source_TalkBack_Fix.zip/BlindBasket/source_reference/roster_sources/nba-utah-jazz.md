# Utah Jazz roster audit — 2026–27

**As of / retrieved:** 2026-10-25. **Team and season:** Utah Jazz, NBA, 2026–27. The supplied candidate URL is the official Utah Jazz team roster page. Its page title is “Roster,” so it does not itself specify a season; the Jazz’s September 26 announcement explicitly labels its 20-player camp list as the 2026–27 roster, confirming the team/season context.[1] [2]

The live roster page is not a reliable complete snapshot: it still lists Jonas Aidoo, Tamar Bates, and Blake Hinson after official waiver announcements, and it omits Tony Bradley despite the Jazz claiming him off waivers and naming him as a recent signing in its season-opening preview.[1] [3] [4] [6] [8] The Jazz also waived Jaelen House on October 1.[5] The list below therefore excludes players with documented waivers, includes Bradley based on the later claim and team preview, and is **not certified complete**. The roster page also lists Terrell Brown Jr., but he does not appear on the dated 20-player camp roster and I found no current official transaction or other corroboration confirming his roster status; he is not counted as verified here.[1] [2]

The following names are supported as current rostered players by the dated camp list and subsequent official transaction evidence, with Bradley added from his later claim. The NBA roster page supplies the jersey numbers and position labels where displayed. The order follows that page where possible and is roster order only, not a statement about starters.[1] [2] [6] [7] [8]

- Kyle Filipowski — #2, Center; standard
- Keyonte George — #3, Guard; standard
- Josh Green — #5, Guard; standard
- Isaiah Collier — #8, Guard; standard
- Svi Mykhailiuk — #10, Guard-Forward; standard
- Jaxson Hayes — #11, Center-Forward; standard
- Ace Bailey — #19, Forward; standard
- Jaren Jackson Jr. — #20, Forward-Center; standard
- Josh Okogie — #21, Guard; standard
- Darryn Peterson — #22, Guard; standard
- Trey Alexander — #23, Guard; two-way
- Lauri Markkanen — #23, Forward-Center; standard
- Brice Sensabaugh — #28, Forward; standard
- Jusuf Nurkić — #30, Center; standard
- Mo Bamba — #44, Center; standard
- Harrison Ingram — jersey number unresolved; Forward; two-way
- Tony Bradley — jersey number unavailable; Center; standard

The October 24 Jazz game preview explicitly identifies Trey Alexander and Harrison Ingram as “G League - Two-Way.”[7] Ingram’s jersey is left blank because the training-camp table shows #00 while the live roster page shows #55; the current number could not be reconciled from the available official evidence.[1] [2]

**Limitation:** `roster_complete=false`. As of October 25, no single current official Jazz/NBA source verified a complete post-waiver roster. The discrepancy between the live roster page, the dated camp list, and subsequent personnel moves leaves Brown’s status and the completeness of the remaining list unresolved. Jersey/position data are omitted wherever an official current value could not be established.

## References

[1]: https://www.nba.com/jazz/roster "Roster | Utah Jazz"
[2]: https://www.nba.com/jazz/news/utah-jazz-announce-2026-27-training-camp-roster "Utah Jazz Announce 2026-27 Training Camp Roster"
[3]: https://utahjazz.com/news/utah-jazz-waive-aidoo-and-bates "Utah Jazz Waive Aidoo and Bates"
[4]: https://utahjazz.com/news/utah-jazz-waive-blake-hinson "Utah Jazz Waive Blake Hinson"
[5]: https://www.nba.com/jazz/news/utah-jazz-waive-jaelen-house "Utah Jazz Waive Jaelen House"
[6]: https://utahjazz.com/news/utah-jazz-claim-tony-bradley-off-waivers "Utah Jazz Claim Tony Bradley Off Waivers"
[7]: https://utahjazz.com/news/preview-utah-jazz-continue-homestand-against-los-angeles-lakers-2 "Preview: Utah Jazz Continue Homestand Against Los Angeles Lakers"
[8]: https://utahjazz.com/news/preview-utah-jazz-begin-2026-27-season-against-the-memphis-grizzlies "Preview: Utah Jazz Begin 2026-27 Season Against the Memphis Grizzlies"
