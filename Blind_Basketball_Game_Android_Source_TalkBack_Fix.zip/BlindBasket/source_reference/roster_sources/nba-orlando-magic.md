# Orlando Magic roster audit

**As of / retrieved:** 2026-10-25. **Team and season:** The candidate page is the official Orlando Magic roster page, but it has only a generic “Roster” heading and does not identify a season. The separate official team release explicitly labels its list “2026-27 ORLANDO MAGIC ROSTER” and says the team had 17 players, including three two-way players, ahead of its October 21 season opener. [1] [2]

The official October 16 release supports the following 17 names, jersey numbers, positions, and contract classifications. Its order is reproduced as roster order, not as a starter designation. [2]

| No. | Player | Pos. | Classification |
|---:|---|---|---|
| 5 | Paolo Banchero | F | Standard |
| 3 | Desmond Bane | G-F | Standard |
| 35 | Goga Bitadze | C | Standard |
| 0 | Anthony Black | G | Standard |
| 8 | Jamal Cain | F | Standard |
| 2 | Jevon Carter | G | Standard |
| 34 | Wendell Carter Jr. | C | Standard |
| 14 | Colin Castleton | C | Two-way |
| 23 | Tristan da Silva | F | Standard |
| 1 | Jonathan Isaac | F | Standard |
| 30 | Alex Morales | F | Two-way |
| 25 | Izaiyah Nelson | C | Two-way |
| 93 | Noah Penda | F | Standard |
| 11 | Jase Richardson | G | Standard |
| 4 | Jalen Suggs | G | Standard |
| 9 | Nikola Vučević | C | Standard |
| 22 | Franz Wagner | F | Standard |

The official NBA G League two-way tracker independently lists Colin Castleton, Alex Morales, and Izaiyah Nelson as Orlando Magic two-way players for 2026–27. [3]

**Completeness limitation:** `roster_complete` is set to `false`. The candidate NBA roster page, checked on the retrieval date, still displays Malaki Branham, JD Davison, and Kevin Knox II; the October 16 team release explicitly says all three were waived that day. [1] [2] The candidate page also does not state a season. The October 16 release is an authoritative 2026–27 roster snapshot, but I found no later official full-roster list confirming that all 17 remained rostered on October 25. Therefore these are the supported names from the latest dated full official roster located, not a claim that the page itself accurately reflects the roster on October 25.

## References

[1]: https://www.nba.com/magic/roster "Orlando Magic Roster"
[2]: https://orlandomagic.com/news/orlando-magic-waive-malaki-branham-jd-davison-and-kevin-knox-ii-20261016 "Orlando Magic Waive Malaki Branham, JD Davison and Kevin Knox II"
[3]: https://gleague.nba.com/twowayplayers "Two-Way Tracker: NBA Players Signed to Two-Way Contracts"
