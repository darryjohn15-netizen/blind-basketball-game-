# Blackwater Bossing roster audit

**As of / retrieved:** 2026-10-25. **Team / competition:** BLACKWATER BOSSING, PBA Season 50 Governors’ Cup (2026).

The candidate page is the PBA’s official team page headed “BLACKWATER BOSSING.” Its Team Roster section lists 17 player entries, with a jersey number and position for each. The page does not itself label the roster by season or display an “as of” date. Its conference-stat section and the league’s October 23 recap indicate contemporary conference activity; the latter calls the matchup the close of the Governors’ Cup elimination round and supplies Blackwater’s game box score. The October 16 PBA preview explicitly identifies that competition as the PBA Season 50 Governors’ Cup. I therefore treat the current official team-page listing as the newest roster, while noting its season-label limitation. [1] [2] [3]

The official team-page roster, in displayed order (not a starter order), is: Cyrus John Austria (17, SG); Sedrick Barefield (2, SG); Kentrell Debarrus Barkley (24, SF); Jack Cruz-Dumont (12, SF); Christian David (25, SF); Nick Demusis (7, SF); Michael Vincent DiGregorio (3, SG); Richard Escoto (23, PF); Regile Kent Ilagan (16, PG); John Troy Mallilin (14, SF); Jonathan Jed Mendoza (26, PG); Kirell Brahndon Montalbo (15, SG); David Murrell (4, SF); Dalph Adem Panopio (9, PG); James Ryan Sena (31, C); Abu Jahal Tratter (1, C); James Paul Una (19, PF). These spellings, numbers, and positions follow the official page. [1]

The October 23 recap lists 15 Blackwater players in the game line, including Barkley and Barefield; it corroborates recent participation but is not used as a replacement for the roster list. Nick Demusis’s July 21 PBA report confirms he earned a Governors’ Cup roster spot, and the June 21 PBA announcement identifies Barkley as Blackwater’s import. [2] [4] [5] No starter designation is inferred. The official roster page is undated and does not name the season, so the season match relies on its current conference-stat context together with the dated Season 50 reports.

## References

[1]: https://www.pba.ph/teams/blackwater-bossing "BLACKWATER BOSSING - Teams"
[2]: https://www.pba.ph/news/ginebra-boots-out-blackwater-sets-up-explosive-faceoff-with-smb "Ginebra boots out Blackwater, sets up explosive faceoff with SMB"
[3]: https://www.pba.ph/news/ros-blackwater-killer-blow-vs-last-stand "ROS-Blackwater: Killer blow vs last stand"
[4]: https://www.pba.ph/news/demusis-makes-most-of-second-chance-in-pba-comeback "Demusis makes most of second chance in PBA comeback"
[5]: https://www.pba.ph/news/familiar-faces-new-imports-coming-over-for-governors-cup "Familiar faces, new imports coming over for Governors' Cup"
