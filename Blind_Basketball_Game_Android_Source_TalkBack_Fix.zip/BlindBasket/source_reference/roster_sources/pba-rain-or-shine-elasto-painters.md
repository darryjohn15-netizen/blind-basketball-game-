# Rain or Shine Elasto Painters — PBA Season 50 Governors’ Cup

**As of:** 2026-10-25 · **Retrieved:** 2026-10-25

The candidate page is the official PBA team page and identifies the exact club as **RAIN OR SHINE ELASTO PAINTERS**. Its current Team Roster section lists 16 players and gives a jersey number and position for each; it also displays conference-average statistics, indicating the roster is tied to the ongoing/just-completed Governors’ Cup rather than merely an undated historical roster.[1] The official PBA standings page lists Rain or Shine in Group B, and official October 21 and October 23, 2026 recaps confirm the contemporaneous Season 50 Governors’ Cup context.[2][3][4]

Roster below follows the official team page’s displayed order, not a starter order. The October 23 game report’s score list documents 12 Rain or Shine participants; it is a game score list, not the complete registered roster. Accordingly, player names and jersey/position fields below come from the league’s full team roster page, while the recent game reports serve as freshness/context checks.[1][3] The official October 21 recap explicitly identifies Aaron Fuller as Rain or Shine’s import.[2] No starters are inferred.

| # | Player | Position |
|---|---|---|
| 8 | Anton Rafael Asistio | SG |
| 28 | Beau Michael Vincent Belga | C |
| 14 | Joshua Andrei Caracut | PG |
| 22 | Jhonard Clarito | PF |
| 29 | Vince Petdeo Cuajao | SG |
| 9 | Vincent Joshua David | SG |
| 10 | Aaron Craig Fuller | SF |
| 2 | Felix Lemetti | PG |
| 4 | Michael John Malonzo | PF |
| 44 | Christian Manaytay | C |
| 1 | Adrian Clarence Nocum | SG |
| 11 | Stanley Pringle | SG |
| 12 | Arthur Roque | PF |
| 25 | Leonard Santillan | PF |
| 0 | Caelan Todd Tiongson | PF |
| 24 | Luis Villegas | C |

## References

[1]: https://pba.ph/teams/rain-or-shine-elasto-painters "Rain or Shine Elasto Painters — Official PBA team roster"
[2]: https://pba.ph/news/magnolia-beats-rain-or-shine-to-clinch-group-b-top-spot "Magnolia beats Rain or Shine to clinch Group B top spot — October 21, 2026"
[3]: https://www.pba.ph/news/ros-blasts-phoenix-sets-up-quarterfinals-duel-vs-converge "ROS blasts Phoenix, sets up quarterfinals duel vs Converge — October 23, 2026"
[4]: https://www.pba.ph/standings "Official PBA standings"
