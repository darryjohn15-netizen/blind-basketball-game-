# Boston Celtics roster audit — 2026–27

**As of / retrieved:** 2026-10-25. **Team:** Boston Celtics (NBA). The requested NBA roster URL is the Boston Celtics’ team roster page, but it does not identify a season in the extracted page content and, on retrieval, still listed Tucker DeVries, Hayden Gray, Gabe McGlothan, and Milos Uzan. The Celtics’ official October 18 announcement says those four players were waived, so the NBA page is stale for membership and those names are excluded. [1] [3]

The official September 27, 2026 training-camp release gives a 21-player list with jersey numbers and positions. Removing the four players explicitly waived on October 18 yields 17 names. The October 22 Celtics home-opener release identifies the same 2026–27 group, including the veteran additions, returning players, draft-class players, and Devin Carter. Taken together, these dated official team announcements support the reconstructed 17-player current roster below. [2] [3] [4]

Roster order below follows the official training-camp list after removing the four waived players; it does not imply starter status. Devin Carter, Dillon Mitchell, and Amari Williams are identified as two-way players in the October 18/September 27 announcements and reaffirmed in the October 22 release. The remaining listed players are standard roster players. Where an official roster-page jersey or position conflicts with the camp listing—Carter’s and Ron Harper Jr.’s jersey numbers, and Hugo González’s, Harper’s, and Williams’s listed position—I leave that field blank rather than choose between the conflicting values. [1] [2] [3] [4]

| Player | Jersey | Position | Classification |
|---|---:|---|---|
| Devin Carter |  | G | Two-way |
| Chris Cenac Jr. | 12 | F/C | Standard |
| Mike Conley Jr. | 45 | G | Standard |
| Luka Garza | 52 | F/C | Standard |
| Paul George | 13 | F | Standard |
| Hugo González | 28 |  | Standard |
| Ron Harper Jr. |  |  | Standard |
| Sam Hauser | 30 | F | Standard |
| Dillon Mitchell | 20 | F | Two-way |
| Payton Pritchard | 11 | G | Standard |
| Neemias Queta | 88 | C | Standard |
| Mitchell Robinson | 4 | C | Standard |
| Baylor Scheierman | 55 | G/F | Standard |
| Jayson Tatum | 0 | F | Standard |
| Jordan Walsh | 27 | F | Standard |
| Derrick White | 9 | G | Standard |
| Amari Williams | 77 |  | Two-way |

## References

[1]: https://www.nba.com/celtics/roster "Roster | Boston Celtics"
[2]: https://celtics.com/news/celtics-announce-2026-27-training-camp-roster "Celtics Announce 2026-27 Training Camp Roster"
[3]: https://celtics.com/news/press-release-20261018-celtics-convert-devin-carter-to-two-way-contract "Celtics Convert Devin Carter to Two-Way Contract"
[4]: https://celtics.com/news/press-release-20261022-boston-celtics-to-face-new-york-knicks-for-home-opener-presented-by-td "Boston Celtics to Face New York Knicks for Home Opener Presented by TD"
