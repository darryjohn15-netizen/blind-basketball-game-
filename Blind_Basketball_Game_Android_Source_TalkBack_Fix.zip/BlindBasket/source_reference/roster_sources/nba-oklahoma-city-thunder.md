# Oklahoma City Thunder roster audit — 2026–27

**As of / retrieved:** 2026-10-25. **Team:** Oklahoma City Thunder (NBA). **Result:** The refreshed official NBA team roster page lists 17 players, including all three players identified in the Thunder’s official two-way-contract announcement. The roster order below follows the official page; it does not identify starters. [1] [2]

The requested candidate URL is the Thunder-specific page on NBA.com (`/thunder/roster`). Its current roster data showed regular-season appearances (2 GP for players who had played), and the NBA’s official 2026–27 Thunder season preview and the team’s dated 2026–27 training-camp release independently establish the season context. [1] [3] [4]

| Player | Jersey | Position | Classification |
|---|---:|---|---|
| Shai Gilgeous-Alexander | 2 | Guard | Standard |
| Jared McCain | 3 | Guard | Standard |
| Jaylin Williams | 6 | Forward | Standard |
| Chet Holmgren | 7 | Center-Forward | Standard |
| Jalen Williams | 8 | Guard-Forward | Standard |
| Alex Caruso | 9 | Guard | Standard |
| Thomas Sorber | 12 | Center | Standard |
| Otega Oweh | 13 | Guard | Two-way |
| Bennett Stirtz | 14 | Guard | Standard |
| Aday Mara | 15 | Center | Standard |
| Josh Dix | 21 | Guard | Two-way |
| Cason Wallace | 22 | Guard | Standard |
| Brooks Barnhizer | 23 | Guard | Two-way |
| Ajay Mitchell | 25 | Guard | Standard |
| Kenrich Williams | 34 | Guard-Forward | Standard |
| Nikola Topić | 44 | Guard | Standard |
| Isaiah Hartenstein | 55 | Center-Forward | Standard |

Numbers and positions are transcribed from the refreshed NBA roster page. The Thunder’s July 3 release explicitly identifies Brooks Barnhizer, Josh Dix, and Otega Oweh as having signed two-way contracts; all other players listed on the current roster page are classified here as standard-roster players. [1] [2]

**Version note:** An earlier page extraction during this research returned a different, apparently older roster representation, including “Cristoph Tilly” and without jersey/position fields for Josh Dix. A later refresh of the same official page returned the 17-player list above, including Dix at No. 21, with two regular-season games shown for played players and no Tilly listing. The roster below follows the refreshed page available on the requested as-of date; Tilly is not included as a current rostered player. [1]

## References

[1]: https://www.nba.com/thunder/roster "Oklahoma City Thunder — Roster"
[2]: https://www.nba.com/thunder/news/release-barnhizerdixoweh-260703 "Thunder Signs Barnhizer, Dix and Oweh to Two-Way Contracts"
[3]: https://www.nba.com/news/2026-27-season-preview-okc "2026-27 Season Preview: Oklahoma City Thunder"
[4]: https://www.nba.com/thunder/news/release-trainingcamp-260927 "Thunder Announces 2026-27 Training Camp Roster"
