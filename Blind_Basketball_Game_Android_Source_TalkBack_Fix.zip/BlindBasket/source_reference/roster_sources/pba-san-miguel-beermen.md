# San Miguel Beermen roster audit

**League/team/season:** PBA — San Miguel Beermen — Season 50 Governors’ Cup (2026). **Retrieved/as of:** 2026-10-25.

The official PBA San Miguel Beermen team page identifies the exact team and labels the following 16 entries under “Team Roster”; it provides jersey numbers and positions for each. In displayed roster order, the names are Jerrick Vincent Ahanmisi (7, SG), John Rodney Brondial (91, C), Philip Andreas Cahilig (11, PF), John Michael Calma (22, PF), Jericho Xavier Cruz (39, SG), June Mar Fajardo (15, C), Paolo Jose Hernandez (19, SG), George King (94, SG), Marcio Lassiter (13, SG), Royce Mantua (23, SF), Jaymar Perez (77, SG), Krismoir Rosales (1, PG), Christopher Ross (6, PG), Moala Tautuaa (3, PF), Jeron Alvin Teng (21, SF), and Celedonio Trollano (2, SF). The roster order is not evidence of starters. [1]

The season association is corroborated by current official PBA coverage: the October 15 report explicitly calls San Miguel’s matchup the PBA 50th Season Governors’ Cup and identifies George King as the team’s import; the October 21 game report names San Miguel and supplies its game roster/scoring line, overlapping the official team-page names; and the October 23 report confirms San Miguel’s place in the Governors’ Cup quarterfinals. [2] [3] [4]

**Completeness limitation:** `roster_complete=false`. The official team page is the latest official roster page available in this check, and its listed names align with current-season reporting, but the page itself provides no season label, publication/update date, or dated roster submission. Current game recaps verify participation by only a subset of the 16 names. I therefore report the names displayed by the official roster page but cannot establish from dated official evidence that every entry was still rostered on 2026-10-25. No player is designated a starter.

## References

[1]: https://www.pba.ph/teams/san-miguel-beermen "San Miguel Beermen - PBA Teams"
[2]: https://www.pba.ph/news/george-king-mastering-smb-playbook-with-laptop-ahead-of-playoffs "George King mastering SMB playbook with laptop ahead of playoffs"
[3]: https://www.pba.ph/news/nlex-blows-20-point-lead-in-loss-to-smb-but-keeps-top-seeding-in-group-a "NLEX blows 20-point lead in loss to SMB, but keeps top seeding in Group A"
[4]: https://www.pba.ph/news/ginebra-boots-out-blackwater-sets-up-explosive-faceoff-with-smb "Ginebra boots out Blackwater, sets up explosive faceoff with SMB"
