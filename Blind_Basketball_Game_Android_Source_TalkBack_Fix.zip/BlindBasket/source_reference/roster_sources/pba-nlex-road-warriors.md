# NLEX Road Warriors — PBA Season 50 roster audit

**As of / retrieved:** 2026-10-25.

The supplied official team page is for the **NLEX ROAD WARRIORS**. It lists a team roster with player jersey numbers and positions, but does not identify a season or give a publication/update date. The Season 50 Governors’ Cup context is independently confirmed by official PBA coverage of NLEX’s October 21, 2026 game and group standings. [1] [2]

The team page lists 16 players, including import DeQuan Jones. That import entry is stale for the requested date: the PBA reported on October 6 that Deonte Burton took over import duties “vice Jones,” and October 14 and October 21 PBA game reports list Burton with NLEX. [3] [4] [5] Accordingly, the roster output uses the 15 non-import names on the official team page and substitutes Burton as the current import; Burton’s jersey and position are left blank because the sources reviewed do not verify them.

**Completeness is not verified.** The live roster page has no visible update date and still carries the superseded Jones import entry. Its remaining names are not reconciled against dated transactions and October game score lists: for example, the October 14 report lists Dave Marcelo in NLEX’s scoring line, while the page does not list him and the October 21 scoring line does not include him. The official transaction page also records Marcelo’s relegation to the UFAWR2RS list in August and Ramirez’s reactivation. The evidence therefore supports the names returned, but does not establish a complete current Season 50 roster as of October 25. [1] [4] [5] [6]

## References

[1]: https://www.pba.ph/teams/nlex-road-warriors "NLEX Road Warriors — Official PBA team page"
[2]: https://www.pba.ph/news/nlex-blows-20-point-lead-in-loss-to-smb-but-keeps-top-seeding-in-group-a "NLEX blows 20-point lead in loss to SMB, but keeps top seeding in Group A"
[3]: https://www.pba.ph/news/nlex-import-deonte-burton-makes-his-debut-vs-macau "NLEX import Deonte Burton makes his debut vs Macau"
[4]: https://www.pba.ph/news/nlex-rips-titan-sets-up-virtual-playoff-for-top-spot-vs-smb "NLEX rips Titan, sets up virtual playoff for top spot vs SMB"
[5]: https://www.pba.ph/news/nlex-blows-20-point-lead-in-loss-to-smb-but-keeps-top-seeding-in-group-a "NLEX blows 20-point lead in loss to SMB, but keeps top seeding in Group A"
[6]: https://www.pba.ph/transaction "Transactions — Official PBA"
