# Houston Rockets roster audit

**As of / retrieved:** 2026-10-25. **League/team/season:** NBA, Houston Rockets, 2026–27.

The official Rockets roster page identifies the team as the Houston Rockets and displays 17 player cards in the order below, with jersey numbers and positions.[1] The roster page itself does not label a season; the Rockets’ official schedule announcement explicitly identifies the 2026–27 season and says Opening Night was October 21, which supports treating the live roster as the current page during the requested season.[2] The requested `/rockets/roster` URL returned “Roster unavailable” in text extraction; live browser navigation redirected to the rendered `/rockets/player` roster page used here.[1]

| Roster order | Player | Jersey | Position | Classification |
|---:|---|---:|---|---|
| 1 | Amen Thompson | 1 | G-F | Not stated on roster page |
| 2 | Bruce Thornton | 2 | G | Not stated on roster page |
| 3 | Julian Phillips | 4 | F | Not stated on roster page |
| 4 | Fred VanVleet | 5 | G | Not stated on roster page |
| 5 | Kevin Durant | 7 | F | Not stated on roster page |
| 6 | Jae'Sean Tate | 8 | F | Not stated on roster page |
| 7 | Jabari Smith Jr. | 10 | F | Not stated on roster page |
| 8 | Steven Adams | 12 | C | Not stated on roster page |
| 9 | Reed Sheppard | 15 | G | Not stated on roster page |
| 10 | Tari Eason | 17 | F | Not stated on roster page |
| 11 | Quadir Copeland | 25 | G | Two-way, confirmed by team announcement [3] |
| 12 | Isaiah Crawford | 27 | F | Not stated on roster page |
| 13 | Alperen Sengun | 28 | C | Not stated on roster page |
| 14 | Clint Capela | 30 | C | Not stated on roster page |
| 15 | Bogdan Bogdanović | 31 | G | Not stated on roster page |
| 16 | Oscar Tshiebwe | 9 | F-C | Not stated on roster page |
| 17 | Marcus Smart | 36 | G | Not stated on roster page |

**Completeness and limitations.** `roster_complete=true` for the players currently displayed on the official roster page at retrieval. The roster page does not show contract categories, so apart from Quadir Copeland’s separately confirmed two-way contract, contract classifications are left unverified rather than inferred. The list preserves the page’s roster order; it does not indicate starters.[1] Official team notices also document Bruce Thornton’s signing and Isaiah Crawford’s re-signing, but do not change the roster-page fields above.[4][5]

## References

[1]: https://www.nba.com/rockets/player "Roster | Houston Rockets"
[2]: https://rockets.com/news/rockets-announce-schedule-for-2026-27-nba-season "Rockets Announce Schedule for 2026-27 NBA Season"
[3]: https://rockets.com/news/rockets-sign-rookie-quadir-copeland-to-two-way-contract "Rockets Sign Rookie Quadir Copeland to Two-Way Contract"
[4]: https://rockets.com/news/rockets-sign-rookie-bruce-thornton "Rockets Sign Rookie Bruce Thornton"
[5]: https://rockets.com/news/rockets-re-sign-isaiah-crawford "Rockets Re-Sign Isaiah Crawford"
