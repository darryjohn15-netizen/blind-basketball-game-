# User-supplied roster research

**Received:** 2026-10-25  
**Source file:** user upload `pasted_content.txt`  
**Reference date stated in the upload:** 2026-10-25

This is a cleaned record of the user-provided research note. The note itself says that it is not a complete combined roster dataset and that not all player names were retrievable. The application must preserve those limits rather than presenting directory links as named rosters.

## Player lists included in the uploaded note

- **PBA — TNT Tropang 5G:** 23 player names were supplied, sourced by the user to the [official TNT roster page](https://pba.ph/teams/tnt-tropang-5g). The runtime catalog includes only this team from the supplied PBA player list. The source order is not treated as an official starting five. The entry has no jersey numbers or positions in the source note, so those are left blank.
- **FIBA Asia Cup 2025 — Philippines:** 12 player names were supplied from the [official FIBA tournament roster PDF](https://reports.fiba.basketball/reports/2025/FIBA%20Asia%20Cup/rosters.pdf). This is a historical national-team tournament squad, not a current 2026 national roster, not a club team, and not a current FIBA Asia league roster. The game labels it accordingly and allows it only as a historical exhibition team.

## Directories mentioned without complete player lists in the upload

- **NBA 2026–27 opening-night roster article:** [NBA.com](https://www.nba.com/news/nba-rosters-set-for-2026-27-regular-season). The upload points to this source but did not include player names for every NBA team in its text.
- **PBA general site:** [PBA.ph](https://www.pba.ph/). The upload supplied only the TNT list above.
- **MPBL 2026 team/roster directory:** [FanZiz MPBL teams](https://www.fanziz.com/basketball/series/mpbl-2026/teams). This is a secondary directory, not an official league/team source; the upload provided no complete named roster list for each team.
- **FIBA Basketball World Cup 2027 Asian Qualifiers tracker:** [FIBA official tracker](https://www.fiba.basketball/en/events/fiba-basketball-world-cup-2027/news/asian-qualifiers-roster-tracker-who-will-play-in-window-1). The upload supplied the directory URL but no current player entries for every team.
- **PBL:** [Historical PBL records](https://pilipinasbasketball.net/pbl-history-champions-mvp-record/). The upload points to historical records, not a current 2026 PBL team field or current rosters.

The named player lists in the runtime supplement are transcribed from the user-provided note and were not independently fetched during this integration step. Other league rosters are being sourced and date-stamped separately; the linked directory pages are not treated as complete roster data by themselves.
