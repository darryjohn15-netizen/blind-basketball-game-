require "import"
import "android.widget.*"
import "android.view.*"
import "android.app.AlertDialog"
import "android.graphics.Color"
import "android.content.Intent"
import "android.net.Uri"
import "android.media.MediaPlayer"
import "android.speech.tts.TextToSpeech"
import "android.os.Vibrator"
import "android.content.Context"
import "com.androlua.Ticker"
import "java.util.Locale"
import "android.view.Gravity"

-- ═══════════════════════════════════════════════════════════════
--  PURE-LUA JSON
-- ═══════════════════════════════════════════════════════════════
local json = {}
local function jsonEncode(v)
  local t=type(v)
  if t=="nil" then return "null"
  elseif t=="boolean" or t=="number" then return tostring(v)
  elseif t=="string" then
    return '"'..v:gsub('\\','\\\\'):gsub('"','\\"'):gsub('\n','\\n'):gsub('\r','\\r'):gsub('\t','\\t')..'"'
  elseif t=="table" then
    local isArr,n=true,0
    for k,_ in pairs(v) do n=n+1; if type(k)~="number" or k~=math.floor(k) or k<1 then isArr=false end end
    if isArr and n==#v then
      local p={}; for i,x in ipairs(v) do p[i]=jsonEncode(x) end; return "["..table.concat(p,",").."]"
    else
      local p={}; for k,x in pairs(v) do table.insert(p,jsonEncode(tostring(k))..":"..jsonEncode(x)) end
      return "{"..table.concat(p,",").."}"
    end
  end; return "null"
end
local function jsonDecode(s)
  local pos=1
  local function skip() while pos<=#s and s:sub(pos,pos):match("%s") do pos=pos+1 end end
  local decode
  local function dStr()
    pos=pos+1; local r={}
    while pos<=#s do
      local c=s:sub(pos,pos)
      if c=='"' then pos=pos+1; return table.concat(r) end
      if c=='\\' then pos=pos+1; c=s:sub(pos,pos)
        local esc={['"']='"',['\\']='\\',n='\n',r='\r',t='\t'}
        r[#r+1]=esc[c] or c
      else r[#r+1]=c end; pos=pos+1
    end; return table.concat(r)
  end
  local function dArr()
    local a={}; pos=pos+1; skip()
    if s:sub(pos,pos)==']' then pos=pos+1; return a end
    while true do a[#a+1]=decode(); skip(); local c=s:sub(pos,pos); pos=pos+1; if c==']' then return a end end
  end
  local function dObj()
    local o={}; pos=pos+1; skip()
    if s:sub(pos,pos)=='}' then pos=pos+1; return o end
    while true do skip(); local k=dStr(); skip(); pos=pos+1; o[k]=decode(); skip(); local c=s:sub(pos,pos); pos=pos+1; if c=='}' then return o end end
  end
  decode=function()
    skip(); local c=s:sub(pos,pos)
    if c=='"' then return dStr()
    elseif c=='[' then return dArr()
    elseif c=='{' then return dObj()
    elseif c=='t' then pos=pos+4; return true
    elseif c=='f' then pos=pos+5; return false
    elseif c=='n' then pos=pos+4; return nil
    else local n=s:match("^-?%d+%.?%d*[eE]?[+-]?%d*",pos); if n then pos=pos+#n; return tonumber(n) end end
    return nil
  end
  local ok,r=pcall(decode); return ok and r or {}
end
json.encode=jsonEncode; json.decode=jsonDecode

-- ═══════════════════════════════════════════════════════════════
--  NETWORK LAYER
-- ═══════════════════════════════════════════════════════════════
local SERVER_HTTPS="https://bugok.net"; local SERVER_HTTP="http://bugok.net"
local currentServer=SERVER_HTTPS

local function _httpRequest(method,urlStr,body,cb)
  local t=java.lang.Thread(java.lang.Runnable{run=function()
    local code,content=-1,""
    local ok,err=pcall(function()
      local conn=java.net.URL(urlStr).openConnection()
      conn.setRequestMethod(method); conn.setConnectTimeout(8000); conn.setReadTimeout(8000); conn.setDoInput(true)
      if method=="POST" and body then
        conn.setDoOutput(true); conn.setRequestProperty("Content-Type","application/json; charset=UTF-8")
        local w=java.io.OutputStreamWriter(conn.getOutputStream(),"UTF-8"); w.write(body); w.flush(); w.close()
      end
      code=conn.getResponseCode()
      local s=(code>=200 and code<400) and conn.getInputStream() or conn.getErrorStream()
      local r=java.io.BufferedReader(java.io.InputStreamReader(s,"UTF-8"))
      local sb=java.lang.StringBuilder(); local ln=r.readLine()
      while ln~=nil do sb.append(ln); ln=r.readLine() end
      r.close(); content=sb.toString()
    end)
    if not ok then code=-1; content=tostring(err) end
    local fc,fv=code,content
    activity.runOnUiThread(java.lang.Runnable{run=function() cb(fc,fv) end})
  end}); t.start()
end
local function httpGet(u,cb)    _httpRequest("GET",u,nil,cb) end
local function httpPost(u,b,cb) _httpRequest("POST",u,b,cb) end
function httpGetFallback(p,cb)
  httpGet(currentServer..p,function(c,v)
    if (c==-1 or c==0) and currentServer==SERVER_HTTPS then currentServer=SERVER_HTTP; httpGet(currentServer..p,cb)
    else cb(c,v) end
  end)
end
function httpPostFallback(p,d,cb)
  httpPost(currentServer..p,d,function(c,v)
    if (c==-1 or c==0) and currentServer==SERVER_HTTPS then currentServer=SERVER_HTTP; httpPost(currentServer..p,d,cb)
    else cb(c,v) end
  end)
end

-- ═══════════════════════════════════════════════════════════════
--  LEAGUE & ROSTER DATA
-- ═══════════════════════════════════════════════════════════════
local LEAGUE_DATA={
  NBA={
    ["LA Lakers"]={"LeBron James","Anthony Davis","Austin Reaves","D'Angelo Russell","Rui Hachimura","Deandre Ayton","Max Christie","Jarred Vanderbilt","Gabe Vincent","Christian Wood","Bronny James","Cam Reddish"},
    ["Golden State Warriors"]={"Stephen Curry","Draymond Green","Andrew Wiggins","Buddy Hield","Jonathan Kuminga","Brandin Podziemski","Trayce Jackson-Davis","Moses Moody","Kevon Looney","Gary Payton II","Lindy Waters III","Kyle Anderson"},
    ["Boston Celtics"]={"Jayson Tatum","Jaylen Brown","Jrue Holiday","Derrick White","Kristaps Porzingis","Al Horford","Payton Pritchard","Sam Hauser","Luke Kornet","Xavier Tillman","Neemias Queta","Jordan Walsh"},
    ["Miami Heat"]={"Jimmy Butler","Bam Adebayo","Tyler Herro","Terry Rozier","Duncan Robinson","Jaime Jaquez Jr.","Nikola Jovic","Kel'el Ware","Kevin Love","Josh Richardson","Haywood Highsmith","Thomas Bryant"},
    ["Dallas Mavericks"]={"Luka Doncic","Kyrie Irving","Klay Thompson","Dereck Lively II","P.J. Washington","Daniel Gafford","Naji Marshall","Quentin Grimes","Maxi Kleber","Jaden Hardy","Dwight Powell","Spencer Dinwiddie"},
  },
  PBA={
    ["San Miguel Beermen"]={"June Mar Fajardo","CJ Perez","Terrence Romeo","Chris Ross","Marcio Lassiter","Jericho Cruz","Don Trollano","Vic Manuel","Simon Enciso","Mo Tautuaa","Jeron Teng","Rodney Brondial"},
    ["Barangay Ginebra"]={"Scottie Thompson","Justin Brownlee","Japeth Aguilar","Jamie Malonzo","Maverick Ahanmisi","RJ Abarrientos","Stephen Holt","Isaac Go","Ben Adamos","LA Tenorio","Aljon Mariano","Von Pessumal"},
    ["Converge FiberXers"]={"Justine Baltazar","Juan Gomez De Liano","Alec Stockton","Justine Arana","King Caralipio","Jhan Nermal","Gelo Alolino","Larry Muyang","Dave Ildefonso","Rafi Reavis","Bryan Santos","Kevin Racal"},
    ["Terrafirma Dyip"]={"Philip Cahilig","John Paul Calvo","Jerrick Ahanmisi","Philip Szanyiel","Louie Sangalang","Mark Nonoy","Paolo Hernandez","Aljun Melecio","Tommy Olivario","Brent Paraiso","Rey Suerte","RK Elagan"},
    ["Blackwater Bossing"]={"Bradwyn Guinto","Christian David","Sedrick Barefield","Troy Mallillin","Dalph Panopio","Jeth Troy Rosario","James Sena","Rey Anthony Suerte","Fredrick Tungcab","DJ Mitchell","David Merrell","Ato Ular"},
  },
  MPBL={
    ["San Juan Knights"]={"Orlan Wamar Jr.","Michael Calisaan","Jo Sabandal","Jen Galinato","Niko Panganiban","Terrence Fortea","Reyland Torres","Harold Alarcon","Reynel Hugnatan","Arvin Gamboa","Joseph Ubald","Jeff Tahoner"},
    ["Pampanga Giant Lanterns"]={"Justine Baltazar","Encho Serrano","Archie Concepcion","MJ Garcia","Raymond Binuya","John Lloyd Clemente","Larry Muyang","Miguel Pangilinan","Wilson Baltazar","Jhaymo Eguilos","Chris Lalata","Kurt Reyson"},
    ["Nueva Ecija Rice Vanguards"]={"Jaycee Marcelino","Jayvee Marcelino","John Wilson","Jasper Aya","Billy Robles","Michael Mabulac","Chris Bitoon","Will McAloney","Byron Villarias","Robby Celiz","Hesed Gabo","Pao Javelona"},
    ["Batangas City Tanduay"]={"Levi Hernandez","Cedric Ablaza","Jeckster Apinan","Juneric Baloria","Dawn Ochea","Philip Paniamogan","Rudy Lingganay","Carlos Isit Jr.","John Ambulodto","Mark Neil Cruz","King Importante","MJ Dela Virgen"},
    ["Manila Batang Quiapo"]={"James Sena","Greg Slaughter","Jan Jamon","Renz Palma","Danielle Atyensa","Raphael Flores","Dustin Ambrosio","Richard Albo","Makmak Samonte","Kyle Shello","Joo Chong Pico","Joey Erram"},
  }
}
local TEAM_NAME_POOL={"Arctic Wolves","Iron Titans","Desert Vipers","Electric Eagles","Midnight Panthers","Golden Griffins","Silver Sabres","Neon Knights","Shadow Strikers","Crimson Crusaders","Storm Breakers","Lunar Lions","Solar Sharks","Galaxy Guardians","Turbo Tigers","Sonic Scorpions","Velocity Vikings","Raptor Raiders","Cobra Commanders","Steel Stallions"}
local PLAYER_NAME_POOL={"Darry Sarmiento","Walter Miles","Jun Mar","Jimmy Alapag","Gabe Norwood","Robert Jaworski","Allan Caidic","Benjie Paras","Alvin Patrimonio","Johnny Abarrientos","Jayson Castro","LA Tenorio","Marc Pingris","James Yap","Gary David","Paul Lee","Terrence Romeo","Calvin Abueva","Ian Sangalang","Chris Newsome","Scottie Thompson","CJ Perez","Robert Bolick","Matthew Wright","Ray Parks Jr.","Kiefer Ravena","Thirdy Ravena","Kai Sotto","Rhenz Abando","Dwight Ramos"}
local ALL_TEAMS={}
for _,teams in pairs(LEAGUE_DATA) do for name,_ in pairs(teams) do table.insert(ALL_TEAMS,name) end end

-- ═══════════════════════════════════════════════════════════════
--  POSITIONS & HEIGHT RANGES
-- ═══════════════════════════════════════════════════════════════
local POSITIONS={"Point Guard","Shooting Guard","Small Forward","Power Forward","Center"}
local POS_HEIGHTS={
  ["Point Guard"]={'5\'10"','5\'11"','6\'0"','6\'1"','6\'2"','6\'3"','6\'4"','6\'5"'},
  ["Shooting Guard"]={'6\'0"','6\'1"','6\'2"','6\'3"','6\'4"','6\'5"','6\'6"','6\'7"'},
  ["Small Forward"]={'6\'4"','6\'5"','6\'6"','6\'7"'},
  ["Power Forward"]={'6\'8"','6\'9"','6\'10"','6\'11"','7\'0"'},
  ["Center"]={'7\'0"','7\'1"','7\'2"','7\'3"','7\'4"'}
}

-- ═══════════════════════════════════════════════════════════════
--  CONSTANTS
-- ═══════════════════════════════════════════════════════════════
local SHOT_MAX=24; local QUARTER_SEC=720; local NUM_Q=4; local OT_SEC=300
local VIBE_DRIBBLE=20; local VIBE_BLOCK=1000; local VIBE_SCORE_MS=100; local VIBE_STEAL_MS=50
local FOUL_LIMIT=6       -- personal fouls before foul-out
local TEAM_FOUL_BONUS=5  -- team fouls before bonus free throws each half
local FT_WINDOW=4000     -- ms player has to tap free throw button

-- ═══════════════════════════════════════════════════════════════
--  GAME STATE
-- ═══════════════════════════════════════════════════════════════
local playerScore=0; local enemyScore=0
local playerName="Your Team"; local enemyName="Enemy Team"
local teamColor=Color.WHITE; local isGameOver=true; local isBusy=false
local possession=""; local blockedLanes={}; local activePlayer="Player"

local to30=2; local to60=1; local isTimeoutActive=false
local shotTicker=nil; local gameTicker=nil; local toTicker=nil
local shotSec=SHOT_MAX; local gameSec=QUARTER_SEC
local currentQ=1; local qStartPlayer=0; local qStartEnemy=0; local qScores={}

-- Stats
local ptsP={}; local ptsE={}
local astP={}; local astE={}
local stealsP={}; local stealsE={}

-- Fouls (NEW)
local foulsP={}         -- per-player foul count (player team)
local foulsE={}         -- per-player foul count (enemy team)
local teamFoulsP=0      -- team fouls this half (player team)
local teamFoulsE=0      -- team fouls this half (enemy team)
local ftPending=false   -- free throw sequence active
local ftCount=0         -- FTs remaining to shoot
local ftMade=0          -- FTs made so far in sequence
local ftCallback=nil    -- what to do after FTs finish

local assistPending=false; local assistFrom=""; local assistWho=""
local careerWins=0; local unlockedPerks={}
local myCA=nil; local isMyCAGame=false

-- Rosters
local playerRoster={}; local enemyRoster={}
local starters={}; local bench={}; local eStarters={}; local eBench={}

-- Online
local isOnline=false; local onlineToken=nil; local networkRole=nil
local localLane=nil; local remoteLane=nil; local networkTicker=nil

-- ═══════════════════════════════════════════════════════════════
--  VOLUME SETTINGS
-- ═══════════════════════════════════════════════════════════════
local sfxVol=1.0; local bgVol=0.3; local menuVol=0.4; local ttsRate=1.0

function saveSettings()
  local f=io.open(activity.getLuaDir().."/settings.txt","w")
  if f then f:write(sfxVol.."\n"..bgVol.."\n"..menuVol.."\n"); f:close() end
end
function loadSettings()
  local f=io.open(activity.getLuaDir().."/settings.txt","r"); if not f then return end
  local a=f:read("*l"); local b=f:read("*l"); local c=f:read("*l"); f:close()
  if a then sfxVol=tonumber(a) or 1.0 end
  if b then bgVol=tonumber(b) or 0.3 end
  if c then menuVol=tonumber(c) or 0.4 end
end

-- ═══════════════════════════════════════════════════════════════
--  AUDIO ENGINE
-- ═══════════════════════════════════════════════════════════════
local vibrator=activity.getSystemService(Context.VIBRATOR_SERVICE)
local SFX={list={}}

local function sfxRelease(mp)
  for i=#SFX.list,1,-1 do if SFX.list[i]==mp then table.remove(SFX.list,i); break end end
  pcall(function() mp.release() end)
end

function SFX.play(file,loop,isBg,customVol)
  local mp=MediaPlayer()
  local ok=pcall(function()
    mp.setDataSource(activity.getLuaDir().."/"..file)
    mp.setLooping(loop or false)
    local v=customVol or (isBg and bgVol or sfxVol)
    mp.setVolume(v,v)
    mp.setOnErrorListener(MediaPlayer.OnErrorListener{onError=function(m,w,e) pcall(function() sfxRelease(m) end); return true end})
    if not loop then
      mp.setOnCompletionListener(MediaPlayer.OnCompletionListener{onCompletion=function(m) pcall(function() sfxRelease(m) end) end})
    end
    mp.prepare(); mp.start(); table.insert(SFX.list,mp)
  end)
  if not ok then pcall(function() mp.release() end); return nil end
  return mp
end

-- Stop ALL sounds (used on game over / menu)
function SFX.stopAll()
  local snap=SFX.list; SFX.list={}
  for _,v in ipairs(snap) do
    pcall(function()
      if v then v.setOnCompletionListener(nil); v.setOnErrorListener(nil); v.stop(); v.release() end
    end)
  end
end

-- Stop ONLY looping background sounds — leaves one-shot SFX playing (FIX for sound overlap)
function SFX.stopBg()
  local keep={}
  local snap=SFX.list; SFX.list={}
  for _,mp in ipairs(snap) do
    local isLoop=false
    pcall(function() isLoop=mp.isLooping() end)
    if isLoop then
      pcall(function() mp.setOnCompletionListener(nil); mp.setOnErrorListener(nil); mp.stop(); mp.release() end)
    else
      table.insert(keep,mp)
    end
  end
  SFX.list=keep
end

local function stopShot() if shotTicker then pcall(function() shotTicker.stop() end); shotTicker=nil end end
local function stopGame() if gameTicker then pcall(function() gameTicker.stop() end); gameTicker=nil end end
local function stopTO()   if toTicker   then pcall(function() toTicker.stop()   end); toTicker=nil   end end
function SFX.stopTickers() stopShot(); stopGame(); stopTO() end
-- stopBoth: pause clocks but leave sounds running
local function stopBoth() stopShot(); stopGame() end

local function pulse(ms) if vibrator then pcall(function() vibrator.vibrate(ms) end) end end

-- ═══════════════════════════════════════════════════════════════
--  HAPTIC PATTERNS
-- ═══════════════════════════════════════════════════════════════
local function vibeDribble() pulse(VIBE_DRIBBLE) end
local function vibeBlock()   pulse(VIBE_BLOCK) end
local function vibeScore()   pulse(VIBE_SCORE_MS); task(200,function() pulse(VIBE_SCORE_MS) end); task(400,function() pulse(VIBE_SCORE_MS) end) end
local function vibeSteal()   pulse(VIBE_STEAL_MS); task(150,function() pulse(200) end) end
local function vibeFoul()    pulse(300); task(400,function() pulse(300) end) end

-- ═══════════════════════════════════════════════════════════════
--  TTS
-- ═══════════════════════════════════════════════════════════════
local tts
tts=TextToSpeech(activity,TextToSpeech.OnInitListener{
  onInit=function(st)
    if st==TextToSpeech.SUCCESS then tts.setLanguage(Locale.US); tts.setSpeechRate(ttsRate) end
  end})
function speak(t)
  if service and service.speak then service.speak(tostring(t))
  elseif tts then tts.speak(tostring(t),TextToSpeech.QUEUE_FLUSH,nil) end
end

-- ═══════════════════════════════════════════════════════════════
--  CAREER PROGRESS
-- ═══════════════════════════════════════════════════════════════
function saveProgress()
  local f=io.open(activity.getLuaDir().."/career_progress.txt","w"); if not f then return end
  f:write(careerWins.."\n"); for _,p in ipairs(unlockedPerks) do f:write(p.."\n") end; f:close()
end
function loadProgress()
  local f=io.open(activity.getLuaDir().."/career_progress.txt","r"); if not f then return end
  local l=f:read("*l"); if l then careerWins=tonumber(l) or 0 end
  unlockedPerks={}
  while true do local p=f:read("*l"); if not p then break end; table.insert(unlockedPerks,p) end
  f:close()
end
function hasPerk(n) for _,p in ipairs(unlockedPerks) do if p==n then return true end end return false end
function checkUnlocks()
  local np
  if     careerWins==3  and not hasPerk("Fast Break") then np="Fast Break"
  elseif careerWins==7  and not hasPerk("Lockdown")   then np="Lockdown"
  elseif careerWins==12 and not hasPerk("Clutch")     then np="Clutch"
  elseif careerWins==20 and not hasPerk("Legendary")  then np="Legendary" end
  if np then table.insert(unlockedPerks,np); speak("CONGRATULATIONS! You unlocked "..np.."!") end
end

-- ═══════════════════════════════════════════════════════════════
--  MY CAREER ACCOUNT
-- ═══════════════════════════════════════════════════════════════
function saveCA()
  if not myCA then return end
  local f=io.open(activity.getLuaDir().."/my_career_account.txt","w"); if not f then return end
  f:write(myCA.name.."\n"..myCA.position.."\n"..myCA.height.."\n")
  f:write(myCA.gamesPlayed.."\n"..myCA.totalPoints.."\n"..myCA.totalAssists.."\n"..myCA.careerWins.."\n")
  f:close()
end
function loadCA()
  local f=io.open(activity.getLuaDir().."/my_career_account.txt","r"); if not f then return end
  local nm=f:read("*l"); local pos=f:read("*l"); local ht=f:read("*l")
  local gp=f:read("*l"); local tp=f:read("*l"); local ta=f:read("*l"); local cw=f:read("*l")
  f:close()
  if nm and #nm>0 then
    myCA={name=nm,position=pos or "Point Guard",height=ht or '6\'0"',
          gamesPlayed=tonumber(gp) or 0,totalPoints=tonumber(tp) or 0,
          totalAssists=tonumber(ta) or 0,careerWins=tonumber(cw) or 0}
  end
end
function deleteCA() myCA=nil; os.remove(activity.getLuaDir().."/my_career_account.txt") end

-- ═══════════════════════════════════════════════════════════════
--  MID-GAME SAVE / LOAD
-- ═══════════════════════════════════════════════════════════════
local SAVE=activity.getLuaDir().."/saved_game.txt"
local function fmtTime(s)
  if s<0 then s=0 end; local m=math.floor(s/60); local sc=s%60
  return m..":"..(sc<10 and "0" or "")..sc
end

function saveGame()
  if isOnline then return end
  local f=io.open(SAVE,"w"); if not f then return end
  f:write("BBG_SAVE\n"..playerName.."\n"..enemyName.."\n")
  f:write(playerScore.."\n"..enemyScore.."\n"..currentQ.."\n"..gameSec.."\n")
  f:write(to30.."\n"..to60.."\n"..careerWins.."\n"..(isMyCAGame and 1 or 0).."\n")
  f:write(teamFoulsP.."\n"..teamFoulsE.."\n")
  for n,v in pairs(ptsP)    do f:write("PP:"..n..":"..v.."\n") end
  for n,v in pairs(ptsE)    do f:write("PE:"..n..":"..v.."\n") end
  for n,v in pairs(astP)    do f:write("AP:"..n..":"..v.."\n") end
  for n,v in pairs(astE)    do f:write("AE:"..n..":"..v.."\n") end
  for n,v in pairs(stealsP) do f:write("SP:"..n..":"..v.."\n") end
  for n,v in pairs(stealsE) do f:write("SE:"..n..":"..v.."\n") end
  for n,v in pairs(foulsP)  do f:write("FP:"..n..":"..v.."\n") end
  for n,v in pairs(foulsE)  do f:write("FE:"..n..":"..v.."\n") end
  for q=1,currentQ-1 do
    local s=qScores[q]; if s then f:write("QS:"..q..":"..s[1]..":"..s[2].."\n") end
  end
  f:close()
end

function loadGame()
  local f=io.open(SAVE,"r"); if not f then return false end
  if f:read("*l")~="BBG_SAVE" then f:close(); return false end
  playerName=f:read("*l") or "Team"; enemyName=f:read("*l") or "Enemy"
  playerScore=tonumber(f:read("*l")) or 0; enemyScore=tonumber(f:read("*l")) or 0
  currentQ=tonumber(f:read("*l")) or 1; gameSec=tonumber(f:read("*l")) or QUARTER_SEC
  to30=tonumber(f:read("*l")) or 2; to60=tonumber(f:read("*l")) or 1
  careerWins=tonumber(f:read("*l")) or 0
  isMyCAGame=(tonumber(f:read("*l")) or 0)==1
  teamFoulsP=tonumber(f:read("*l")) or 0; teamFoulsE=tonumber(f:read("*l")) or 0
  ptsP={}; ptsE={}; astP={}; astE={}; stealsP={}; stealsE={}; foulsP={}; foulsE={}; qScores={}
  while true do
    local ln=f:read("*l"); if not ln then break end
    local px=ln:sub(1,3); local rest=ln:sub(4); local c=rest:find(":",1,true)
    if c then
      local k=rest:sub(1,c-1); local v=tonumber(rest:sub(c+1)) or 0
      if     px=="PP:" then ptsP[k]=v
      elseif px=="PE:" then ptsE[k]=v
      elseif px=="AP:" then astP[k]=v
      elseif px=="AE:" then astE[k]=v
      elseif px=="SP:" then stealsP[k]=v
      elseif px=="SE:" then stealsE[k]=v
      elseif px=="FP:" then foulsP[k]=v
      elseif px=="FE:" then foulsE[k]=v
      elseif px=="QS:" then
        local pts={}; for p in ln:gmatch("[^:]+") do table.insert(pts,p) end
        if #pts>=4 then local q=tonumber(pts[2]); if q then qScores[q]={tonumber(pts[3]) or 0,tonumber(pts[4]) or 0} end end
      end
    end
  end
  f:close()
  local cp,ce=0,0
  for q=1,currentQ-1 do local s=qScores[q]; if s then cp=cp+s[1]; ce=ce+s[2] end end
  qStartPlayer=cp; qStartEnemy=ce
  return true
end

function hasSave()
  local f=io.open(SAVE,"r"); if not f then return false end
  local l=f:read("*l"); f:close(); return l=="BBG_SAVE"
end
function delSave() os.remove(SAVE) end

-- ═══════════════════════════════════════════════════════════════
--  STATS HELPERS
-- ═══════════════════════════════════════════════════════════════
local function topOf(t)
  local bn,bv=nil,0; for n,v in pairs(t) do if v>bv then bn=n; bv=v end end; return bn,bv
end
local function bestPlayer()
  local bn,bt,bv="","",0; local pWin=(playerScore>=enemyScore)
  local function scan(pt,at,st,team,win)
    for n,p in pairs(pt) do
      local raw=p+(at[n] or 0)+(st[n] or 0)*1.5
      local score=win and (raw*1.1) or raw
      if score>bv then bn=n; bt=team; bv=score end
    end
  end
  scan(ptsP,astP,stealsP,playerName,pWin); scan(ptsE,astE,stealsE,enemyName,not pWin)
  return bn,bt,bv
end

-- ═══════════════════════════════════════════════════════════════
--  DISPLAY HELPERS
-- ═══════════════════════════════════════════════════════════════
function refreshClocks()
  local ql=(currentQ<=NUM_Q) and ("Q"..currentQ) or "OT"
  gcView.setText(ql.."  "..fmtTime(gameSec))
  if isTimeoutActive then scView.setText("TIMEOUT")
  elseif ftPending   then scView.setText("FREE THROW")
  else scView.setText("SHOT: "..shotSec) end
end
function refreshScore()
  pScoreV.setText(playerName..": "..playerScore); pScoreV.setTextColor(teamColor)
  eScoreV.setText(enemyName..": "..enemyScore)
end
function refreshTOBtn()
  toBtn.setText("TIMEOUT  30s:"..to30.."  60s:"..to60)
  local dis=(to30<=0 and to60<=0) or isGameOver or isTimeoutActive or ftPending
  toBtn.setEnabled(not dis); toBtn.setAlpha(dis and 0.5 or 1.0)
end

-- ═══════════════════════════════════════════════════════════════
--  SCORE ANNOUNCEMENT
-- ═══════════════════════════════════════════════════════════════
function announceScore(cb)
  task(1200,function()
    speak("Score. "..playerName.." "..playerScore..". "..enemyName.." "..enemyScore..".")
    task(4000,function() if cb then cb() end end)
  end)
end

-- ═══════════════════════════════════════════════════════════════
--  FOUL SYSTEM
-- ═══════════════════════════════════════════════════════════════
-- Record a foul on a player; handle foul-out if FOUL_LIMIT reached.
-- isPlayerTeam=true means it's a player-team player who fouled.
local function recordFoul(playerN, isPlayerTeam)
  local tbl  = isPlayerTeam and foulsP or foulsE
  local tfbl = isPlayerTeam and function() teamFoulsP=teamFoulsP+1 end
                             or function() teamFoulsE=teamFoulsE+1 end
  tbl[playerN] = (tbl[playerN] or 0) + 1
  tfbl()
  local fc = tbl[playerN]
  vibeFoul()
  speak(playerN.." is called for a foul. That is foul number "..fc.." for them.")
  if fc >= FOUL_LIMIT then
    speak(playerN.." has fouled out!")
    if isPlayerTeam then
      -- Force sub: find them in starters and swap with bench
      for i,s in ipairs(starters) do
        if s==playerN then
          if #bench>0 then
            local sub=bench[math.random(1,#bench)]
            starters[i]=sub; table.remove(bench,math.random(1,#bench))
            speak(sub.." checks in for the fouled-out "..playerN..".")
          end
          break
        end
      end
    else
      for i,s in ipairs(eStarters) do
        if s==playerN then
          if #eBench>0 then
            local idx=math.random(1,#eBench); local sub=eBench[idx]
            eStarters[i]=sub; table.remove(eBench,idx)
            speak(sub.." replaces fouled-out "..playerN.." for "..enemyName..".")
          end
          break
        end
      end
    end
  end
  return fc
end

-- Run a free-throw sequence.
-- shooter=player name, isPlayerTeam=who shoots, count=number of FTs,
-- basePts already scored (for and-1 announcements), cb=called when done
function doFreeThrows(shooter, isPlayerTeam, count, cb)
  ftPending=true; ftCount=count; ftMade=0; ftCallback=cb
  shootLayout.setVisibility(View.GONE)
  passBtn.setVisibility(View.GONE)
  ftBtn.setVisibility(View.VISIBLE)
  refreshClocks(); refreshTOBtn()

  local function shootOne(remaining)
    if remaining <= 0 then
      -- sequence done
      ftPending=false; ftCount=0
      ftBtn.setVisibility(View.GONE)
      refreshClocks(); refreshTOBtn()
      speak("Free throws done. "..ftMade.." of "..count.." made.")
      task(1500, function()
        if ftCallback then ftCallback() end
      end)
      return
    end

    speak("Free throw "..( count - remaining + 1 ).." of "..count
          ..". "..(isPlayerTeam and "Tap SHOOT!" or "Shooting...").." "
          ..(teamFoulsP>=TEAM_FOUL_BONUS or teamFoulsE>=TEAM_FOUL_BONUS and " (Bonus)" or ""))

    if isPlayerTeam then
      -- Player taps ftBtn within FT_WINDOW ms
      local tapped = false
      ftBtn.onClick = function()
        if not tapped then
          tapped = true
          local made = (math.random() < 0.80)   -- 80% success on tap
          if made then
            ftMade=ftMade+1; playerScore=playerScore+1
            ptsP[shooter]=(ptsP[shooter] or 0)+1
            vibeScore(); SFX.play("point-basket.mp3",false,false)
            speak("Good!")
          else
            SFX.play("Basketball Shot Rim - Short - Free Sound Effects(MP3_128K).mp3",false,false)
            speak("Missed!")
          end
          refreshScore()
          task(1800, function() shootOne(remaining-1) end)
        end
      end
      -- Auto-miss if no tap within FT_WINDOW
      task(FT_WINDOW, function()
        if not tapped then
          tapped=true
          local made = (math.random() < 0.40)  -- 40% if player didn't tap in time
          if made then
            ftMade=ftMade+1; playerScore=playerScore+1
            ptsP[shooter]=(ptsP[shooter] or 0)+1
            vibeScore(); SFX.play("point-basket.mp3",false,false)
            speak("Auto-made!")
          else
            SFX.play("Basketball Shot Rim - Short - Free Sound Effects(MP3_128K).mp3",false,false)
            speak("Missed!")
          end
          refreshScore()
          task(1800, function() shootOne(remaining-1) end)
        end
      end)
    else
      -- Enemy shoots automatically: 75% make rate
      task(2000, function()
        local made = (math.random() < 0.75)
        if made then
          ftMade=ftMade+1; enemyScore=enemyScore+1
          ptsE[shooter]=(ptsE[shooter] or 0)+1
          SFX.play("point-basket.mp3",false,false)
          speak(shooter.." makes it!")
        else
          SFX.play("Basketball Shot Rim - Short - Free Sound Effects(MP3_128K).mp3",false,false)
          speak(shooter.." misses!")
        end
        refreshScore()
        task(1800, function() shootOne(remaining-1) end)
      end)
    end
  end

  shootOne(count)
end

-- ═══════════════════════════════════════════════════════════════
--  SHOT CLOCK
-- ═══════════════════════════════════════════════════════════════
function startShotClock(fromVal)
  stopShot()
  shotSec=fromVal or (hasPerk("Fast Break") and 30 or SHOT_MAX)
  refreshClocks()
  shotTicker=Ticker(); shotTicker.Period=1000
  shotTicker.onTick=function()
    shotSec=shotSec-1; refreshClocks()
    if shotSec<=3 and shotSec>0 then speak(tostring(shotSec)) end
    if shotSec<=0 then
      stopShot(); stopGame(); SFX.stopAll()
      assistPending=false
      task(100,function()
        SFX.play("SHOT CLOCK SOUND EFFECT HD (NO COPYRIGHT)(MP3_128K).mp3",false,false)
        task(2000,function()
          speak("Shot clock violation!")
          announceScore(function() startPhase(possession=="player" and "enemy" or "player") end)
        end)
      end)
    end
  end
  shotTicker.start()
end

-- ═══════════════════════════════════════════════════════════════
--  GAME CLOCK
-- ═══════════════════════════════════════════════════════════════
function startGameClock()
  stopGame()
  gameTicker=Ticker(); gameTicker.Period=1000
  gameTicker.onTick=function()
    gameSec=gameSec-1; refreshClocks()
    if gameSec==30 then speak("30 seconds left in the quarter.") end
    if gameSec==10 then speak("10 seconds!") end
    if gameSec<=3 and gameSec>0 then speak(tostring(gameSec)) end
    if gameSec<=0 then stopGame(); stopShot(); endOfQuarter() end
  end
  gameTicker.start()
end
local function startBoth(shotFrom) startShotClock(shotFrom); startGameClock() end

-- ═══════════════════════════════════════════════════════════════
--  TIMEOUT
-- ═══════════════════════════════════════════════════════════════
function handleTimeout()
  if isGameOver or isTimeoutActive or ftPending then return end
  if to30<=0 and to60<=0 then return end
  if not shotTicker then return end
  local savedShot=shotSec; stopBoth()
  local opts={}; local durs={}
  if to30>0 then table.insert(opts,"30-Second Timeout (Remaining: "..to30..")"); table.insert(durs,30) end
  if to60>0 then table.insert(opts,"60-Second Timeout (Remaining: "..to60..")"); table.insert(durs,60) end
  table.insert(opts,"Substitution Menu")
  AlertDialog.Builder(activity).setTitle("Timeout Options")
    .setItems(opts,function(idx,val)
      local v=tostring(val)
      if v=="Substitution Menu" then
        if isTimeoutActive then showSubstitutionMenu()
        else speak("Call a timeout first."); task(200,function() startBoth(savedShot) end) end
        return
      end
      local dur=durs[idx+1] or 30
      if dur==30 then to30=to30-1; speak("30-second timeout!")
      else to60=to60-1; speak("60-second timeout!") end
      refreshTOBtn(); runTO(dur,savedShot)
    end)
    .setNegativeButton("Cancel",function() task(200,function() startBoth(savedShot) end) end)
    .show()
end

function runTO(duration,savedShot)
  isTimeoutActive=true; refreshTOBtn(); SFX.stopAll(); stopTO()
  local rem=duration; refreshClocks(); scView.setText("TIMEOUT: "..rem.."s")
  toTicker=Ticker(); toTicker.Period=1000
  toTicker.onTick=function()
    rem=rem-1; scView.setText("TIMEOUT: "..rem.."s")
    if rem==10 then speak("10 seconds left in timeout.") end
    if rem<=3 and rem>0 then speak(tostring(rem)) end
    if rem<=0 then
      stopTO()
      task(200,function()
        SFX.play("Sound Effects _ Referee Whistle Blow Gym(MP3_128K).mp3",false,false)
        task(1500,function()
          speak("Timeout over! Back to action!")
          isTimeoutActive=false
          task(1000,function()
            startGameClock(); startShotClock()
            refreshTOBtn(); refreshClocks()
            if possession=="player" then speak(activePlayer.." resumes for "..playerName..".")
            else speak(activePlayer.." of "..enemyName.." resumes attack.") end
          end)
        end)
      end)
    end
  end
  toTicker.start()
  speak("Timeout! Use Substitution to swap players.")
end

-- ═══════════════════════════════════════════════════════════════
--  SUBSTITUTION
-- ═══════════════════════════════════════════════════════════════
function showSubstitutionMenu()
  if not isTimeoutActive then speak("Call a timeout first."); return end
  local names={}; for _,p in ipairs(starters) do table.insert(names,p..(foulsP[p] and foulsP[p]>0 and " (F:"..foulsP[p]..")" or "")) end
  AlertDialog.Builder(activity).setTitle("Who subs OUT? — "..playerName)
    .setItems(names,function(si,sv)
      si=si+1; local outName=starters[si]
      local bNames={}; for _,p in ipairs(bench) do table.insert(bNames,p..(foulsP[p] and foulsP[p]>0 and " (F:"..foulsP[p]..")" or "")) end
      AlertDialog.Builder(activity).setTitle("Who comes IN?")
        .setItems(bNames,function(bi,bv)
          bi=bi+1; local newP=bench[bi]
          bench[bi]=starters[si]; starters[si]=newP
          if activePlayer==outName then activePlayer=newP end
          SFX.play("ball bouncing with sound(MP3_128K).mp3",false,false)
          speak("Sub! "..outName.." out. "..newP.." checks in for "..playerName.."!")
        end).show()
    end).show()
end

-- ═══════════════════════════════════════════════════════════════
--  QUARTER / HALFTIME / GAME END
-- ═══════════════════════════════════════════════════════════════
local function hideGameControls()
  shootLayout.setVisibility(View.GONE); passBtn.setVisibility(View.GONE)
  ftBtn.setVisibility(View.GONE); toBtn.setVisibility(View.GONE); subBtn.setVisibility(View.GONE)
end

local function showContinueButton(label,action)
  qBreakLabel.setVisibility(View.VISIBLE)
  contBtn.setText(label); contBtn.setVisibility(View.VISIBLE)
  contBtn.onClick=function()
    qBreakLabel.setVisibility(View.GONE); contBtn.setVisibility(View.GONE); action()
  end
end

function endOfQuarter()
  if isGameOver then return end
  isBusy=true; assistPending=false; ftPending=false
  SFX.stopAll(); hideGameControls()
  qScores[currentQ]={playerScore-qStartPlayer,enemyScore-qStartEnemy}
  if currentQ==2 then doHalftime()
  elseif currentQ>=NUM_Q then doGameEnd()
  else
    local nextQ=currentQ+1
    speak("End of quarter "..currentQ.."! "..playerName.." "..playerScore.." — "..enemyName.." "..enemyScore..".")
    qBreakLabel.setText("END OF Q"..currentQ.."\n"..playerName..": "..playerScore.."\n"..enemyName..": "..enemyScore)
    showContinueButton("Continue to Quarter "..nextQ,function()
      currentQ=nextQ; gameSec=QUARTER_SEC; qStartPlayer=playerScore; qStartEnemy=enemyScore
      isBusy=false; toBtn.setVisibility(View.VISIBLE); subBtn.setVisibility(View.VISIBLE)
      refreshScore(); refreshClocks(); refreshTOBtn()
      speak("Quarter "..currentQ..". Get ready!")
      task(800,function() jumpBallBtn.setVisibility(View.VISIBLE) end)
    end)
  end
end

function doHalftime()
  SFX.play("ITO ANG LIGA(MP3_128K).mp3",true,false,menuVol)
  -- Reset team fouls for 2nd half
  teamFoulsP=0; teamFoulsE=0
  local tpN,tpV=topOf(ptsP); local teN,teV=topOf(ptsE)
  local taN,taV=topOf(astP); local tsN,tsV=topOf(stealsP)
  local scoreLine
  if     playerScore>enemyScore then scoreLine=playerName.." leads "..playerScore.." to "..enemyScore.."."
  elseif enemyScore>playerScore then scoreLine=enemyName.." leads "..enemyScore.." to "..playerScore.."."
  else scoreLine="Tied at "..playerScore.." all." end
  local spk="Halftime! "..scoreLine
  if tpN then spk=spk.." Top scorer "..playerName..": "..tpN..", "..tpV.."pts." end
  if teN then spk=spk.." Top scorer "..enemyName..": "..teN..", "..teV.."pts." end
  speak(spk)
  task(9000,function()
    local q1=qScores[1] or {0,0}; local q2=qScores[2] or {0,0}
    local msg="HALFTIME — "..scoreLine.."\n\n"
      .."Q1: "..playerName.." "..q1[1].." — "..enemyName.." "..q1[2].."\n"
      .."Q2: "..playerName.." "..q2[1].." — "..enemyName.." "..q2[2].."\n"
    if tpN then msg=msg.."\n"..playerName.." scorer: "..tpN.." ("..tpV.."pts)" end
    if teN then msg=msg.."\n"..enemyName.." scorer: "..teN.." ("..teV.."pts)" end
    if taN and taV>0 then msg=msg.."\nTop assists: "..taN.." ("..taV.."ast)" end
    if tsN and tsV>0 then msg=msg.."\nTop steals: "..tsN.." ("..tsV.."stl)" end
    msg=msg.."\n\nTeam fouls reset for 2nd half."
    qBreakLabel.setText("HALFTIME\n\n"..scoreLine)
    AlertDialog.Builder(activity).setTitle("HALFTIME").setMessage(msg)
      .setPositiveButton("OK",function()
        showContinueButton("Start 2nd Half",function()
          SFX.stopAll(); to30=2; to60=1; currentQ=3; gameSec=QUARTER_SEC
          qStartPlayer=playerScore; qStartEnemy=enemyScore; isBusy=false
          toBtn.setVisibility(View.VISIBLE); subBtn.setVisibility(View.VISIBLE)
          refreshScore(); refreshClocks(); refreshTOBtn()
          speak("Second half! Quarter 3. Get ready!")
          task(800,function() jumpBallBtn.setVisibility(View.VISIBLE) end)
        end)
      end).setCancelable(false).show()
  end)
end

function doGameEnd()
  if currentQ==NUM_Q and playerScore==enemyScore then
    speak("Tied at "..playerScore.."! Overtime!")
    currentQ=NUM_Q+1; gameSec=OT_SEC; qStartPlayer=playerScore; qStartEnemy=enemyScore; isBusy=false
    qBreakLabel.setText("OVERTIME!\nTied "..playerScore.." — "..enemyScore)
    showContinueButton("Start Overtime",function()
      toBtn.setVisibility(View.VISIBLE); subBtn.setVisibility(View.VISIBLE)
      refreshClocks(); refreshTOBtn()
      speak("Overtime! Get ready!")
      task(500,function() jumpBallBtn.setVisibility(View.VISIBLE) end)
    end)
    return
  end
  isGameOver=true; isBusy=true; SFX.stopAll()
  if playerScore>enemyScore then careerWins=careerWins+1; checkUnlocks(); saveProgress() end
  if isMyCAGame and myCA then
    myCA.gamesPlayed=myCA.gamesPlayed+1
    myCA.totalPoints=myCA.totalPoints+(ptsP[myCA.name] or 0)
    myCA.totalAssists=myCA.totalAssists+(astP[myCA.name] or 0)
    if playerScore>enemyScore then myCA.careerWins=myCA.careerWins+1 end
    saveCA()
  end
  isMyCAGame=false; delSave()
  local tpN,tpV=topOf(ptsP); local teN,teV=topOf(ptsE)
  local taN,taV=topOf(astP); local taEN,taEV=topOf(astE)
  local tsN,tsV=topOf(stealsP); local tsEN,tsEV=topOf(stealsE)
  local bpN,bpT,_=bestPlayer()
  local winner
  if     playerScore>enemyScore then winner=playerName
  elseif enemyScore>playerScore then winner=enemyName
  else winner="TIE" end
  local title=(winner=="TIE") and "FINAL — TIE!" or ("FINAL — "..winner.." Wins!")
  local msg=((winner=="TIE") and "Tie! " or (winner.." wins! "))
    ..playerName.." "..playerScore.." — "..enemyName.." "..enemyScore.."\n\nQUARTER SCORES:\n"
  for q=1,currentQ do
    local s=qScores[q]; if s then
      local lbl=(q<=NUM_Q) and ("Q"..q) or "OT"
      msg=msg..lbl..": "..playerName.." "..s[1].." — "..enemyName.." "..s[2].."\n"
    end
  end
  msg=msg.."\n--- STATS ---\n"
  if tpN then msg=msg..playerName.." scorer: "..tpN.." ("..tpV.."pts)\n" end
  if teN then msg=msg..enemyName.." scorer: "..teN.." ("..teV.."pts)\n" end
  if taN and taV>0 then msg=msg..playerName.." assists: "..taN.." ("..taV.."ast)\n" end
  if taEN and taEV>0 then msg=msg..enemyName.." assists: "..taEN.." ("..taEV.."ast)\n" end
  if tsN and tsV>0 then msg=msg..playerName.." steals: "..tsN.." ("..tsV.."stl)\n" end
  if tsEN and tsEV>0 then msg=msg..enemyName.." steals: "..tsEN.." ("..tsEV.."stl)\n" end
  if bpN~="" then msg=msg.."\nBEST PLAYER: "..bpN.." ("..bpT..")" end
  local spk=(winner=="TIE") and "Final! Tie! Both teams "..playerScore.." points!"
    or "Final! "..winner.." wins! "..playerName.." "..playerScore.." to "..enemyName.." "..enemyScore.."!"
  if bpN~="" then spk=spk.." Best player: "..bpN.." of the "..bpT.."." end
  speak(spk); SFX.play("Victory Sound Effect(MP3_128K).mp3",false,false)
  task(6000,function()
    AlertDialog.Builder(activity).setTitle(title).setMessage(msg)
      .setPositiveButton("Back to Menu",function() showMainMenu() end).setCancelable(false).show()
  end)
end

-- ═══════════════════════════════════════════════════════════════
--  JUMP BALL
-- ═══════════════════════════════════════════════════════════════
function handleJumpBall()
  isBusy=true; jumpBallBtn.setVisibility(View.GONE)
  speak("Ready. 3. 2. 1.")
  task(1000,function() pulse(200) end)
  task(2000,function() pulse(200) end)
  task(3000,function() pulse(600) end)
  task(3500,function()
    SFX.play("Sound Effects _ Referee Whistle Blow Gym(MP3_128K).mp3",false,false)
    task(3000,function()
      SFX.play("ball bouncing with sound(MP3_128K).mp3",true,true)
      SFX.play("Basketball Game Crowd Sound Effect  [ HD ](MP3_128K).mp3",true,true)
    end)
    task(math.random(8000,12000),function()
      SFX.stopBg(); isBusy=false
      if math.random(0,1)==1 then
        speak(playerName.." wins the jump ball!")
        task(1500,function() startPhase("player") end)
      else
        speak(enemyName.." wins the jump ball!")
        task(1500,function() startPhase("enemy") end)
      end
    end)
  end)
end

-- ═══════════════════════════════════════════════════════════════
--  GAME PHASE  (FIX: stopBg instead of stopAll so score sounds finish)
-- ═══════════════════════════════════════════════════════════════
function startPhase(side, isRemote)
  if isOnline and not isRemote then relayAction({action="start_phase",side=side}) end
  if isGameOver then return end
  stopBoth(); SFX.stopBg()   -- ← stop looping BG only, leave score sounds
  possession=side; isBusy=false; ftPending=false
  assistPending=false; assistFrom=""; assistWho=""

  -- Build 12-player rosters on first possession
  if #playerRoster==0 then
    local full=nil
    for _,teams in pairs(LEAGUE_DATA) do if teams[playerName] then full=teams[playerName]; break end end
    if not full then full={}; for i=1,12 do table.insert(full,PLAYER_NAME_POOL[math.random(1,#PLAYER_NAME_POOL)]) end end
    playerRoster=full; starters={}; bench={}
    for i=1,5 do table.insert(starters,full[i]) end
    for i=6,#full do table.insert(bench,full[i]) end
  end
  if #enemyRoster==0 then
    local e=nil
    for _,teams in pairs(LEAGUE_DATA) do if teams[enemyName] then e=teams[enemyName]; break end end
    if not e then e={}; for i=1,12 do table.insert(e,PLAYER_NAME_POOL[math.random(1,#PLAYER_NAME_POOL)]) end end
    enemyRoster=e; eStarters={}; eBench={}
    for i=1,5 do table.insert(eStarters,e[i]) end
    for i=6,#e do table.insert(eBench,e[i]) end
  end

  local lanes={"left","center","right"}
  table.remove(lanes,math.random(1,3)); blockedLanes=lanes

  SFX.play("Sound Effects _ Referee Whistle Blow Gym(MP3_128K).mp3",false,false)
  task(1500,function()
    SFX.play("Dribbling Basketball _ HQ Sound Effects(MP3_128K).mp3",true,true)
    SFX.play("Basketball Game Crowd Sound Effect  [ HD ](MP3_128K).mp3",true,true)
    qBreakLabel.setVisibility(View.GONE); contBtn.setVisibility(View.GONE)
    ftBtn.setVisibility(View.GONE)
    shootLayout.setVisibility(View.VISIBLE)
    toBtn.setVisibility(View.VISIBLE); subBtn.setVisibility(View.VISIBLE)
    if side=="player" then
      activePlayer=starters[math.random(1,#starters)]
      passBtn.setVisibility(View.VISIBLE)
      speak(activePlayer.." on the "..playerName.." has the ball. Predict the open lane!")
    else
      passBtn.setVisibility(View.GONE)
      SFX.play("defense-nba.mp3",true,true)
      activePlayer=eStarters[math.random(1,#eStarters)]
      speak("Defense! "..activePlayer.." from "..enemyName.." is attacking! Pick the lane!")
      aiCheckStrategy()
    end
    startBoth(nil)
    refreshScore(); refreshClocks(); refreshTOBtn()
  end)
end

-- ═══════════════════════════════════════════════════════════════
--  AI STRATEGY
-- ═══════════════════════════════════════════════════════════════
function aiCheckStrategy()
  if enemyScore<playerScore-15 and math.random()<0.3 and not isTimeoutActive then
    speak(enemyName.." calls a strategic timeout!")
    isTimeoutActive=true
    if #eStarters>0 and #eBench>0 then
      local si=math.random(1,#eStarters); local bi=math.random(1,#eBench)
      local old=eStarters[si]; eStarters[si]=eBench[bi]; eBench[bi]=old
      speak("Strategic sub made by "..enemyName..".")
    end
    task(8000,function() isTimeoutActive=false; speak(enemyName.." timeout over.") end)
  end
end

-- ═══════════════════════════════════════════════════════════════
--  HANDLE ACTION  (with foul system)
-- ═══════════════════════════════════════════════════════════════
function handleAction(side, isRemote)
  if isGameOver or isBusy or isTimeoutActive or ftPending then return end
  if not shotTicker then return end

  -- ONLINE MODE
  if isOnline then
    if isRemote then remoteLane=side
    else localLane=side; relayAction({action="handle_action",lane=side}); speak("Lane confirmed. Waiting for opponent.") end
    if not localLane or not remoteLane then return end
    isBusy=true; pcall(function() shotTicker.stop() end)
    task(100,function()
      if possession=="player" then
        if localLane==remoteLane then
          SFX.play("defense-nba.mp3",false,false); vibeBlock()
          speak("Blocked by "..enemyName.."! Turnover.")
          task(2000,function() startPhase("enemy") end)
        else
          local pts=(localLane=="left" and 3) or (localLane=="right" and 2) or 1
          playerScore=playerScore+pts; vibeScore()
          SFX.play("basketball-swish_OMsr9CN.mp3",false,false)
          speak("Swish! "..playerName.." scores "..pts.."!"); refreshScore()
          task(1500,function() startPhase("enemy") end)
        end
      else
        if localLane==remoteLane then
          vibeSteal(); SFX.play("basketball-swish_OMsr9CN.mp3",false,false)
          speak("Steal by "..playerName.."!"); task(1500,function() startPhase("player") end)
        else
          local pts=(remoteLane=="left" and 3) or (remoteLane=="right" and 2) or 1
          enemyScore=enemyScore+pts; SFX.play("basketball-swish_OMsr9CN.mp3",false,false)
          speak("Failed block. "..enemyName.." scores "..pts.."."); refreshScore()
          task(1500,function() startPhase("player") end)
        end
      end
      if networkRole=="player" then relayAction({action="score_sync",p_score=playerScore,e_score=enemyScore}) end
    end)
    return
  end

  -- OFFLINE MODE
  isBusy=true; stopBoth(); SFX.stopBg()

  if possession=="player" then
    -- Check if blocked
    local blocked=false
    for _,ln in ipairs(blockedLanes) do if side==ln then blocked=true; break end end

    if blocked then
      assistPending=false
      local blocker=eStarters[math.random(1,math.max(1,#eStarters))]

      -- 20% chance: blocker commits a foul → player gets 2 FTs
      if math.random() < 0.20 then
        vibeFoul()
        SFX.play("Sound Effects _ Referee Whistle Blow Gym(MP3_128K).mp3",false,false)
        task(800,function()
          local fc=recordFoul(blocker, false)   -- foul on enemy player
          speak("Foul on "..blocker.."! "..activePlayer.." shoots 2 free throws.")
          task(1500,function()
            doFreeThrows(activePlayer, true, 2, function()
              announceScore(function() startPhase("enemy") end)
            end)
          end)
        end)
      else
        -- Clean block
        vibeBlock()
        SFX.play("defense-nba.mp3",false,false)
        task(600,function() SFX.play("Sound Effects _ Referee Whistle Blow Gym(MP3_128K).mp3",false,false) end)
        task(1500,function()
          speak("Blocked by "..blocker.."! Turnover.")
          announceScore(function() startPhase("enemy") end)
        end)
      end
    else
      -- Scored
      local pts=(side=="left" and 3 or (side=="right" and 2 or 1))
      if hasPerk("Clutch") and playerScore<enemyScore and enemyScore>20 then
        if math.random()<0.3 then pts=pts+1; speak("AND ONE opportunity!") end
      end
      local ptx=(pts==3 and "three") or (pts==2 and "two") or "one"
      if pts==4 then ptx="four" end
      playerScore=playerScore+pts
      ptsP[activePlayer]=(ptsP[activePlayer] or 0)+pts
      if assistPending and assistFrom~="" and assistWho==activePlayer then
        astP[assistFrom]=(astP[assistFrom] or 0)+1; speak("Assist by "..assistFrom.."!")
      end
      assistPending=false; vibeScore()

      -- Play score sound first, THEN check for and-1 foul
      if side=="left" then
        SFX.play("Nba Bubble PA Announcer Three-pointer Sound(MP3_128K).mp3",false,false)
        task(600,function() SFX.play("point-basket.mp3",false,false) end)
      elseif side=="right" then
        SFX.play("Basketball Shot Rim - Short - Free Sound Effects(MP3_128K).mp3",false,false)
      else
        SFX.play("point-basket.mp3",false,false)
      end

      task(1200,function()
        speak(activePlayer.." scores "..ptx.." point"..(pts==1 and "" or "s").."!")
        refreshScore()

        -- 15% chance of and-1 foul on the shooter
        if pts<=3 and math.random()<0.15 then
          local fouler=eStarters[math.random(1,math.max(1,#eStarters))]
          task(800,function()
            vibeFoul()
            SFX.play("Sound Effects _ Referee Whistle Blow Gym(MP3_128K).mp3",false,false)
            task(600,function()
              recordFoul(fouler, false)
              speak("And one! Foul on "..fouler.."! "..activePlayer.." goes to the line.")
              task(1200,function()
                doFreeThrows(activePlayer, true, 1, function()
                  announceScore(function() startPhase("enemy") end)
                end)
              end)
            end)
          end)
        else
          task(1000,function() announceScore(function() startPhase("enemy") end) end)
        end
      end)
    end

  else
    -- DEFENSE
    local attackLane=nil
    for _,l in ipairs({"left","center","right"}) do
      local bl=false
      for _,b in ipairs(blockedLanes) do if l==b then bl=true; break end end
      if not bl then attackLane=l; break end
    end
    if not attackLane then attackLane="center" end

    local stolen=(side==attackLane)
    if not stolen and hasPerk("Lockdown") and math.random()<0.15 then stolen=true; speak("Lockdown Defense!") end

    if stolen then
      vibeSteal()
      SFX.play("ball bouncing with sound(MP3_128K).mp3",false,false)
      task(400,function() SFX.play("basketball-swish_OMsr9CN.mp3",false,false) end)
      task(1500,function()
        local st=starters[math.random(1,math.max(1,#starters))]
        stealsP[st]=(stealsP[st] or 0)+1

        -- 10% chance: foul called on the steal → enemy gets 2 FTs
        if math.random()<0.10 then
          local fouler=starters[math.random(1,math.max(1,#starters))]
          vibeFoul()
          SFX.play("Sound Effects _ Referee Whistle Blow Gym(MP3_128K).mp3",false,false)
          task(600,function()
            recordFoul(fouler, true)
            speak("Foul on the steal! "..fouler.." fouled "..activePlayer..". "..activePlayer.." shoots 2 free throws.")
            task(1200,function()
              doFreeThrows(activePlayer, false, 2, function()
                announceScore(function() startPhase("player") end)
              end)
            end)
          end)
        else
          speak("Steal by "..st.."! Ball to "..playerName.."!")
          announceScore(function() startPhase("player") end)
        end
      end)
    else
      -- Enemy scores
      local ep=(attackLane=="left" and 3 or (attackLane=="right" and 2 or 1))
      local etx=(ep==3 and "three") or (ep==2 and "two") or "one"
      enemyScore=enemyScore+ep
      ptsE[activePlayer]=(ptsE[activePlayer] or 0)+ep

      -- Enemy score sound
      SFX.play("basketball-swish_OMsr9CN.mp3",false,false)

      task(1200,function()
        speak(activePlayer.." of "..enemyName.." scores "..etx.." point"..(ep==1 and "" or "s").."!")
        refreshScore()

        -- 15% and-1 on defender
        if math.random()<0.15 then
          local fouler=starters[math.random(1,math.max(1,#starters))]
          task(800,function()
            vibeFoul()
            SFX.play("Sound Effects _ Referee Whistle Blow Gym(MP3_128K).mp3",false,false)
            task(600,function()
              recordFoul(fouler, true)
              speak("And one! Foul on "..fouler.."! "..activePlayer.." shoots 1 free throw.")
              task(1200,function()
                doFreeThrows(activePlayer, false, 1, function()
                  announceScore(function() startPhase("player") end)
                end)
              end)
            end)
          end)
        else
          task(1000,function() announceScore(function() startPhase("player") end) end)
        end
      end)
    end
  end
end

-- ═══════════════════════════════════════════════════════════════
--  PASS
-- ═══════════════════════════════════════════════════════════════
function handlePass()
  if possession~="player" or isBusy or isTimeoutActive or ftPending then return end
  if #starters<2 then return end
  local passer=activePlayer; local newP=activePlayer; local tries=0
  while newP==activePlayer and tries<10 do newP=starters[math.random(1,#starters)]; tries=tries+1 end
  assistPending=true; assistFrom=passer; assistWho=newP; activePlayer=newP
  SFX.play("ball bouncing with sound(MP3_128K).mp3",false,false); vibeDribble()
  speak("Ball passed to "..activePlayer.."!")
  task(3000,function() if assistPending then assistPending=false end end)
end

-- ═══════════════════════════════════════════════════════════════
--  EXIT
-- ═══════════════════════════════════════════════════════════════
function confirmExit()
  stopBoth()
  AlertDialog.Builder(activity).setTitle("Exit Match?").setMessage("What would you like to do?")
    .setPositiveButton("Save & Exit",function()
      saveGame(); isGameOver=true; SFX.stopAll()
      speak("Game saved."); task(800,function() showMainMenu() end)
    end)
    .setNeutralButton("Exit (No Save)",function()
      delSave(); isGameOver=true; SFX.stopAll(); showMainMenu()
    end)
    .setNegativeButton("Resume",function()
      if not isGameOver then task(300,function() startGameClock(); startShotClock(shotSec) end) end
    end)
    .show()
end
function confirmQuit()
  AlertDialog.Builder(activity).setTitle("Quit App?").setMessage("Close the application?")
    .setPositiveButton("YES",function()
      isGameOver=true; SFX.stopAll()
      if tts then pcall(function() tts.stop(); tts.shutdown(); tts=nil end) end
      task(300,function() activity.finish() end)
    end)
    .setNegativeButton("NO",nil).show()
end

-- ═══════════════════════════════════════════════════════════════
--  MATCH SETUP
-- ═══════════════════════════════════════════════════════════════
function setupMatch(pName,pColor)
  playerName=pName; teamColor=pColor
  isGameOver=false; isBusy=false; isTimeoutActive=false; ftPending=false
  playerScore=0; enemyScore=0; currentQ=1; gameSec=QUARTER_SEC
  qStartPlayer=0; qStartEnemy=0; qScores={}
  ptsP={}; ptsE={}; astP={}; astE={}; stealsP={}; stealsE={}
  foulsP={}; foulsE={}; teamFoulsP=0; teamFoulsE=0
  to30=2; to60=1
  playerRoster={}; enemyRoster={}; starters={}; bench={}; eStarters={}; eBench={}
  local eIdx=math.random(1,#ALL_TEAMS)
  while ALL_TEAMS[eIdx]==playerName do eIdx=math.random(1,#ALL_TEAMS) end
  enemyName=ALL_TEAMS[eIdx]
  if hasPerk("Legendary") then playerScore=5; ptsP["Legendary Bonus"]=5; speak("Legends never die!") end
  gameLayout.setVisibility(View.VISIBLE)
  qBreakLabel.setVisibility(View.GONE); contBtn.setVisibility(View.GONE)
  shootLayout.setVisibility(View.GONE); passBtn.setVisibility(View.GONE)
  ftBtn.setVisibility(View.GONE)
  jumpBallBtn.setVisibility(View.VISIBLE)
  toBtn.setVisibility(View.VISIBLE); subBtn.setVisibility(View.VISIBLE)
  refreshScore(); refreshClocks(); refreshTOBtn()
  speak("Match setup. "..playerName.." vs "..enemyName..". Prepare for jump ball!")
end

-- ═══════════════════════════════════════════════════════════════
--  BUILD UI
-- ═══════════════════════════════════════════════════════════════
mainLayout=LinearLayout(activity); mainLayout.setOrientation(1)
mainLayout.setBackgroundColor(Color.BLACK); mainLayout.setPadding(20,20,20,20)

scoreBoard=LinearLayout(activity); scoreBoard.setOrientation(0)
pScoreV=TextView(activity); pScoreV.setTextSize(18); pScoreV.setTextColor(Color.WHITE)
pScoreV.setLayoutParams(LinearLayout.LayoutParams(0,-2,1))
eScoreV=TextView(activity); eScoreV.setTextColor(Color.LTGRAY); eScoreV.setTextSize(18)
eScoreV.setGravity(Gravity.RIGHT); eScoreV.setLayoutParams(LinearLayout.LayoutParams(0,-2,1))
scoreBoard.addView(pScoreV); scoreBoard.addView(eScoreV)
mainLayout.addView(scoreBoard)

gameLayout=LinearLayout(activity); gameLayout.setOrientation(1); gameLayout.setVisibility(View.GONE)

clockRow=LinearLayout(activity); clockRow.setOrientation(0); clockRow.setPadding(0,10,0,10)
gcView=TextView(activity); gcView.setTextColor(Color.YELLOW); gcView.setTextSize(22)
gcView.setLayoutParams(LinearLayout.LayoutParams(0,-2,1))
scView=TextView(activity); scView.setTextColor(Color.CYAN); scView.setTextSize(22)
scView.setGravity(Gravity.RIGHT); scView.setLayoutParams(LinearLayout.LayoutParams(0,-2,1))
clockRow.addView(gcView); clockRow.addView(scView)
gameLayout.addView(clockRow)

qBreakLabel=TextView(activity); qBreakLabel.setTextColor(Color.WHITE); qBreakLabel.setTextSize(18)
qBreakLabel.setGravity(Gravity.CENTER); qBreakLabel.setPadding(0,20,0,10)
qBreakLabel.setVisibility(View.GONE); gameLayout.addView(qBreakLabel)

contBtn=Button(activity); contBtn.setText("Continue"); contBtn.setVisibility(View.GONE); gameLayout.addView(contBtn)
jumpBallBtn=Button(activity); jumpBallBtn.setText("JUMP BALL"); jumpBallBtn.setVisibility(View.GONE); gameLayout.addView(jumpBallBtn)
passBtn=Button(activity); passBtn.setText("PASS THE BALL"); passBtn.setVisibility(View.GONE); gameLayout.addView(passBtn)

shootLayout=LinearLayout(activity); shootLayout.setOrientation(0); shootLayout.setVisibility(View.GONE)
btnL=Button(activity); btnL.setText("LEFT (3PT)");   btnL.setLayoutParams(LinearLayout.LayoutParams(0,200,1))
btnC=Button(activity); btnC.setText("CENTER (1PT)"); btnC.setLayoutParams(LinearLayout.LayoutParams(0,200,1))
btnR=Button(activity); btnR.setText("RIGHT (2PT)");  btnR.setLayoutParams(LinearLayout.LayoutParams(0,200,1))
shootLayout.addView(btnL); shootLayout.addView(btnC); shootLayout.addView(btnR)
gameLayout.addView(shootLayout)

ftBtn=Button(activity); ftBtn.setText("SHOOT FREE THROW"); ftBtn.setVisibility(View.GONE); gameLayout.addView(ftBtn)

toBtn=Button(activity);   toBtn.setText("TIMEOUT");            toBtn.setVisibility(View.GONE);  gameLayout.addView(toBtn)
subBtn=Button(activity);  subBtn.setText("SUBSTITUTION");      subBtn.setVisibility(View.GONE); gameLayout.addView(subBtn)
backBtn=Button(activity); backBtn.setText("Save & Back to Menu"); gameLayout.addView(backBtn)

mainLayout.addView(gameLayout)
activity.setContentView(mainLayout)

-- ═══════════════════════════════════════════════════════════════
--  BUTTON HANDLERS
-- ═══════════════════════════════════════════════════════════════
jumpBallBtn.onClick = function() handleJumpBall() end
passBtn.onClick     = function() handlePass() end
btnL.onClick        = function() handleAction("left") end
btnC.onClick        = function() handleAction("center") end
btnR.onClick        = function() handleAction("right") end
toBtn.onClick       = function() handleTimeout() end
subBtn.onClick      = function() showSubstitutionMenu() end
backBtn.onClick     = function() confirmExit() end
-- ftBtn.onClick is set dynamically inside doFreeThrows

-- ═══════════════════════════════════════════════════════════════
--  MAIN MENU  (FIX: resume game is now a MENU ITEM, not a startup popup)
-- ═══════════════════════════════════════════════════════════════
function showMenuDialog()
  local opts={}
  if hasSave() then table.insert(opts,"Resume Saved Game") end  -- only if save exists
  table.insert(opts,"Exhibition Match")
  table.insert(opts,"Career Mode")
  table.insert(opts,"My Career Account")
  table.insert(opts,"Play Online")
  table.insert(opts,"About & Instructions")
  table.insert(opts,"Settings")
  table.insert(opts,"QUIT")

  AlertDialog.Builder(activity)
    .setTitle("Blind Basketball Game")
    .setMessage("Created by Darry John Sarmiento")
    .setItems(opts,function(i,item)
      local v=tostring(item)
      if v=="Resume Saved Game" then
        if loadGame() then
          teamColor=Color.WHITE; isGameOver=false; isBusy=false; isTimeoutActive=false; ftPending=false
          playerRoster={}; enemyRoster={}; starters={}; bench={}; eStarters={}; eBench={}
          gameLayout.setVisibility(View.VISIBLE)
          qBreakLabel.setVisibility(View.GONE); contBtn.setVisibility(View.GONE)
          shootLayout.setVisibility(View.GONE); passBtn.setVisibility(View.GONE)
          ftBtn.setVisibility(View.GONE); jumpBallBtn.setVisibility(View.VISIBLE)
          toBtn.setVisibility(View.VISIBLE); subBtn.setVisibility(View.VISIBLE)
          refreshScore(); refreshClocks(); refreshTOBtn()
          speak("Resumed. Quarter "..currentQ..". "..playerName.." "..playerScore.." — "..enemyName.." "..enemyScore..".")
        else speak("Could not load save."); delSave() end
      elseif v=="Exhibition Match"     then showLeague("exhibition")
      elseif v=="Career Mode"          then showLeague("career")
      elseif v=="My Career Account"    then showMC()
      elseif v=="Play Online"          then showOnlineMenu()
      elseif v=="About & Instructions" then showAbout()
      elseif v=="Settings"             then showSettings()
      elseif v=="QUIT"                 then confirmQuit() end
    end)
    .setCancelable(false).show()
end

function showMainMenu()
  isGameOver=true; isBusy=false; isTimeoutActive=false; ftPending=false
  SFX.stopAll()
  gameLayout.setVisibility(View.GONE); pScoreV.setText(""); eScoreV.setText("")
  SFX.play("ITO ANG LIGA(MP3_128K).mp3",true,false,menuVol)
  showMenuDialog()   -- straight to menu — no startup popup
end

-- ═══════════════════════════════════════════════════════════════
--  ABOUT
-- ═══════════════════════════════════════════════════════════════
function showAbout()
  local info=
    "HOW TO PLAY:\n\n"
    .."OFFENSE: Tap LEFT=3pt, CENTER=1pt, RIGHT=2pt.\n"
    .."DEFENSE: Predict the enemy lane to steal the ball.\n"
    .."PASS: Pass to a teammate. Score within 3s = assist.\n"
    .."TIMEOUT: 2x30s and 1x60s per half. Resets at halftime.\n"
    .."SUBSTITUTION: Swap players during a live timeout.\n"
    .."FOULS: Players foul out at 6 fouls. Foul shots awarded.\n"
    .."FREE THROWS: Tap SHOOT FREE THROW button within 4 seconds.\n"
    .."GAME: 4 quarters x 12 minutes. Halftime after Q2. 5-min OT.\n\n"
    .."ACCESSIBILITY FEATURES:\n\n"
    .."HAPTIC FEEDBACK:\n"
    .."  Short tap   = Pass or dribble\n"
    .."  3x pulses   = You scored!\n"
    .."  Long 1000ms = Blocked!\n"
    .."  Double tap  = Steal!\n"
    .."  2x 300ms    = Foul called!\n\n"
    .."CAREER PERKS:\n"
    .."  3 wins  — Fast Break : shot clock +6s\n"
    .."  7 wins  — Lockdown   : 15% extra steal chance\n"
    .." 12 wins  — Clutch     : 30% bonus point when trailing\n"
    .." 20 wins  — Legendary  : start every match +5 points\n\n"
    .."LEAGUES: NBA, PBA, MPBL\n\n"
    .."Created by Darry John Sarmiento\n"
    .."Community: t.me/gwapokobay1639"
  AlertDialog.Builder(activity).setTitle("About & Instructions").setMessage(info)
    .setPositiveButton("Join Telegram",function()
      activity.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://t.me/gwapokobay1639")))
    end)
    .setNegativeButton("Back",nil).show()
end

-- ═══════════════════════════════════════════════════════════════
--  SETTINGS
-- ═══════════════════════════════════════════════════════════════
function showSettings()
  local cont=LinearLayout(activity); cont.setOrientation(1); cont.setPadding(20,10,20,10)
  local sfxLbl=TextView(activity); sfxLbl.setTextColor(Color.WHITE); sfxLbl.setText("Sound FX: "..math.floor(sfxVol*100).."%")
  local sfxBar=SeekBar(activity);  sfxBar.setMax(100); sfxBar.setProgress(math.floor(sfxVol*100))
  local bgLbl=TextView(activity);  bgLbl.setTextColor(Color.WHITE);  bgLbl.setText("Crowd / BG: "..math.floor(bgVol*100).."%")
  local bgBar=SeekBar(activity);   bgBar.setMax(100); bgBar.setProgress(math.floor(bgVol*100))
  local muLbl=TextView(activity);  muLbl.setTextColor(Color.WHITE);  muLbl.setText("Menu Music: "..math.floor(menuVol*100).."%")
  local muBar=SeekBar(activity);   muBar.setMax(100); muBar.setProgress(math.floor(menuVol*100))
  cont.addView(sfxLbl); cont.addView(sfxBar); cont.addView(bgLbl); cont.addView(bgBar); cont.addView(muLbl); cont.addView(muBar)
  sfxBar.setOnSeekBarChangeListener(SeekBar.OnSeekBarChangeListener{
    onProgressChanged=function(sb,p,fu) sfxVol=p/100.0; sfxLbl.setText("Sound FX: "..p.."%") end,
    onStartTrackingTouch=function(sb) end, onStopTrackingTouch=function(sb) end})
  bgBar.setOnSeekBarChangeListener(SeekBar.OnSeekBarChangeListener{
    onProgressChanged=function(sb,p,fu) bgVol=p/100.0; bgLbl.setText("Crowd / BG: "..p.."%") end,
    onStartTrackingTouch=function(sb) end, onStopTrackingTouch=function(sb) end})
  muBar.setOnSeekBarChangeListener(SeekBar.OnSeekBarChangeListener{
    onProgressChanged=function(sb,p,fu) menuVol=p/100.0; muLbl.setText("Menu Music: "..p.."%") end,
    onStartTrackingTouch=function(sb) end, onStopTrackingTouch=function(sb) end})
  local sv=ScrollView(activity); sv.addView(cont)
  AlertDialog.Builder(activity).setTitle("Settings — Volume Control").setView(sv)
    .setPositiveButton("Save",function()
      saveSettings()
      speak("Saved. FX "..math.floor(sfxVol*100).."%. Crowd "..math.floor(bgVol*100).."%. Music "..math.floor(menuVol*100).."%.")
    end)
    .setNegativeButton("Back",nil).show()
end

-- ═══════════════════════════════════════════════════════════════
--  MY CAREER ACCOUNT
-- ═══════════════════════════════════════════════════════════════
function showMC()
  if not myCA then
    AlertDialog.Builder(activity).setTitle("My Career Account").setMessage("No account found.")
      .setPositiveButton("Create Account",function() createCAFlow(nil) end)
      .setNegativeButton("Back",nil).show(); return
  end
  local info="Name: "..myCA.name.."\nPosition: "..myCA.position.."\nHeight: "..myCA.height
    .."\n\nGames Played: "..myCA.gamesPlayed.."\nTotal Points: "..myCA.totalPoints
    .."\nTotal Assists: "..myCA.totalAssists.."\nCareer Wins: "..myCA.careerWins
  AlertDialog.Builder(activity).setTitle("My Career: "..myCA.name).setMessage(info)
    .setItems({"Play Career Game","Edit Profile","Delete Account"},function(i,item)
      local v=tostring(item)
      if     v=="Play Career Game" then showLeague("mycareer")
      elseif v=="Edit Profile"     then createCAFlow(myCA.name)
      elseif v=="Delete Account"   then
        AlertDialog.Builder(activity).setTitle("Delete Account?").setMessage("Delete "..myCA.name.."?")
          .setPositiveButton("Delete",function() deleteCA(); speak("Account deleted.") end)
          .setNegativeButton("Cancel",nil).show()
      end
    end).show()
end
function createCAFlow(ex)
  local ed=EditText(activity); ed.setHint("Enter your player name"); if ex then ed.setText(ex) end
  AlertDialog.Builder(activity).setTitle("Player Name").setView(ed)
    .setPositiveButton("Next",function()
      local nm=tostring(ed.getText()); if #nm==0 then speak("Enter a name."); return end; pickPos(nm)
    end).setNegativeButton("Cancel",nil).show()
end
function pickPos(nm)
  AlertDialog.Builder(activity).setTitle("Select Position")
    .setItems(POSITIONS,function(i,v) pickHt(nm,tostring(v)) end).setNegativeButton("Back",nil).show()
end
function pickHt(nm,pos)
  local hs=POS_HEIGHTS[pos]
  AlertDialog.Builder(activity).setTitle("Select Height — "..pos)
    .setItems(hs,function(i,v)
      local ch=tostring(v)
      if myCA then myCA.name=nm; myCA.position=pos; myCA.height=ch
      else myCA={name=nm,position=pos,height=ch,gamesPlayed=0,totalPoints=0,totalAssists=0,careerWins=0} end
      saveCA(); speak("Account saved! "..nm.." — "..pos.." — "..ch..".")
    end).setNegativeButton("Back",nil).show()
end

-- ═══════════════════════════════════════════════════════════════
--  LEAGUE / TEAM SELECTION
-- ═══════════════════════════════════════════════════════════════
function showLeague(mode)
  local leagues={"NBA","PBA","MPBL"}
  local title=((mode=="career") and "Career Mode" or (mode=="mycareer") and "My Career" or "Exhibition").." — Select League"
  AlertDialog.Builder(activity).setTitle(title)
    .setItems(leagues,function(i,v) showTeam(tostring(v),mode) end)
    .setNegativeButton("Back",function() showMenuDialog() end).show()
  speak("Select a league.")
end
function showTeam(league,mode)
  local rawTeams=LEAGUE_DATA[league]; if not rawTeams then speak("No teams found."); return end
  local teams={}
  if mode=="career" or mode=="mycareer" then table.insert(teams,"Custom Team Name") end
  for name,_ in pairs(rawTeams) do table.insert(teams,name) end
  local title=league.." — "..((mode=="career") and "Career" or (mode=="mycareer") and "My Career" or "Exhibition")
  AlertDialog.Builder(activity).setTitle(title.." — Select Team")
    .setItems(teams,function(i,item)
      local choice=tostring(item)
      if choice=="Custom Team Name" then showCustomName(mode); return end
      isMyCAGame=(mode=="mycareer")
      setupMatch(choice,(mode=="career" or mode=="mycareer") and Color.BLUE or Color.WHITE)
    end)
    .setNegativeButton("Back",function() showLeague(mode) end).show()
  speak("Select your team.")
end
function showCustomName(mode)
  local ed=EditText(activity); ed.setHint("Enter team name")
  AlertDialog.Builder(activity).setTitle("Custom Team Name").setView(ed)
    .setPositiveButton("Confirm",function()
      local nm=tostring(ed.getText())
      if #nm>0 then
        isMyCAGame=(mode=="mycareer")
        setupMatch(nm,(mode=="career" or mode=="mycareer") and Color.BLUE or Color.WHITE)
      else speak("Invalid name.") end
    end).setNegativeButton("Cancel",nil).show()
end

-- ═══════════════════════════════════════════════════════════════
--  ONLINE MULTIPLAYER
-- ═══════════════════════════════════════════════════════════════
function showOnlineMenu()
  AlertDialog.Builder(activity).setTitle("Online Multiplayer")
    .setItems({"Create Room (Host)","Join Room (Connect)"},function(i,item)
      if tostring(item)=="Create Room (Host)" then createOnlineRoom() else showTokenInput() end
    end).setNegativeButton("Back",nil).show()
end
function createOnlineRoom()
  networkRole="player"; speak("Creating room...")
  httpGetFallback("/create",function(code,content)
    if code==200 then
      local res=json.decode(content); onlineToken=res.token
      speak("Room created. Token is "..onlineToken..". Waiting for opponent.")
      startPolling()
      AlertDialog.Builder(activity).setTitle("Share Token")
        .setMessage("Your Token: "..onlineToken.."\n\nWaiting for opponent...")
        .setNegativeButton("Cancel",function()
          onlineToken=nil; if networkTicker then pcall(function() networkTicker.stop() end) end
        end).show()
    else speak("Failed to create room.") end
  end)
end
function showTokenInput()
  networkRole="guest"; local ed=EditText(activity); ed.setHint("6-digit token"); ed.setInputType(2)
  AlertDialog.Builder(activity).setTitle("Join Room").setView(ed)
    .setPositiveButton("Connect",function()
      local token=tostring(ed.getText())
      if #token==6 then
        onlineToken=token
        httpGetFallback("/join?token="..token,function(code,content)
          if code==200 then local res=json.decode(content); handleNetworkMessage(res); startPolling()
          else speak("Room not found.") end
        end)
      else speak("Invalid token.") end
    end).setNegativeButton("Back",nil).show()
end
function relayAction(payload)
  if not isOnline then return end
  httpPostFallback("/send",json.encode({token=onlineToken,role=networkRole,payload=payload}),function(code,content)
    if code~=200 then print("Send error: "..code) end
  end)
end
function handleNetworkMessage(msg)
  if msg.type=="relay" then
    local p=msg.payload
    if     p.action=="start_phase"   then startPhase(p.side,true)
    elseif p.action=="handle_action" then handleAction(p.lane,true)
    elseif p.action=="score_sync"    then playerScore=p.e_score; enemyScore=p.p_score; refreshScore()
    elseif p.action=="sync_names"    then enemyName=p.p_name; playerName=p.e_name; refreshScore() end
  elseif msg.type=="game_start" then
    isOnline=true; networkRole=msg.role; speak("Opponent found! Game starting.")
    if networkRole=="player" then
      relayAction({action="sync_names",p_name=playerName,e_name=enemyName}); handleJumpBall()
    end
  elseif msg.type=="opponent_disconnected" then
    speak("Opponent disconnected."); isOnline=false; onlineToken=nil
    if networkTicker then pcall(function() networkTicker.stop() end) end
    showMainMenu()
  end
end
function startPolling()
  if networkTicker then pcall(function() networkTicker.stop() end) end
  networkTicker=Ticker(); networkTicker.Period=1000
  networkTicker.onTick=function()
    if not onlineToken then return end
    httpGetFallback("/poll?token="..onlineToken.."&role="..networkRole,function(code,content)
      if code==200 then
        local messages=json.decode(content)
        for _,m in ipairs(messages) do handleNetworkMessage(m) end
      end
    end)
  end
  networkTicker.start()
end

-- ═══════════════════════════════════════════════════════════════
--  LIFECYCLE
-- ═══════════════════════════════════════════════════════════════
function onDestroy()
  isGameOver=true; SFX.stopAll()
  if tts then pcall(function() tts.stop(); tts.shutdown(); tts=nil end) end
end
function onStop() isGameOver=true; SFX.stopAll() end

-- ═══════════════════════════════════════════════════════════════
--  START
-- ═══════════════════════════════════════════════════════════════
loadProgress()
loadSettings()
loadCA()
showMainMenu()