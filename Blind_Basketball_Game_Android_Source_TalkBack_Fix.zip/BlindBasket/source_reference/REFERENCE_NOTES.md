# External reference notes

## User-supplied NBA 2K dataset README

- Source: [https://github.com/luyangzhu/NBA2K-dataset/blob/master/README.md](https://github.com/luyangzhu/NBA2K-dataset/blob/master/README.md) (the README was read through the repository's raw GitHub URL during this task).
- Use in this project: research guidance only. No NBA 2K dataset records, assets, player likenesses, branding or audio are bundled in the game.
- Reuse caution: the README's data-use and attribution terms are not a license to redistribute its material; verify its exact current terms before any separate reuse.

## Telegram community link

- Public page checked: [https://t.me/gwapokobay1639](https://t.me/gwapokobay1639).
- Check date: 2026-10-25.
- At the time checked, the page resolved publicly under the supplied Telegram URL and showed 312 subscribers. This confirms that a public page was visible then; it does not verify the channel operator's identity, ownership by the creator, ongoing activity, or future availability.

## Voice and sound scope

- The four in-game commentary voices and added free-throw crowd cue are original generated assets. No NBA 2K broadcast audio or identifiable person's voice is cloned.
- The game retains the user-supplied sounds where used. Runtime speech files are compressed clips; temporary WAV masters are not part of the game export.
