# Original user-supplied source reference

`main.lua` and the three text files were copied from the user-uploaded `blindbasketballgamefullprojectvbbfullsarascode.zip` as reference for the Godot port. The original code identifies its creator as **Darry John Sarmiento** and links the community channel at https://t.me/gwapokobay1639. The original Android/AndroLua project uses Android UI, MediaPlayer, TextToSpeech and haptic APIs; this directory is reference material, not a compiled Windows application. The playable game is implemented in the project’s Godot/GDScript files.
