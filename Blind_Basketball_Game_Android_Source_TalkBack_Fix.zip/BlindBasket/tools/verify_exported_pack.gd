extends SceneTree

const MatchType = preload("res://scripts/game/basketball_match.gd")

var _failures: Array[String] = []
var _checks := 0


func _initialize() -> void:
	call_deferred("_verify")


func _verify() -> void:
	_check(ProjectSettings.get_setting("application/config/name") == "Blind Basketball Game", "exported application identity")
	for path: String in [
		"res://assets/game/sprites/player_atlas.png",
		"res://assets/game/audio/announcer/sideline_start.ogg",
		"res://assets/game/audio/announcer/puck_pass.ogg",
		"res://assets/game/audio/announcer/fenrir_fastbreak.ogg",
		"res://assets/game/audio/announcer/zube_turnover.ogg",
		"res://assets/game/audio/crowd_ambience_loop.mp3",
		"res://assets/game/audio/crowd_cheer_home.mp3",
		"res://assets/game/audio/crowd_room.mp3",
		"res://assets/game/audio/crowd_free_throw_boo.mp3",
	]:
		_check(ResourceLoader.exists(path), "exported game resource: " + path)
	var crowd_bus := AudioServer.get_bus_index("Crowd")
	_check(crowd_bus >= 0, "dedicated crowd audio route exists")
	var packed := load("res://scenes/main.tscn") as PackedScene
	_check(packed != null, "exported main scene loads")
	if packed != null:
		var app := packed.instantiate() as Control
		_check(app != null, "exported app scene instantiates")
		if app != null:
			root.add_child(app)
			await process_frame
			await process_frame
			_check(String(app.get("_screen")) == "home", "exported game boots to its home menu")
			app.call("_show_settings")
			_check(String(app.get("_screen")) == "settings", "exported settings menu opens")
			app.call("_show_home")
			app.call("_show_setup", false)
			var audio_manager: Node = app.get("_audio")
			audio_manager.call("set_narration_enabled", false)
			audio_manager.set("commentary_enabled", false)
			app.call("_begin_match")
			await process_frame
			_check(String(app.get("_screen")) == "game", "exported quick exhibition reaches live gameplay")
			var live: Variant = app.get("_simulation")
			_check(live != null and live.home_players.size() == 5 and live.away_players.size() == 5, "exported match starts with two five-player teams")
			app.call("_show_pause")
			_check(String(app.get("_screen")) == "pause", "exported match pauses")
			app.call("_resume_game")
			_check(String(app.get("_screen")) == "game", "exported match resumes")
			app.call("_show_home")
			app.queue_free()
			await process_frame
	var small_match = MatchType.new()
	small_match.start(2, "Home Test", "Away Test", false, 2)
	_check(small_match.home_players.size() == 2 and small_match.away_players.size() == 2, "exported simulator supports 2-on-2")
	_check(is_equal_approx(small_match.game_seconds, 30.0), "exported simulator uses the selected two-minute clock")
	var restored = MatchType.new()
	_check(restored.restore(small_match.to_save_dict()), "exported simulator restores a match snapshot")
	if _failures.is_empty():
		print("[basketball-pack] PASS: %d checks" % _checks)
		quit(0)
		return
	for failure: String in _failures:
		push_error("[basketball-pack] " + failure)
	print("[basketball-pack] FAIL: %d failures across %d checks" % [_failures.size(), _checks])
	quit(1)


func _check(condition: bool, context: String) -> void:
	_checks += 1
	if not condition:
		_failures.append(context)
