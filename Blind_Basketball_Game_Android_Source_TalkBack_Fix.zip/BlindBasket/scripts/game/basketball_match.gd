extends RefCounted

signal event_occurred(kind: String, text: String)

const COURT_W := 1000.0
const COURT_H := 560.0
const GAME_CLOCK_RATE := 1.0
const SHOT_CLOCK_LENGTH := 24.0
const TEAM_POOL := ["Harbor City Waves", "Metro Comets", "Copper Canyon", "Northside Owls", "Coastal Current", "Skyline Sparks"]
const PLAYER_POOL := ["Ari Rivers", "Kai Moreno", "Jordan Vale", "Mika Stone", "Rae Carter", "Sam Brooks", "Eli Park", "Noah Quinn", "Casey James", "Taylor Reed", "Alex Morgan"]

var players_per_side := 5
var home_team := "Harbor City Waves"
var away_team := "Metro Comets"
var home_players: Array[Dictionary] = []
var away_players: Array[Dictionary] = []
var home_bench: Array[Dictionary] = []
var away_bench: Array[Dictionary] = []
var home_score := 0
var away_score := 0
var quarter := 1
var match_duration_minutes := 12
var game_seconds := 180.0
var shot_seconds := SHOT_CLOCK_LENGTH
var possession_team := 0
var carrier_index := 0
var selected_index := 0
var ball_position := Vector2(250.0, 280.0)
var ball_air_time := 0.0
var pending_action: Dictionary = {}
var offense_seconds := 0.0
var timeout_seconds := 0.0
var away_free_throw_timer := 0.0
var timeout_uses := 2
var period_break_seconds := 0.0
var free_throws_remaining := 0
var free_throw_team := 0
var fouls_home := 0
var fouls_away := 0
var game_over := false
var has_overtime := false
var career_mode := false
var assist_name := ""
var assist_seconds := 0.0
var rng := RandomNumberGenerator.new()


func start(mode: int, home_name: String, away_name: String, is_career: bool = false, duration_minutes: int = 12, home_roster: Array[Dictionary] = [], away_roster: Array[Dictionary] = []) -> void:
	players_per_side = clampi(mode, 2, 5)
	home_team = home_name if not home_name.is_empty() else TEAM_POOL[0]
	away_team = away_name if not away_name.is_empty() else TEAM_POOL[1]
	career_mode = is_career
	match_duration_minutes = clampi(duration_minutes, 2, 12)
	rng.randomize()
	home_score = 0
	away_score = 0
	quarter = 1
	game_seconds = _regular_period_seconds()
	shot_seconds = SHOT_CLOCK_LENGTH
	possession_team = 0
	carrier_index = 0
	selected_index = 0
	offense_seconds = 0.0
	timeout_seconds = 0.0
	timeout_uses = 2
	period_break_seconds = 0.0
	free_throws_remaining = 0
	fouls_home = 0
	fouls_away = 0
	game_over = false
	has_overtime = false
	assist_name = ""
	assist_seconds = 0.0
	ball_air_time = 0.0
	pending_action.clear()
	home_players.clear()
	away_players.clear()
	home_bench.clear()
	away_bench.clear()
	_build_team(home_players, home_bench, home_team, 0, home_roster)
	_build_team(away_players, away_bench, away_team, 1, away_roster)
	_place_players()
	ball_position = home_players[0].position
	_emit("tipoff", "Tip-off. %s has the ball. %s is defending." % [home_team, away_team])


func _regular_period_seconds() -> float:
	return float(match_duration_minutes * 60) / 4.0


func _overtime_period_seconds() -> float:
	return maxf(30.0, _regular_period_seconds() * 5.0 / 12.0)


func _period_duration_seconds() -> float:
	return _overtime_period_seconds() if quarter >= 5 else _regular_period_seconds()


func set_match_duration_minutes(minutes: float) -> void:
	var elapsed_this_period := maxf(0.0, _period_duration_seconds() - game_seconds)
	match_duration_minutes = clampi(roundi(minutes), 2, 12)
	game_seconds = maxf(0.0, _period_duration_seconds() - elapsed_this_period)


func _build_team(active: Array[Dictionary], bench: Array[Dictionary], team_name: String, side: int, roster_data: Array[Dictionary]) -> void:
	if roster_data.is_empty():
		for i in range(players_per_side):
			var fallback_name: String = PLAYER_POOL[(i + side * 5) % PLAYER_POOL.size()]
			active.append(_make_player_record({"name": fallback_name, "number": str(i + 1)}, i, false))
		for i in range(3):
			var bench_name: String = PLAYER_POOL[(i + 4 + side * 5) % PLAYER_POOL.size()]
			bench.append(_make_player_record({"name": bench_name, "number": str(i + 5)}, i + 4, false))
		return
	for i in range(players_per_side):
		if i < roster_data.size():
			active.append(_make_player_record(roster_data[i], i, true))
		else:
			active.append(_make_player_record({"name": "Unlisted roster slot %d for %s" % [i + 1, team_name]}, i, false))
	for i in range(players_per_side, roster_data.size()):
		bench.append(_make_player_record(roster_data[i], i, true))


func _make_player_record(data: Dictionary, slot: int, verified: bool) -> Dictionary:
	var player_name: String = str(data.get("name", "")).strip_edges()
	if player_name.is_empty():
		player_name = "Unlisted roster slot %d" % (slot + 1)
	var jersey_number: String = str(data.get("number", "")).strip_edges()
	var internal_number := int(jersey_number) if jersey_number.is_valid_int() else slot + 1
	return {
		"name": player_name,
		"number": internal_number,
		"jersey_number": jersey_number,
		"position_name": str(data.get("position", "")).strip_edges(),
		"position": Vector2.ZERO,
		"fouls": 0,
		"points": 0,
		"energy": 1.0,
		"roster_verified": verified,
		"source_url": str(data.get("source_url", "")).strip_edges()
	}


func _place_players() -> void:
	for i in range(home_players.size()):
		var y := 160.0 + float(i % 4) * 82.0
		home_players[i].position = Vector2(245.0 + float(i / 4) * 95.0, y)
	for i in range(away_players.size()):
		var y := 160.0 + float(i % 4) * 82.0
		away_players[i].position = Vector2(755.0 - float(i / 4) * 95.0, y)
	carrier_index = clampi(carrier_index, 0, max(0, _team(0).size() - 1))
	selected_index = clampi(selected_index, 0, max(0, _team(0).size() - 1))
	ball_position = _carrier().position


func _process_active_team(delta: float, direction: Vector2, sprinting: bool) -> void:
	var team: Array[Dictionary] = _team(0)
	if team.is_empty():
		return
	var controlled := team[selected_index]
	var speed := 220.0 if sprinting else 175.0
	if direction.length() > 1.0:
		direction = direction.normalized()
	controlled.position = _clamp_to_court(controlled.position + direction * speed * delta)
	if selected_index == carrier_index and possession_team == 0:
		ball_position = controlled.position + Vector2(18.0, 10.0)
	else:
		ball_position = _carrier().position + Vector2(18.0, 10.0)


func _move_teammates(delta: float) -> void:
	var home_target_sign := 1.0 if _home_attacks_right() else -1.0
	var ball_owner: Dictionary = _carrier()
	for i in range(home_players.size()):
		if possession_team == 0 and i == carrier_index:
			continue
		var target: Vector2
		if possession_team == 0:
			target = ball_owner.position + Vector2(home_target_sign * (125.0 + float(i % 2) * 35.0), (float(i) - float(home_players.size() - 1) / 2.0) * 74.0)
		else:
			target = Vector2(355.0 + float(i % 2) * 115.0, 150.0 + float(i % 4) * 86.0)
		home_players[i].position = _move_toward(home_players[i].position, _clamp_to_court(target), 95.0 * delta)
	for i in range(away_players.size()):
		if possession_team == 1 and i == carrier_index:
			continue
		var target: Vector2
		if possession_team == 0:
			target = ball_owner.position + Vector2(-home_target_sign * (82.0 + float(i % 2) * 38.0), (float(i) - float(away_players.size() - 1) / 2.0) * 52.0)
		else:
			target = Vector2(520.0 - float(i % 2) * 100.0, 155.0 + float(i % 4) * 82.0)
		away_players[i].position = _move_toward(away_players[i].position, _clamp_to_court(target), 88.0 * delta)


func tick(delta: float, direction: Vector2 = Vector2.ZERO, sprinting: bool = false) -> void:
	if game_over:
		return
	if period_break_seconds > 0.0:
		period_break_seconds = maxf(0.0, period_break_seconds - delta)
		if period_break_seconds == 0.0:
			_emit("resume", "Back to play. %s has possession. %s." % [_team_name(possession_team), _score_summary()])
		return
	if timeout_seconds > 0.0:
		timeout_seconds = maxf(0.0, timeout_seconds - delta)
		if timeout_seconds == 0.0:
			_emit("resume", "Timeout over. Back to play. %s has the ball." % _team_name(possession_team))
		return
	if ball_air_time > 0.0:
		ball_air_time = maxf(0.0, ball_air_time - delta)
		if ball_air_time == 0.0:
			_resolve_pending_action()
		return
	if free_throws_remaining > 0:
		if free_throw_team == 1:
			away_free_throw_timer += delta
			if away_free_throw_timer >= 0.9:
				away_free_throw_timer = 0.0
				_take_free_throw()
		return

	game_seconds -= delta * GAME_CLOCK_RATE
	shot_seconds -= delta
	offense_seconds += delta
	if assist_seconds > 0.0:
		assist_seconds -= delta
		if assist_seconds <= 0.0:
			assist_name = ""
	if game_seconds <= 0.0:
		_end_period()
		return
	if shot_seconds <= 0.0:
		_emit("shot_clock", "Shot clock violation. Possession changes to %s." % _other_team_name())
		_start_possession(1 - possession_team)
		return

	_process_active_team(delta, direction, sprinting)
	_move_teammates(delta)
	if possession_team == 1:
		_update_away_offense(delta)


func _update_away_offense(delta: float) -> void:
	var carrier := _carrier()
	var target := _hoop_position(1)
	var attack_direction := 1.0 if target.x > COURT_W / 2.0 else -1.0
	carrier.position = _move_toward(carrier.position, target - Vector2(145.0 * attack_direction, 0.0), 82.0 * delta)
	ball_position = carrier.position + Vector2(-18.0, 10.0)
	if offense_seconds >= 5.0:
		_launch_shot(1)


func pass_ball(direction: Vector2 = Vector2.ZERO) -> void:
	if game_over or possession_team != 0 or ball_air_time > 0.0 or free_throws_remaining > 0:
		return
	if home_players.size() <= 1:
		_emit("pass", "There is no teammate to pass to in this mode.")
		return
	var receiver := _choose_receiver(direction)
	assist_name = String(home_players[carrier_index].name)
	assist_seconds = 6.0
	var from_position: Vector2 = home_players[carrier_index].position
	var to_position: Vector2 = home_players[receiver].position
	pending_action = {"type": "pass", "team": 0, "receiver": receiver, "from": from_position, "to": to_position}
	ball_position = from_position
	ball_air_time = 0.34
	_emit("pass", "Pass away from %s. The ball is traveling to %s." % [home_players[carrier_index].name, home_players[receiver].name])


func _choose_receiver(direction: Vector2) -> int:
	var best_index := (carrier_index + 1) % home_players.size()
	var best_score := -INF
	var from_position: Vector2 = home_players[carrier_index].position
	var aim := direction.normalized() if direction.length() > 0.2 else Vector2.RIGHT if _home_attacks_right() else Vector2.LEFT
	for i in range(home_players.size()):
		if i == carrier_index:
			continue
		var offset: Vector2 = home_players[i].position - from_position
		var score := aim.dot(offset.normalized()) * 2.0 + offset.length() / 1000.0
		if score > best_score:
			best_score = score
			best_index = i
	return best_index


func shoot() -> void:
	if free_throws_remaining > 0:
		if free_throw_team == 0:
			_take_free_throw()
		else:
			_emit("action", "The opponent is at the free-throw line. The attempt will happen automatically.")
		return
	if game_over or possession_team != 0 or ball_air_time > 0.0:
		_emit("action", "Your team needs the ball before you can shoot.")
		return
	if selected_index != carrier_index:
		_emit("action", "Switch to the player with the ball before shooting.")
		return
	_launch_shot(0)


func _launch_shot(team: int) -> void:
	if ball_air_time > 0.0 or game_over:
		return
	var shooter: Dictionary = _team(team)[carrier_index]
	var hoop := _hoop_position(team)
	pending_action = {"type": "shot", "team": team, "shooter": shooter.name, "from": shooter.position, "to": hoop}
	ball_position = shooter.position
	ball_air_time = 0.72 if shooter.position.distance_to(hoop) < 230.0 else 0.98
	_emit("shot", "%s rises for a %s-point shot. %s." % [shooter.name, "three" if shooter.position.distance_to(hoop) > 255.0 else "two", _distance_callout(shooter.position, hoop)])


func _resolve_pending_action() -> void:
	if pending_action.is_empty():
		return
	var action: Dictionary = pending_action
	pending_action.clear()
	if String(action.get("type", "")) == "pass":
		carrier_index = int(action.get("receiver", 0))
		selected_index = carrier_index
		ball_position = home_players[carrier_index].position
		shot_seconds = SHOT_CLOCK_LENGTH
		offense_seconds = 0.0
		_emit("pass_complete", "Ball received by %s. %s." % [home_players[carrier_index].name, _score_summary()])
		return
	if String(action.get("type", "")) != "shot":
		return
	var team := int(action.get("team", 0))
	var shooter_position: Vector2 = action.from
	var hoop: Vector2 = action.to
	var distance := shooter_position.distance_to(hoop)
	var points := 3 if distance > 255.0 else 2
	var pressure := _nearest_defender_distance(team, shooter_position)
	var contest := clampf(1.0 - pressure / 180.0, 0.0, 1.0)
	var foul_chance := 0.16 if contest > 0.70 else 0.04
	if rng.randf() < foul_chance:
		free_throw_team = team
		free_throws_remaining = 3 if points == 3 else 2
		away_free_throw_timer = 0.0
		if team == 0:
			fouls_away += 1
		else:
			fouls_home += 1
			var instruction := "Press shoot or tap Shoot to take the free throw." if team == 0 else "The opponent steps to the free-throw line."
			_emit("foul", "Shooting foul on %s. %s gets %d free throws. %s" % [String(action.get("shooter", "Player")), _team_name(team), free_throws_remaining, instruction])
			_emit("free_throw_start", "Free-throw pressure rises as %s steps to the line." % _team_name(team))
			return
	var accuracy := clampf(0.68 - distance / 1700.0 - contest * 0.22, 0.22, 0.67)
	if rng.randf() < accuracy:
		if team == 0:
			home_score += points
			_add_player_points(0, String(action.get("shooter", "Player")), points)
			ball_position = hoop
			if not assist_name.is_empty() and assist_seconds > 0.0:
				_emit("assist", "Basket! %s scores %d. Assist by %s." % [String(action.get("shooter", "Player")), points, assist_name])
			else:
				_emit("home_score", "Home basket! %s scores %d." % [String(action.get("shooter", "Player")), points])
		else:
			away_score += points
			_add_player_points(1, String(action.get("shooter", "Player")), points)
			ball_position = hoop
			_emit("away_score", "Opponent basket. %s scores %d." % [String(action.get("shooter", "Player")), points])
		_start_possession(1 - team)
	else:
		_emit("miss", "The shot misses and hits the rim. Rebound is up for grabs.")
		var rebound_team := _rebound_team(hoop)
		_start_possession(rebound_team)


func _take_free_throw() -> void:
	if free_throws_remaining <= 0:
		return
	away_free_throw_timer = 0.0
	var player := _carrier()
	var made := rng.randf() < 0.72
	if made:
		if free_throw_team == 0:
			home_score += 1
			_add_player_points(0, String(player.get("name", "Player")), 1)
			_emit("home_free_throw_make", "%s makes the free throw. %s." % [player.name, _score_summary()])
		else:
			away_score += 1
			_add_player_points(1, String(player.get("name", "Player")), 1)
			_emit("away_free_throw_make", "%s makes the free throw. %s." % [player.name, _score_summary()])
	else:
		_emit("free_throw_miss", "%s misses the free throw. %s." % [player.name, _score_summary()])
	free_throws_remaining -= 1
	if free_throws_remaining <= 0:
		var next_team := 1 - free_throw_team
		_start_possession(next_team)
		_emit("free_throw_end", "Free throws complete. %s has possession." % _team_name(next_team))


func defend() -> void:
	if game_over or possession_team != 1 or ball_air_time > 0.0 or free_throws_remaining > 0:
		_emit("defense", "Stay in front of the opponent. Your team is not defending right now.")
		return
	var defender: Dictionary = home_players[selected_index]
	var carrier: Dictionary = _carrier()
	var distance: float = defender.position.distance_to(carrier.position)
	if distance > 190.0:
		_emit("defense", "Too far to steal. Move toward %s, the opponent with the ball." % carrier.name)
		return
	var chance := 0.58 if distance < 82.0 else 0.34
	if rng.randf() < chance:
		_emit("steal", "Steal by %s! Your team takes possession." % defender.name)
		_start_possession(0)
	else:
		_emit("defense", "%s keeps the ball. Stay close and try again." % carrier.name)


func switch_player() -> void:
	if home_players.is_empty():
		return
	selected_index = (selected_index + 1) % home_players.size()
	var player: Dictionary = home_players[selected_index]
	_emit("switch", "Selected %s%s." % [_player_descriptor(player), ", ball carrier" if selected_index == carrier_index and possession_team == 0 else ""])


func _player_descriptor(player: Dictionary) -> String:
	var description := String(player.get("name", "Player"))
	var jersey_number := String(player.get("jersey_number", ""))
	var position_name := String(player.get("position_name", ""))
	if not jersey_number.is_empty():
		description += ", number " + jersey_number
	if not position_name.is_empty():
		description += ", " + position_name
	return description


func substitute() -> void:
	if home_players.is_empty() or home_bench.is_empty():
		_emit("substitution", "No substitute is available.")
		return
	var outgoing: Dictionary = home_players[selected_index].duplicate(true)
	var incoming: Dictionary = home_bench.pop_front()
	var court_position: Vector2 = outgoing.position
	incoming.position = court_position
	outgoing.position = Vector2.ZERO
	home_bench.append(outgoing)
	home_players[selected_index] = incoming
	if selected_index == carrier_index and possession_team == 0:
		carrier_index = selected_index
		ball_position = incoming.position
	_emit("substitution", "%s checks in for %s." % [_player_descriptor(incoming), _player_descriptor(outgoing)])


func call_timeout() -> void:
	if timeout_uses <= 0 or game_over or free_throws_remaining > 0 or timeout_seconds > 0.0:
		_emit("timeout", "No timeout is available right now.")
		return
	timeout_uses -= 1
	timeout_seconds = 5.0
	_emit("timeout", "Timeout called. Five seconds to regroup. %s." % _score_summary())


func _start_possession(team: int) -> void:
	possession_team = team
	carrier_index = 0
	selected_index = 0
	ball_air_time = 0.0
	pending_action.clear()
	offense_seconds = 0.0
	shot_seconds = SHOT_CLOCK_LENGTH
	assist_name = ""
	assist_seconds = 0.0
	_place_players()
	ball_position = _carrier().position


func _end_period() -> void:
	if quarter < 4:
		quarter += 1
		game_seconds = _regular_period_seconds()
		period_break_seconds = 2.0
		_start_possession(quarter % 2)
		if quarter == 3:
			_emit("halftime", "%s Teams switch ends." % halftime_statistics())
		else:
			_emit("quarter", "End of quarter %d. %s." % [quarter - 1, _score_summary()])
		return
	if quarter == 4 and home_score == away_score and not has_overtime:
		has_overtime = true
		quarter = 5
		game_seconds = _overtime_period_seconds()
		period_break_seconds = 2.5
		_start_possession(0)
		_emit("overtime", "Tie game. Overtime period. %s." % _score_summary())
		return
	game_over = true
	_emit("game_over", "Final score. %s. %s." % [_score_summary(), "Home wins!" if home_score > away_score else "Opponent wins!" if away_score > home_score else "The game ends in a tie."])


func _rebound_team(spot: Vector2) -> int:
	var home_min := INF
	var away_min := INF
	for p: Dictionary in home_players:
		home_min = minf(home_min, p.position.distance_to(spot))
	for p: Dictionary in away_players:
		away_min = minf(away_min, p.position.distance_to(spot))
	if absf(home_min - away_min) < 55.0:
		return rng.randi_range(0, 1)
	return 0 if home_min < away_min else 1


func _nearest_defender_distance(team: int, position: Vector2) -> float:
	var defenders: Array[Dictionary] = _team(1 - team)
	var nearest := INF
	for player: Dictionary in defenders:
		nearest = minf(nearest, player.position.distance_to(position))
	return nearest


func _team(team: int) -> Array[Dictionary]:
	return home_players if team == 0 else away_players


func _carrier() -> Dictionary:
	var players := _team(possession_team)
	if players.is_empty():
		return {"name": "Player", "number": 1, "position": Vector2(COURT_W / 2.0, COURT_H / 2.0), "fouls": 0}
	return players[clampi(carrier_index, 0, players.size() - 1)]


func _home_attacks_right() -> bool:
	return quarter == 1 or quarter == 3 or quarter >= 5


func _hoop_position(team: int) -> Vector2:
	var home_right := _home_attacks_right()
	var attacks_right := home_right if team == 0 else not home_right
	return Vector2(940.0 if attacks_right else 60.0, COURT_H / 2.0)


func _team_name(team: int) -> String:
	return home_team if team == 0 else away_team


func _other_team_name() -> String:
	return away_team if possession_team == 0 else home_team


func _score_summary() -> String:
	return "%s %d, %s %d" % [home_team, home_score, away_team, away_score]


func _best_player_callout() -> String:
	var leaders := _leading_scorer_names()
	return "No player has scored yet." if leaders.is_empty() else "Top scorer: %s." % ", and ".join(leaders)


func halftime_statistics() -> String:
	return "Halftime statistics. %s. Team fouls: %s %d, %s %d. %s" % [_score_summary(), home_team, fouls_home, away_team, fouls_away, _best_player_callout()]


func _leading_scorer_names() -> Array[String]:
	var leaders: Array[String] = []
	var high_score := 0
	for players: Array[Dictionary] in [home_players, home_bench, away_players, away_bench]:
		for player: Dictionary in players:
			var points := int(player.get("points", 0))
			if points > high_score:
				high_score = points
				leaders.clear()
				leaders.append("%s with %d points" % [String(player.get("name", "Player")), points])
			elif points == high_score and points > 0:
				leaders.append("%s with %d points" % [String(player.get("name", "Player")), points])
	return leaders


func _add_player_points(team: int, player_name: String, points: int) -> void:
	for player: Dictionary in _team(team):
		if String(player.get("name", "")) == player_name:
			player["points"] = int(player.get("points", 0)) + points
			return
	var bench: Array[Dictionary] = home_bench if team == 0 else away_bench
	for player: Dictionary in bench:
		if String(player.get("name", "")) == player_name:
			player["points"] = int(player.get("points", 0)) + points
			return


func _distance_callout(position: Vector2, hoop: Vector2) -> String:
	var distance := position.distance_to(hoop)
	if distance < 125.0:
		return "close to the basket"
	if distance > 255.0:
		return "outside the three-point arc"
	return "inside the three-point line"


func _move_toward(from: Vector2, to: Vector2, amount: float) -> Vector2:
	var offset := to - from
	return to if offset.length() <= amount else from + offset.normalized() * amount


func _clamp_to_court(point: Vector2) -> Vector2:
	return Vector2(clampf(point.x, 38.0, COURT_W - 38.0), clampf(point.y, 38.0, COURT_H - 38.0))


func time_text() -> String:
	var seconds := maxi(0, ceili(game_seconds))
	return "%d:%02d" % [seconds / 60, seconds % 60]


func shot_clock_text() -> String:
	return str(maxi(0, ceili(shot_seconds)))


func score_text() -> String:
	return "%s %d  —  %s %d" % [home_team, home_score, away_team, away_score]


func status_summary() -> String:
	var possession := "Your team has the ball" if possession_team == 0 else "The opponent has the ball"
	var selected := "Selected player %s" % String(home_players[selected_index].name) if not home_players.is_empty() else "No player selected"
	var phase := "Overtime" if quarter >= 5 else "Quarter %d" % quarter
	var extra := " Free throws remaining: %d." % free_throws_remaining if free_throws_remaining > 0 else " Shot clock: %s seconds." % shot_clock_text()
	return "%s. %s. %s. %s. %s." % [phase, time_text(), score_text(), possession, selected + extra]


func _emit(kind: String, text: String) -> void:
	event_occurred.emit(kind, text)


func progress_fraction() -> float:
	if quarter >= 5:
		return 1.0
	var total_seconds := float(match_duration_minutes * 60)
	var period_seconds := _regular_period_seconds()
	var prior_periods := float(clampi(quarter - 1, 0, 4)) * period_seconds
	var elapsed_this_period := clampf(period_seconds - game_seconds, 0.0, period_seconds)
	return clampf((prior_periods + elapsed_this_period) / total_seconds, 0.0, 1.0)


func _serialize_pending_action() -> Dictionary:
	if pending_action.is_empty():
		return {}
	var saved: Dictionary = {}
	for key: String in ["type", "team", "receiver", "shooter"]:
		if pending_action.has(key):
			saved[key] = pending_action[key]
	for key: String in ["from", "to"]:
		if pending_action.get(key, null) is Vector2:
			var point: Vector2 = pending_action[key]
			saved[key + "_x"] = point.x
			saved[key + "_y"] = point.y
	return saved


func _deserialize_pending_action(value: Variant) -> Dictionary:
	if not value is Dictionary or String(value.get("type", "")).is_empty():
		return {}
	var restored: Dictionary = {}
	for key: String in ["type", "team", "receiver", "shooter"]:
		if value.has(key):
			restored[key] = value[key]
	for key: String in ["from", "to"]:
		if value.has(key + "_x") and value.has(key + "_y"):
			restored[key] = Vector2(float(value[key + "_x"]), float(value[key + "_y"]))
	return restored


func to_save_dict() -> Dictionary:
	return {
		"players_per_side": players_per_side,
		"home_team": home_team,
		"away_team": away_team,
		"home_score": home_score,
		"away_score": away_score,
		"quarter": quarter,
		"match_duration_minutes": match_duration_minutes,
		"game_seconds": game_seconds,
		"shot_seconds": shot_seconds,
		"offense_seconds": offense_seconds,
		"timeout_seconds": timeout_seconds,
		"possession_team": possession_team,
		"carrier_index": carrier_index,
		"selected_index": selected_index,
		"career_mode": career_mode,
		"timeout_uses": timeout_uses,
		"home_players": _serialize_players(home_players),
		"away_players": _serialize_players(away_players),
		"home_bench": _serialize_players(home_bench),
		"away_bench": _serialize_players(away_bench),
		"fouls_home": fouls_home,
		"fouls_away": fouls_away,
		"has_overtime": has_overtime,
		"free_throws_remaining": free_throws_remaining,
		"free_throw_team": free_throw_team,
		"ball_x": ball_position.x,
		"ball_y": ball_position.y,
		"ball_air_time": ball_air_time,
		"pending_action": _serialize_pending_action(),
		"assist_name": assist_name,
		"assist_seconds": assist_seconds,
		"game_over": game_over
	}


func restore(data: Dictionary) -> bool:
	if data.is_empty():
		return false
	players_per_side = clampi(int(data.get("players_per_side", 5)), 2, 5)
	home_team = String(data.get("home_team", TEAM_POOL[0]))
	away_team = String(data.get("away_team", TEAM_POOL[1]))
	home_score = int(data.get("home_score", 0))
	away_score = int(data.get("away_score", 0))
	quarter = int(data.get("quarter", 1))
	match_duration_minutes = clampi(int(data.get("match_duration_minutes", 12)), 2, 12)
	game_seconds = float(data.get("game_seconds", _regular_period_seconds()))
	shot_seconds = float(data.get("shot_seconds", SHOT_CLOCK_LENGTH))
	offense_seconds = float(data.get("offense_seconds", 0.0))
	timeout_seconds = float(data.get("timeout_seconds", 0.0))
	possession_team = int(data.get("possession_team", 0))
	carrier_index = int(data.get("carrier_index", 0))
	selected_index = int(data.get("selected_index", 0))
	career_mode = bool(data.get("career_mode", false))
	timeout_uses = int(data.get("timeout_uses", 2))
	fouls_home = int(data.get("fouls_home", 0))
	fouls_away = int(data.get("fouls_away", 0))
	has_overtime = bool(data.get("has_overtime", false))
	home_players = _deserialize_players(data.get("home_players", []), 0)
	away_players = _deserialize_players(data.get("away_players", []), 1)
	home_bench.assign(_deserialize_players(data.get("home_bench", []), 0, false))
	away_bench.assign(_deserialize_players(data.get("away_bench", []), 1, false))
	free_throws_remaining = clampi(int(data.get("free_throws_remaining", 0)), 0, 3)
	free_throw_team = clampi(int(data.get("free_throw_team", 0)), 0, 1)
	away_free_throw_timer = 0.0
	ball_air_time = maxf(0.0, float(data.get("ball_air_time", 0.0)))
	pending_action = _deserialize_pending_action(data.get("pending_action", {}))
	assist_name = String(data.get("assist_name", ""))
	assist_seconds = maxf(0.0, float(data.get("assist_seconds", 0.0)))
	game_over = bool(data.get("game_over", false))
	if not home_players.is_empty() and not away_players.is_empty():
		carrier_index = clampi(carrier_index, 0, _team(possession_team).size() - 1)
		selected_index = clampi(selected_index, 0, home_players.size() - 1)
		ball_position = Vector2(float(data.get("ball_x", _carrier().position.x)), float(data.get("ball_y", _carrier().position.y)))
	return not home_players.is_empty() and not away_players.is_empty()


func _serialize_players(players: Array[Dictionary]) -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	for p: Dictionary in players:
		var pos: Vector2 = p.get("position", Vector2.ZERO)
		result.append({
			"name": String(p.get("name", "Player")),
			"number": int(p.get("number", 0)),
			"jersey_number": String(p.get("jersey_number", "")),
			"position_name": String(p.get("position_name", "")),
			"roster_verified": bool(p.get("roster_verified", false)),
			"source_url": String(p.get("source_url", "")),
			"x": pos.x,
			"y": pos.y,
			"fouls": int(p.get("fouls", 0)),
			"points": int(p.get("points", 0)),
			"energy": float(p.get("energy", 1.0))
		})
	return result


func _deserialize_players(source: Array, side: int, active_only: bool = true) -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	var restore_count := mini(source.size(), players_per_side) if active_only else source.size()
	for i in range(restore_count):
		if not source[i] is Dictionary:
			continue
		var item: Dictionary = source[i]
		var fallback_name: String = PLAYER_POOL[(i + side * 5) % PLAYER_POOL.size()]
		var jersey_default: String = str(item.get("number", i + 1))
		result.append({
			"name": String(item.get("name", fallback_name)),
			"number": int(item.get("number", i + 1)),
			"jersey_number": str(item.get("jersey_number", jersey_default)),
			"position_name": String(item.get("position_name", "")),
			"roster_verified": bool(item.get("roster_verified", false)),
			"source_url": String(item.get("source_url", "")),
			"position": Vector2(float(item.get("x", 300.0)), float(item.get("y", 280.0))),
				"fouls": int(item.get("fouls", 0)),
				"points": int(item.get("points", 0)),
				"energy": float(item.get("energy", 1.0))
		})
	while active_only and result.size() < players_per_side:
		var i := result.size()
		var fallback_name: String = PLAYER_POOL[(i + side * 5) % PLAYER_POOL.size()]
		result.append(_make_player_record({"name": fallback_name, "number": str(i + 1)}, i, false))
	return result
