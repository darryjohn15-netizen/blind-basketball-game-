extends Control

const PLAYER_ATLAS: Texture2D = preload("res://assets/game/sprites/player_atlas.png")
const WOOD_FLOOR: Texture2D = preload("res://assets/game/sprites/generated/court_wood.jpg")
const BASKETBALL: Texture2D = preload("res://assets/game/sprites/generated/basketball.png")
const HOOP: Texture2D = preload("res://assets/game/sprites/generated/hoop_backboard.png")
const NAVY := Color("#101A2B")
const COURT_COLOR := Color("#B97A4A")
const COURT_LIGHT := Color("#D89D64")
const LINE_COLOR := Color("#FFF1D5")
const ORANGE := Color("#F47A38")
const TEAL := Color("#10BDB5")

var simulation: Object
var _reduced_motion := false


func _ready() -> void:
	custom_minimum_size = Vector2(520.0, 290.0)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	accessibility_name = "Basketball court"
	accessibility_description = "Top-down live court diagram. Use Read status for a spoken description of possession, score, clock and selected player."


func set_simulation(value: Object) -> void:
	simulation = value
	queue_redraw()


func set_reduced_motion(enabled: bool) -> void:
	_reduced_motion = enabled
	queue_redraw()


func _draw() -> void:
	var full := Rect2(Vector2.ZERO, size)
	draw_rect(full, NAVY)
	if simulation == null or size.x < 20.0 or size.y < 20.0:
		return
	var court := Rect2(Vector2(13.0, 13.0), size - Vector2(26.0, 26.0))
	var sx := court.size.x / float(simulation.COURT_W)
	var sy := court.size.y / float(simulation.COURT_H)
	var sw := minf(sx, sy)
	var line_width := maxf(1.5, sw * 3.1)
	var radius := 34.0 * sw
	draw_texture_rect(WOOD_FLOOR, court, false)
	# Alternating broad floor lanes keep player and ball movement easy to locate.
	for lane in range(1, 10):
		var x := court.position.x + court.size.x * float(lane) / 10.0
		if lane % 2 == 0:
			draw_rect(Rect2(Vector2(x, court.position.y), Vector2(court.size.x / 20.0, court.size.y)), Color(COURT_LIGHT, 0.18))
	draw_rect(court, LINE_COLOR, false, line_width)
	var middle_x := court.position.x + court.size.x * 0.5
	var center := Vector2(middle_x, court.position.y + court.size.y * 0.5)
	draw_line(Vector2(middle_x, court.position.y), Vector2(middle_x, court.end.y), LINE_COLOR, line_width)
	draw_arc(center, minf(court.size.y * 0.17, court.size.x * 0.09), 0.0, TAU, 64, LINE_COLOR, line_width, true)
	var left_key := Rect2(court.position.x, court.position.y + court.size.y * 0.32, court.size.x * 0.17, court.size.y * 0.36)
	var right_key := Rect2(court.end.x - court.size.x * 0.17, left_key.position.y, left_key.size.x, left_key.size.y)
	draw_rect(left_key, LINE_COLOR, false, line_width)
	draw_rect(right_key, LINE_COLOR, false, line_width)
	var hoop_left := Vector2(court.position.x + 28.0 * sx, center.y)
	var hoop_right := Vector2(court.end.x - 28.0 * sx, center.y)
	var hoop_size := Vector2(60.0 * sw, 60.0 * sw)
	draw_texture_rect(HOOP, Rect2(hoop_left - hoop_size * 0.5, hoop_size), false)
	draw_texture_rect(HOOP, Rect2(hoop_right - hoop_size * 0.5, hoop_size), false)
	draw_arc(hoop_left, 18.0 * sw, -PI * 0.5, PI * 0.5, 32, ORANGE, line_width * 1.4, true)
	draw_arc(hoop_right, 18.0 * sw, PI * 0.5, PI * 1.5, 32, ORANGE, line_width * 1.4, true)
	draw_line(Vector2(court.position.x, center.y - 16.0 * sy), Vector2(court.position.x, center.y + 16.0 * sy), LINE_COLOR, line_width * 2.0)
	draw_line(Vector2(court.end.x, center.y - 16.0 * sy), Vector2(court.end.x, center.y + 16.0 * sy), LINE_COLOR, line_width * 2.0)
	draw_arc(hoop_left, 224.0 * sw, -PI * 0.5, PI * 0.5, 54, Color(LINE_COLOR, 0.72), line_width, true)
	draw_arc(hoop_right, 224.0 * sw, PI * 0.5, PI * 1.5, 54, Color(LINE_COLOR, 0.72), line_width, true)
	_draw_players(simulation.home_players, 0, court, sx, sy, radius)
	_draw_players(simulation.away_players, 1, court, sx, sy, radius)
	var ball_center := _map_position(simulation.ball_position, court, sx, sy)
	_draw_ball(ball_center, maxf(9.0 * sw, 7.0))
	var possession := String(simulation.home_team) if int(simulation.possession_team) == 0 else String(simulation.away_team)
	draw_string(ThemeDB.fallback_font, Vector2(court.position.x + 10.0, court.position.y + 24.0), possession.to_upper() + " POSSESSION", HORIZONTAL_ALIGNMENT_LEFT, -1.0, 14, Color("#FFF7E8"))
	var direction_text := "Attacking right" if bool(simulation._home_attacks_right()) else "Attacking left"
	draw_string(ThemeDB.fallback_font, Vector2(court.end.x - 145.0, court.position.y + 24.0), direction_text, HORIZONTAL_ALIGNMENT_RIGHT, 136.0, 12, Color("#FFF7E8"))


func _draw_players(players: Array, team: int, court: Rect2, sx: float, sy: float, radius: float) -> void:
	var team_color := ORANGE if team == 0 else TEAL
	var focus_pulse := 0.0 if _reduced_motion else 2.0 * sin(float(Time.get_ticks_msec()) / 240.0)
	for i in range(players.size()):
		var player: Dictionary = players[i]
		var center := _map_position(player.position, court, sx, sy)
		var is_selected := team == 0 and i == int(simulation.selected_index)
		var is_carrier := team == int(simulation.possession_team) and i == int(simulation.carrier_index)
		if is_selected:
			draw_arc(center, radius + 11.0 * minf(sx, sy) + focus_pulse, 0.0, TAU, 36, Color("#FFFFFF"), maxf(2.0, 2.5 * minf(sx, sy)), true)
			if is_carrier:
				draw_arc(center, radius + 5.0 * minf(sx, sy), 0.0, TAU, 36, team_color, maxf(2.5, 3.0 * minf(sx, sy)), true)
		if is_carrier:
			draw_circle(center, radius * 0.92, Color(NAVY, 0.78))
		var atlas_index := (0 if team == 0 else 1) if i % 2 == 0 else (3 if team == 0 else 2)
		var cell_size := Vector2(PLAYER_ATLAS.get_width() / 2.0, PLAYER_ATLAS.get_height() / 2.0)
		var atlas_origin := Vector2(float(atlas_index % 2) * cell_size.x, float(atlas_index / 2) * cell_size.y)
		var source_rect := Rect2(atlas_origin, cell_size)
		var dest_size := Vector2(maxf(radius * 1.35, 19.0), maxf(radius * 1.75, 25.0))
		draw_texture_rect_region(PLAYER_ATLAS, Rect2(center - dest_size * 0.5, dest_size), source_rect, Color.WHITE, false, true)
		if is_selected:
			var jersey_number := String(player.get("jersey_number", ""))
			var label := String(player.get("name", "Player"))
			if not jersey_number.is_empty():
				label = "#%s %s" % [jersey_number, label]
			draw_string(ThemeDB.fallback_font, center + Vector2(-44.0 * sx, radius + 15.0 * sy), label, HORIZONTAL_ALIGNMENT_CENTER, 88.0 * sx, 10, Color("#101A2B"))


func _draw_ball(center: Vector2, ball_radius: float) -> void:
	var diameter := ball_radius * 2.6
	draw_circle(center, diameter * 0.56, Color("#FFF9ED"))
	draw_texture_rect(BASKETBALL, Rect2(center - Vector2.ONE * diameter * 0.5, Vector2.ONE * diameter), false)


func _map_position(value: Vector2, court: Rect2, sx: float, sy: float) -> Vector2:
	return court.position + Vector2(value.x * sx, value.y * sy)
