extends Node

const SIDELINE := {
	"tipoff": "res://assets/game/audio/announcer/sideline_start.ogg",
	"home_score": "res://assets/game/audio/announcer/sideline_home_score.ogg",
	"away_score": "res://assets/game/audio/announcer/sideline_away_score.ogg",
	"miss": "res://assets/game/audio/announcer/sideline_rim.ogg",
	"foul": "res://assets/game/audio/announcer/sideline_free_throw.ogg",
	"game_over": "res://assets/game/audio/announcer/sideline_final.ogg"
}
const ANALYSTS := {
	"pass": "res://assets/game/audio/announcer/puck_pass.ogg",
	"assist": "res://assets/game/audio/announcer/puck_score.ogg",
	"steal": "res://assets/game/audio/announcer/fenrir_block.ogg",
	"overtime": "res://assets/game/audio/announcer/fenrir_fastbreak.ogg",
	"free_throw_miss": "res://assets/game/audio/announcer/zube_looseball.ogg",
	"defense": "res://assets/game/audio/announcer/zube_turnover.ogg"
}
const HALFTIME_LISA := "res://assets/game/audio/announcer/lisa_halftime.wav"
const HALFTIME_JAMIE := "res://assets/game/audio/announcer/jamie_halftime.wav"
const EFFECT_PATHS := {
	"ball_bounce": "res://assets/game/audio/ball_bounce.mp3",
	"dribble": "res://assets/game/audio/dribble.mp3",
	"rim": "res://assets/game/audio/shot_rim.mp3",
	"swish": "res://assets/game/audio/shot_swish.mp3",
	"score": "res://assets/game/audio/score.mp3",
	"shot_clock": "res://assets/game/audio/shot_clock.mp3",
	"whistle": "res://assets/game/audio/ref_whistle.mp3",
	"victory": "res://assets/game/audio/victory.mp3"
}
const CROWD_PATHS := {
	"home_score": "res://assets/game/audio/crowd_cheer_home.mp3",
	"away_score": "res://assets/game/audio/crowd_room.mp3",
	"boo": "res://assets/game/audio/crowd_free_throw_boo.mp3"
}
const EFFECT_CUES := {
	"ball_bounce": "basketball.ball_bounce",
	"dribble": "basketball.dribble",
	"rim": "basketball.rim",
	"swish": "basketball.swish",
	"score": "basketball.score",
	"shot_clock": "basketball.shot_clock",
	"whistle": "basketball.whistle",
	"victory": "basketball.victory"
}

var narration_enabled := true
var commentary_enabled := true
var crowd_enabled := true
var effects_enabled := true
var crowd_volume := 0.25
var effects_volume := 0.82
var narration_volume := 0.82
var commentary_volume := 0.88
var ui_volume := 0.80
var _voice_player: AudioStreamPlayer
var _crowd_player: AudioStreamPlayer
var _crowd_reaction_player: AudioStreamPlayer
var _crowd_streams: Dictionary = {}
var _voice_queue: Array[Dictionary] = []
var _voice_busy := false
var _waiting_for_tts := false
var _waiting_for_web_tts := false
var _web_tts_left := 0.0
var _current_text := ""
var _current_detail := false
var _crowd_active := false
var _crowd_ducked := false
var _voice_name := "Sideline Reporter"
var _last_dribble := 0.0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_voice_player = AudioStreamPlayer.new()
	_voice_player.name = "CommentaryVoice"
	_voice_player.bus = "Voice"
	_voice_player.volume_db = linear_to_db(maxf(commentary_volume, 0.001)) - 6.0206
	_voice_player.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(_voice_player)
	_voice_player.finished.connect(_on_voice_clip_finished)
	_crowd_player = AudioStreamPlayer.new()
	_crowd_player.name = "ArenaCrowdBed"
	_crowd_player.bus = "Crowd"
	_crowd_player.volume_db = 0.0
	_crowd_player.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(_crowd_player)
	_crowd_player.stream = load("res://assets/game/audio/crowd_ambience_loop.mp3") as AudioStream
	_crowd_reaction_player = AudioStreamPlayer.new()
	_crowd_reaction_player.name = "CrowdReaction"
	_crowd_reaction_player.bus = "Crowd"
	_crowd_reaction_player.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(_crowd_reaction_player)
	for reaction_id: String in CROWD_PATHS:
		_crowd_streams[reaction_id] = load(CROWD_PATHS[reaction_id]) as AudioStream
	if _crowd_player.stream is AudioStreamMP3:
		(_crowd_player.stream as AudioStreamMP3).loop = true
	elif _crowd_player.stream is AudioStreamOggVorbis:
		(_crowd_player.stream as AudioStreamOggVorbis).loop = true
	for effect_id: String in EFFECT_PATHS:
		AudioDirector.register_cue(EFFECT_CUES[effect_id], EFFECT_PATHS[effect_id])
	_update_crowd_mix()


func _process(delta: float) -> void:
	if _waiting_for_web_tts:
		_web_tts_left -= delta
		if _web_tts_left <= 0.0:
			_waiting_for_web_tts = false
			_finish_voice()
	elif _waiting_for_tts and not DisplayServer.tts_is_speaking():
		_waiting_for_tts = false
		_finish_voice()


func unlock() -> void:
	AudioDirector.unlock_audio()


func start_arena() -> void:
	_crowd_active = true
	if crowd_enabled and _crowd_player.stream != null and not _crowd_player.playing:
		_crowd_player.play()
	_update_crowd_mix()


func stop_arena() -> void:
	_crowd_active = false
	if _crowd_player.playing:
		_crowd_player.stop()
	if _crowd_reaction_player.playing:
		_crowd_reaction_player.stop()


func set_crowd_enabled(enabled: bool) -> void:
	crowd_enabled = enabled
	if not crowd_enabled:
		if _crowd_player.playing:
			_crowd_player.stop()
		if _crowd_reaction_player.playing:
			_crowd_reaction_player.stop()
	elif _crowd_active:
		if _crowd_player.stream != null and not _crowd_player.playing:
			_crowd_player.play()
	_update_crowd_mix()


func set_narration_enabled(enabled: bool) -> void:
	narration_enabled = enabled
	if not enabled:
		_cancel_voices()


func set_effects_enabled(enabled: bool) -> void:
	effects_enabled = enabled


func set_crowd_volume(value: float) -> void:
	crowd_volume = clampf(value, 0.0, 1.0)
	_update_crowd_mix()


func set_effects_volume(value: float) -> void:
	effects_volume = clampf(value, 0.0, 1.0)
	_set_audio_director_volume("audio.sfx.volume_db", effects_volume, "SFX")


func set_narration_volume(value: float) -> void:
	narration_volume = clampf(value, 0.0, 1.0)


func set_commentary_volume(value: float) -> void:
	commentary_volume = clampf(value, 0.0, 1.0)
	if _voice_player != null:
		_voice_player.volume_db = linear_to_db(maxf(commentary_volume, 0.001)) - 6.0206


func set_ui_volume(value: float) -> void:
	ui_volume = clampf(value, 0.0, 1.0)
	_set_audio_director_volume("audio.ui.volume_db", ui_volume, "UI")


func _set_audio_director_volume(setting_id: String, level: float, bus_name: String) -> void:
	var bus_index := AudioServer.get_bus_index(bus_name)
	var setting: Dictionary = TuningStore.get_setting(setting_id)
	var db := linear_to_db(maxf(level, 0.001))
	if not setting.is_empty():
		db = clampf(db, float(setting.get("min", -60.0)), minf(0.0, float(setting.get("max", 0.0))))
		TuningStore.set_value(setting_id, db, false)
	elif bus_index >= 0:
		AudioServer.set_bus_volume_db(bus_index, minf(db, 0.0))


func handle_event(kind: String, text: String) -> void:
	match kind:
		"pass":
			_play_effect("ball_bounce")
		"shot":
			_last_dribble = 0.0
		"home_score", "assist":
			_play_effect("swish")
			_play_effect("score", 1.0)
			_play_crowd_reaction("home_score")
			_vibrate(65)
		"away_score":
			_play_effect("swish")
			_play_effect("score", 0.95)
			_play_crowd_reaction("away_score")
			_vibrate(45)
		"miss":
			_play_effect("rim")
		"foul":
			_play_effect("whistle")
		"free_throw_start":
			_play_crowd_reaction("boo")
		"home_free_throw_make":
			_play_effect("swish", 0.96)
			_play_crowd_reaction("home_score")
			_vibrate(50)
		"away_free_throw_make":
			_play_effect("swish", 0.94)
			_play_crowd_reaction("away_score")
			_vibrate(35)
		"free_throw_miss":
			_play_effect("rim", 0.90)
		"shot_clock":
			_play_effect("shot_clock")
		"game_over":
			if text.contains("Home wins"):
				_play_effect("victory")
			elif text.contains("Away wins"):
				_play_crowd_reaction("away_score")
	if not commentary_enabled or not narration_enabled:
		return
	if kind == "halftime":
		_queue_voice("", HALFTIME_LISA, false)
		_queue_voice("", HALFTIME_JAMIE, false)
		_queue_voice(text, "", true)
	elif kind != "free_throw_start":
		var voice_kind := "home_score" if kind == "home_free_throw_make" else "away_score" if kind == "away_free_throw_make" else kind
		var clip_path := String(SIDELINE.get(voice_kind, ANALYSTS.get(voice_kind, "")))
		var detail := kind in ["home_score", "away_score", "assist", "foul", "home_free_throw_make", "away_free_throw_make", "free_throw_miss", "game_over", "tipoff", "halftime", "quarter", "overtime", "timeout", "steal", "shot_clock", "resume"]
		_queue_voice(text, clip_path, detail)


func read_status(text: String) -> void:
	if not narration_enabled:
		return
	_cancel_voices()
	_voice_queue.append({"text": text, "clip": "", "detail": false})
	_pump_voice_queue()


func play_reporter_intro() -> void:
	if commentary_enabled and narration_enabled:
		_queue_voice("We're courtside, and this game is starting to sizzle.", String(SIDELINE.tipoff), false)


func set_paused(paused: bool) -> void:
	if paused:
		stop_arena()
	AudioDirector.set_game_paused(paused)


func _queue_voice(text: String, clip_path: String, speak_details: bool) -> void:
	if not narration_enabled:
		return
	_voice_queue.append({"text": text, "clip": clip_path, "detail": speak_details})
	while _voice_queue.size() > 5:
		_voice_queue.pop_front()
	_pump_voice_queue()


func _pump_voice_queue() -> void:
	if _voice_busy or _voice_queue.is_empty() or not narration_enabled:
		return
	var data: Dictionary = _voice_queue.pop_front()
	_current_text = String(data.text)
	_current_detail = bool(data.detail)
	var clip_path := String(data.clip)
	if commentary_enabled and not clip_path.is_empty() and ResourceLoader.exists(clip_path):
		_voice_name = _persona_for_path(clip_path)
		_voice_player.stream = load(clip_path) as AudioStream
		_voice_player.play()
		_voice_busy = true
		_set_crowd_ducked(true)
		return
	_voice_name = "Game Announcer"
	_speak_text(_current_text)


func _on_voice_clip_finished() -> void:
	if _current_detail and narration_enabled:
		_speak_text(_current_text)
	else:
		_finish_voice()


func _speak_text(text: String) -> void:
	if text.is_empty() or not narration_enabled:
		_finish_voice()
		return
	_voice_busy = true
	_set_crowd_ducked(true)
	if Engine.has_singleton("JavaScriptBridge"):
		var bridge: Object = Engine.get_singleton("JavaScriptBridge")
		if bridge != null:
			var safe_text := JSON.stringify(text)
			bridge.call("eval", "if(window.speechSynthesis){window.speechSynthesis.cancel();var u=new SpeechSynthesisUtterance(%s);u.volume=%s;u.rate=1.0;window.speechSynthesis.speak(u);}" % [safe_text, str(narration_volume)], true)
			_waiting_for_web_tts = true
			_web_tts_left = maxf(1.2, float(text.length()) / 13.0)
			return
	var voices: Array = DisplayServer.tts_get_voices()
	if voices.is_empty():
		_finish_voice()
		return
	var voice_id := String(voices[0].get("id", ""))
	DisplayServer.tts_speak(text, voice_id, narration_volume * 100.0, 1.0, 1.0, 0, true)
	_waiting_for_tts = true


func _finish_voice() -> void:
	_waiting_for_tts = false
	_waiting_for_web_tts = false
	_voice_busy = false
	_current_text = ""
	_current_detail = false
	_set_crowd_ducked(false)
	_pump_voice_queue()


func _cancel_voices() -> void:
	_voice_queue.clear()
	_waiting_for_tts = false
	_waiting_for_web_tts = false
	_voice_busy = false
	_web_tts_left = 0.0
	if _voice_player != null and _voice_player.playing:
		_voice_player.stop()
	DisplayServer.tts_stop()
	_set_crowd_ducked(false)


func _exit_tree() -> void:
	release_resources()


func release_resources() -> void:
	_cancel_voices()
	stop_arena()
	if is_instance_valid(_voice_player):
		_voice_player.stream = null
	if is_instance_valid(_crowd_player):
		_crowd_player.stream = null
	if is_instance_valid(_crowd_reaction_player):
		_crowd_reaction_player.stream = null
	_crowd_streams.clear()


func _play_effect(effect_id: String, pitch: float = 1.0) -> void:
	if not effects_enabled:
		return
	var cue_id := String(EFFECT_CUES.get(effect_id, ""))
	if not cue_id.is_empty():
		AudioDirector.play_cue(cue_id, pitch)


func _play_crowd_reaction(reaction_id: String) -> void:
	if not crowd_enabled or not _crowd_streams.has(reaction_id):
		return
	if _crowd_reaction_player.playing:
		_crowd_reaction_player.stop()
	_crowd_reaction_player.stream = _crowd_streams[reaction_id] as AudioStream
	_crowd_reaction_player.play()


func _vibrate(duration_ms: int) -> void:
	if OS.has_feature("android"):
		Input.vibrate_handheld(duration_ms, 0.65)


func _set_crowd_ducked(value: bool) -> void:
	_crowd_ducked = value
	_update_crowd_mix()


func _update_crowd_mix() -> void:
	var bus_index := AudioServer.get_bus_index("Crowd")
	if bus_index < 0:
		return
	var gain := linear_to_db(maxf(crowd_volume, 0.001))
	if _crowd_ducked:
		gain -= 18.0
	AudioServer.set_bus_volume_db(bus_index, minf(gain, 0.0))


func _persona_for_path(path: String) -> String:
	if path.contains("sideline_"):
		return "Abby, courtside reporter"
	if path.contains("puck_"):
		return "Michael, analyst"
	if path.contains("fenrir_"):
		return "Andrei, analyst"
	if path.contains("zube_"):
		return "Adam, commentator"
	if path.contains("lisa_halftime"):
		return "Lisa, halftime analyst"
	if path.contains("jamie_halftime"):
		return "Jamie, halftime analyst"
	return "Basketball commentator"
