extends Control

const MatchType := preload("res://scripts/game/basketball_match.gd")
const CourtViewType := preload("res://scripts/game/court_view.gd")
const GameAudioType := preload("res://scripts/audio/game_audio.gd")
const RosterCatalogType := preload("res://scripts/data/league_roster_catalog.gd")
const APP_NAME := "Blind Basketball Game"
const APP_VERSION := "1.0.2"
const CREATOR := "Darry John Sarmiento"
const TELEGRAM_URL := "https://t.me/gwapokobay1639"
const PROFILE_PATH := "user://blind_basketball_profile.cfg"
const MATCH_PATH := "user://blind_basketball_saved_match.json"
const TEAM_NAMES := ["Harbor City Waves", "Metro Comets", "Copper Canyon", "Northside Owls", "Coastal Current", "Skyline Sparks"]
const TEAM_COLORS := [Color("#F47A38"), Color("#10BDB5"), Color("#D95D39"), Color("#21A0A0"), Color("#C87E32"), Color("#42A1E8")]

var _audio
var _simulation
var _court_view
var _root_layout: VBoxContainer
var _body_scroll: ScrollContainer
var _body: VBoxContainer
var _footer: Label
var _screen := "home"
var _help_return_screen := "home"
var _settings_return_screen := "home"
var _career_setup := false
var _career_mode := false
var _selected_players := 5
var _last_home_team := TEAM_NAMES[0]
var _last_away_team := TEAM_NAMES[1]
var _roster_catalog
var _roster_data_loaded := false
var _selected_home_league_id := ""
var _selected_away_league_id := ""
var _selected_home_team_id := ""
var _selected_away_team_id := ""
var _selected_home_starters: Array[String] = []
var _selected_away_starters: Array[String] = []
var _profile: Dictionary = {"name": "Rookie", "games": 0, "wins": 0, "losses": 0}
var _settings: Dictionary = {"narration": true, "commentary": true, "crowd": true, "effects": true, "speech_volume": 0.82, "commentary_volume": 0.88, "crowd_volume": 0.25, "effects_volume": 0.82, "ui_volume": 0.80, "match_duration_minutes": 12, "reduced_motion": false}
var _touch_directions: Dictionary = {}
var _touch_sprint := false
var _last_event_text := ""
var _hud_time := 0.0
var _final_recorded := false
var _settings_controls: Array[Control] = []
var _top_label: Label
var _status_label: Label
var _score_label: Label
var _clock_label: Label
var _shot_label: Label
var _progress_bar: ProgressBar
var _progress_label: Label
var _event_label: Label
var _home_option: OptionButton
var _away_option: OptionButton
var _mode_option: OptionButton
var _home_league_option: OptionButton
var _away_league_option: OptionButton
var _home_team_option: OptionButton
var _away_team_option: OptionButton
var _home_roster_button: Button
var _away_roster_button: Button
var _home_roster_panel: ScrollContainer
var _away_roster_panel: ScrollContainer
var _home_roster_label: Label
var _away_roster_label: Label
var _home_starter_status: Label
var _away_starter_status: Label
var _home_starter_list: VBoxContainer
var _away_starter_list: VBoxContainer
var _setup_start_button: Button
var _home_roster_expanded := false
var _away_roster_expanded := false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_audio = GameAudioType.new()
	_audio.name = "GameAudio"
	add_child(_audio)
	_roster_catalog = RosterCatalogType.new()
	_roster_data_loaded = _roster_catalog.load_file()
	_load_profile_and_settings()
	_build_shell()
	_show_home()
	call_deferred("_focus_first_button")


func _process(delta: float) -> void:
	if _screen != "game" or _simulation == null:
		return
	var direction := Input.get_vector("move_left", "move_right", "move_up", "move_down")
	for key: Variant in _touch_directions.keys():
		direction += _touch_directions[key]
	if direction.length() > 1.0:
		direction = direction.normalized()
	_simulation.tick(delta, direction, Input.is_key_pressed(KEY_SHIFT) or _touch_sprint)
	if _court_view != null:
		_court_view.queue_redraw()
	_hud_time += delta
	if _hud_time >= 0.15:
		_hud_time = 0.0
		_update_game_hud()
	if _simulation.game_over and not _final_recorded:
		call_deferred("_show_results")


func _unhandled_key_input(event: InputEvent) -> void:
	if not event is InputEventKey or not event.pressed or event.echo:
		return
	var key := event as InputEventKey
	if key.ctrl_pressed and key.keycode == KEY_H:
		_open_help()
		get_viewport().set_input_as_handled()
		return
	if _screen == "help":
		if key.keycode == KEY_ESCAPE:
			_close_help()
			get_viewport().set_input_as_handled()
		return
	if _screen == "game":
		_audio.unlock()
		match key.keycode:
			KEY_SPACE:
				_simulation.pass_ball(Input.get_vector("move_left", "move_right", "move_up", "move_down"))
			KEY_ENTER, KEY_KP_ENTER, KEY_J:
				_simulation.shoot()
			KEY_F:
				_simulation.defend()
			KEY_TAB:
				_simulation.switch_player()
			KEY_T:
				_simulation.call_timeout()
			KEY_B:
				_simulation.substitute()
			KEY_V:
				_read_match_status()
			KEY_ESCAPE:
				_show_pause()
		get_viewport().set_input_as_handled()
	elif key.keycode == KEY_ESCAPE:
		if _screen == "pause":
			_resume_game()
		elif _screen == "settings":
			_close_settings()
		elif _screen != "home":
			_show_home()
		get_viewport().set_input_as_handled()


func _build_shell() -> void:
	var background := ColorRect.new()
	background.color = Color("#101A2B")
	background.mouse_filter = Control.MOUSE_FILTER_IGNORE
	background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(background)
	var margins := MarginContainer.new()
	margins.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margins.add_theme_constant_override("margin_left", 22)
	margins.add_theme_constant_override("margin_right", 22)
	margins.add_theme_constant_override("margin_top", 14)
	margins.add_theme_constant_override("margin_bottom", 12)
	add_child(margins)
	_root_layout = VBoxContainer.new()
	_root_layout.add_theme_constant_override("separation", 10)
	margins.add_child(_root_layout)
	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 16)
	_root_layout.add_child(header)
	var title := Label.new()
	title.text = APP_NAME
	title.add_theme_font_size_override("font_size", 26)
	title.add_theme_color_override("font_color", Color("#F47A38"))
	title.accessibility_name = APP_NAME
	title.accessibility_description = "Game title. Version %s." % APP_VERSION
	header.add_child(title)
	_top_label = Label.new()
	_top_label.text = "Audio-first basketball for Windows and Android"
	_top_label.add_theme_font_size_override("font_size", 15)
	_top_label.add_theme_color_override("font_color", Color("#D7E3F0"))
	_top_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_top_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(_top_label)
	_body_scroll = ScrollContainer.new()
	_body_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_body_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_body_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_root_layout.add_child(_body_scroll)
	_body = VBoxContainer.new()
	_body.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_body.add_theme_constant_override("separation", 12)
	_body_scroll.add_child(_body)
	_footer = Label.new()
	_footer.text = "Windows: Ctrl+H help. Menus: Tab / Shift+Tab, then Enter."
	_footer.add_theme_font_size_override("font_size", 13)
	_footer.add_theme_color_override("font_color", Color("#B6C7D8"))
	_footer.accessibility_name = "Keyboard guidance"
	_root_layout.add_child(_footer)


func _show_home() -> void:
	_screen = "home"
	_career_mode = false
	_audio.stop_arena()
	_audio.set_paused(false)
	_clear_body()
	_top_label.text = "Audio-first basketball · Windows and Android · Version " + APP_VERSION
	var hero := HBoxContainer.new()
	hero.add_theme_constant_override("separation", 18)
	_body.add_child(hero)
	var icon := TextureRect.new()
	icon.texture = load("res://assets/share/favicon.png") as Texture2D
	icon.custom_minimum_size = Vector2(88, 88)
	icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	icon.accessibility_name = "Blind Basketball Game app icon"
	hero.add_child(icon)
	var intro := VBoxContainer.new()
	intro.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hero.add_child(intro)
	_add_heading(intro, "Hear the court. Make the play.", 30)
	_add_text(intro, "Play accessible 2-on-2, 3-on-3 or 5-on-5 basketball against AI. Use passing, shooting, defence and team management with spoken match updates.")
	_add_text(intro, "Player: %s · Career record: %d wins, %d losses" % [_profile.name, int(_profile.wins), int(_profile.losses)])
	var card := _new_card()
	_body.add_child(card)
	var actions := VBoxContainer.new()
	actions.add_theme_constant_override("separation", 8)
	card.add_child(actions)
	_add_heading(actions, "Play", 20)
	_add_button(actions, "Quick Exhibition", "Set up an offline match against AI.", func() -> void: _show_setup(false))
	_add_button(actions, "Career Match", "Start or continue your saved local career.", func() -> void: _show_setup(true))
	if FileAccess.file_exists(MATCH_PATH):
		_add_button(actions, "Continue Saved Match", "Resume the saved match and current score.", _continue_saved_match)
	_add_button(actions, "Player Profile", "Change the player name and review local career results.", _show_profile)
	_add_button(actions, "Settings", "Set 2–12 minute match length and individual narration, commentary, crowd, effects and interface volumes.", _show_settings)
	_add_button(actions, "How to Play, About and Credits", "Read the startup guide, Windows and Android controls, creator credit and community link.", _show_about)
	if not OS.has_feature("android"):
		_add_button(actions, "Exit Game", "Close Blind Basketball Game.", func() -> void: get_tree().quit())
	_footer.text = "Windows help: Ctrl+H · Menus: Tab / Shift+Tab and Enter · One-player local play against AI"
	call_deferred("_focus_first_button")


func _show_setup(career: bool) -> void:
	_screen = "setup"
	_career_setup = career
	_setup_start_button = null
	_clear_body()
	_top_label.text = "Career setup" if career else "Exhibition setup"
	var card := _new_card()
	_body.add_child(card)
	var stack := VBoxContainer.new()
	stack.add_theme_constant_override("separation", 9)
	card.add_child(stack)
	_add_heading(stack, "Choose teams and match size", 24)
	_add_text(stack, "Offline match. The computer controls teammates and the opposing team. Passing and shooting are explicit buttons, not timing tests.")
	_mode_option = _new_option(["5-on-5 · full lineup", "3-on-3 · small-sided", "2-on-2 · quick match"], "Team size", "Choose a 5, 3 or 2 player team.")
	_mode_option.select(0 if _selected_players == 5 else 1 if _selected_players == 3 else 2)
	_mode_option.item_selected.connect(_on_match_size_selected)
	stack.add_child(_labeled_field("Players per side", _mode_option))
	if _has_league_rosters():
		_add_text(stack, "Choose the home and opponent leagues independently in Exhibition. Expand both sourced rosters and select who starts for each team. The preselected names are editable convenience choices, not an official starting lineup.")
		_build_league_fields(stack)
		_add_roster_disclosure(stack, "home")
		_add_roster_disclosure(stack, "away")
		var inactive_note: String = String(_roster_catalog.inactive_summary())
		if not inactive_note.is_empty():
			_add_text(stack, "League status: " + inactive_note)
	else:
		_home_option = _new_option(TEAM_NAMES, "Home team", "Choose the team you control.")
		_home_option.select(maxi(0, TEAM_NAMES.find(_last_home_team)))
		stack.add_child(_labeled_field("Your home team", _home_option))
		_away_option = _new_option(TEAM_NAMES, "Opponent team", "Choose the AI opponent.")
		_away_option.select(maxi(0, TEAM_NAMES.find(_last_away_team)))
		stack.add_child(_labeled_field("AI opponent", _away_option))
	_setup_start_button = _add_button(stack, "Start %s" % ("Career Match" if career else "Exhibition"), "Start the selected basketball match.", _begin_match)
	if _has_league_rosters():
		_update_start_button()
	_add_button(stack, "Back to Main Menu", "Return without starting a match.", _show_home)
	_footer.text = "Use Tab to reach each setup option; Enter activates the focused choice. Exhibition supports cross-league opponents when current rosters are loaded."
	call_deferred("_focus_first_button")


func _begin_match() -> void:
	_audio.unlock()
	var mode_index := _mode_option.selected
	_selected_players = 5 if mode_index == 0 else 3 if mode_index == 1 else 2
	var home_roster: Array[Dictionary] = []
	var away_roster: Array[Dictionary] = []
	if _has_league_rosters():
		_selected_home_team_id = _selected_option_id(_home_team_option)
		_selected_away_team_id = _selected_option_id(_away_team_option)
		if not _roster_catalog.matchup_resolves(_selected_home_league_id, _selected_home_team_id, _selected_away_league_id, _selected_away_team_id):
			_footer.text = "Choose a home team and a verified AI opponent before starting."
			return
		if _selected_home_league_id == _selected_away_league_id and _selected_home_team_id == _selected_away_team_id:
			_footer.text = "Choose a different team as your AI opponent."
			return
		var home_team_data: Dictionary = _roster_catalog.team_by_id(_selected_home_league_id, _selected_home_team_id)
		var away_team_data: Dictionary = _roster_catalog.team_by_id(_selected_away_league_id, _selected_away_team_id)
		_last_home_team = "%s · %s" % [_roster_catalog.league_name(_selected_home_league_id), String(home_team_data.get("name", "Home team"))]
		_last_away_team = "%s · %s" % [_roster_catalog.league_name(_selected_away_league_id), String(away_team_data.get("name", "AI opponent"))]
		home_roster = _roster_catalog.roster_for_team(_selected_home_league_id, _selected_home_team_id)
		away_roster = _roster_catalog.roster_for_team(_selected_away_league_id, _selected_away_team_id)
		if home_roster.size() < _selected_players or away_roster.size() < _selected_players:
			_footer.text = "Each team needs at least %d sourced players for this match size. Choose a smaller format or different teams." % _selected_players
			return
		if _selected_home_starters.size() != _selected_players or _selected_away_starters.size() != _selected_players:
			_footer.text = "Choose exactly %d starters for both teams before tip-off." % _selected_players
			return
		home_roster = _order_roster_with_starters(home_roster, _selected_home_starters)
		away_roster = _order_roster_with_starters(away_roster, _selected_away_starters)
	else:
		var home_index := _home_option.selected
		var away_index := _away_option.selected
		if away_index == home_index:
			away_index = (home_index + 1) % TEAM_NAMES.size()
		_last_home_team = TEAM_NAMES[home_index]
		_last_away_team = TEAM_NAMES[away_index]
	_career_mode = _career_setup
	_simulation = MatchType.new()
	_simulation.start(_selected_players, _last_home_team, _last_away_team, _career_mode, int(_settings.get("match_duration_minutes", 12)), home_roster, away_roster)
	_simulation.event_occurred.connect(_on_match_event)
	_final_recorded = false
	_show_game()
	_audio.start_arena()
	_on_match_event("tipoff", "Tip-off. %s has possession. %d on %d against %s." % [_last_home_team, _selected_players, _selected_players, _last_away_team])


func _has_league_rosters() -> bool:
	return _roster_catalog != null and _roster_data_loaded and not _roster_catalog.active_league_ids().is_empty()


func _configure_roster_data(data: Dictionary) -> bool:
	if _roster_catalog == null:
		_roster_catalog = RosterCatalogType.new()
	_roster_data_loaded = _roster_catalog.configure(data)
	return _has_league_rosters()


func _build_league_fields(stack: VBoxContainer) -> void:
	var league_ids: Array[String] = _roster_catalog.active_league_ids()
	if league_ids.is_empty():
		return
	if not league_ids.has(_selected_home_league_id):
		_selected_home_league_id = league_ids[0]
	if _career_setup:
		_selected_away_league_id = _selected_home_league_id
	elif not league_ids.has(_selected_away_league_id):
		_selected_away_league_id = _selected_home_league_id
	if not _career_setup and league_ids.size() > 1 and _selected_away_league_id == _selected_home_league_id:
		var home_league_index: int = league_ids.find(_selected_home_league_id)
		_selected_away_league_id = league_ids[(home_league_index + 1) % league_ids.size()]
	_home_league_option = _make_league_option("Home league", "Choose the league for your home team.", _selected_home_league_id)
	_away_league_option = _make_league_option("Opponent league", "Choose the AI opponent's league independently for a cross-league Exhibition.", _selected_away_league_id)
	_away_league_option.disabled = _career_setup
	stack.add_child(_labeled_field("Your home league", _home_league_option))
	stack.add_child(_labeled_field("AI opponent league", _away_league_option))
	_home_team_option = _new_option([], "Home team", "Choose the team you control.")
	_away_team_option = _new_option([], "Opponent team", "Choose the AI opponent team.")
	_selected_home_team_id = _populate_team_option(_home_team_option, _selected_home_league_id, _selected_home_team_id)
	_selected_away_team_id = _populate_team_option(_away_team_option, _selected_away_league_id, _selected_away_team_id)
	if _selected_home_league_id == _selected_away_league_id and _selected_home_team_id == _selected_away_team_id:
		var opponent_teams: Array[Dictionary] = _roster_catalog.teams_for_league(_selected_away_league_id)
		if opponent_teams.size() > 1:
			_selected_away_team_id = String(opponent_teams[1].get("id", ""))
			_away_team_option.select(_option_index_for_id(_away_team_option, _selected_away_team_id))
	stack.add_child(_labeled_field("Your home team", _home_team_option))
	stack.add_child(_labeled_field("AI opponent", _away_team_option))
	_home_league_option.item_selected.connect(_on_home_league_selected)
	_away_league_option.item_selected.connect(_on_away_league_selected)
	_home_team_option.item_selected.connect(_on_home_team_selected)
	_away_team_option.item_selected.connect(_on_away_team_selected)


func _make_league_option(control_name: String, description: String, selected_id: String) -> OptionButton:
	var league_ids: Array[String] = _roster_catalog.active_league_ids()
	var names: Array[String] = []
	for league_id: String in league_ids:
		names.append(_roster_catalog.league_name(league_id))
	var option := _new_option(names, control_name, description)
	for index in range(league_ids.size()):
		option.set_item_metadata(index, league_ids[index])
	option.select(_option_index_for_id(option, selected_id))
	return option


func _populate_team_option(option: OptionButton, league_id: String, preferred_id: String) -> String:
	option.clear()
	var teams: Array[Dictionary] = _roster_catalog.teams_for_league(league_id)
	for team: Dictionary in teams:
		option.add_item(String(team.get("name", "Team")))
		option.set_item_metadata(option.item_count - 1, String(team.get("id", "")))
	if teams.is_empty():
		option.add_item("No current teams verified")
		option.set_item_disabled(0, true)
		option.select(0)
		return ""
	var selected_index := _option_index_for_id(option, preferred_id)
	option.select(selected_index)
	return _selected_option_id(option)


func _option_index_for_id(option: OptionButton, item_id: String) -> int:
	if option == null:
		return 0
	for index in range(option.item_count):
		if String(option.get_item_metadata(index)) == item_id:
			return index
	return 0


func _selected_option_id(option: OptionButton) -> String:
	if option == null or option.item_count == 0:
		return ""
	return String(option.get_item_metadata(option.selected))


func _on_home_league_selected(index: int) -> void:
	_selected_home_league_id = String(_home_league_option.get_item_metadata(index))
	_selected_home_team_id = _populate_team_option(_home_team_option, _selected_home_league_id, "")
	_selected_home_starters.clear()
	if _career_setup:
		_selected_away_league_id = _selected_home_league_id
		_away_league_option.select(_option_index_for_id(_away_league_option, _selected_away_league_id))
		_selected_away_team_id = _populate_team_option(_away_team_option, _selected_away_league_id, "")
		_selected_away_starters.clear()
	elif _selected_away_league_id == _selected_home_league_id:
		var league_ids: Array[String] = _roster_catalog.active_league_ids()
		if league_ids.size() > 1:
			var home_league_index: int = league_ids.find(_selected_home_league_id)
			_selected_away_league_id = league_ids[(home_league_index + 1) % league_ids.size()]
			_away_league_option.select(_option_index_for_id(_away_league_option, _selected_away_league_id))
			_selected_away_team_id = _populate_team_option(_away_team_option, _selected_away_league_id, "")
			_selected_away_starters.clear()
	_update_roster_previews()


func _on_away_league_selected(index: int) -> void:
	if _career_setup:
		return
	_selected_away_league_id = String(_away_league_option.get_item_metadata(index))
	_selected_away_team_id = _populate_team_option(_away_team_option, _selected_away_league_id, "")
	_selected_away_starters.clear()
	_update_roster_previews()


func _on_home_team_selected(index: int) -> void:
	_selected_home_team_id = String(_home_team_option.get_item_metadata(index))
	if _selected_home_league_id == _selected_away_league_id and _selected_home_team_id == _selected_away_team_id:
		var teams: Array[Dictionary] = _roster_catalog.teams_for_league(_selected_away_league_id)
		for team: Dictionary in teams:
			var alternative_id := String(team.get("id", ""))
			if alternative_id != _selected_home_team_id:
				_selected_away_team_id = alternative_id
				_away_team_option.select(_option_index_for_id(_away_team_option, alternative_id))
				_selected_away_starters.clear()
				break
	_selected_home_starters.clear()
	_update_roster_previews()


func _on_away_team_selected(index: int) -> void:
	_selected_away_team_id = String(_away_team_option.get_item_metadata(index))
	_selected_away_starters.clear()
	_update_roster_previews()


func _on_match_size_selected(index: int) -> void:
	_selected_players = 5 if index == 0 else 3 if index == 1 else 2
	_update_roster_previews()


func _add_roster_disclosure(parent: VBoxContainer, side: String) -> void:
	var is_home := side == "home"
	var button := Button.new()
	button.text = "Expand home roster and choose starters" if is_home else "Expand opponent roster and choose starters"
	button.custom_minimum_size = Vector2(0.0, 64.0)
	button.add_theme_font_size_override("font_size", 18)
	button.accessibility_name = button.text
	button.accessibility_description = "Review the sourced roster and choose the starting players for this team."
	button.focus_mode = Control.FOCUS_ALL
	button.pressed.connect(func() -> void: _toggle_roster_panel(side))
	parent.add_child(button)
	var panel := ScrollContainer.new()
	panel.custom_minimum_size = Vector2(0.0, 280.0)
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	panel.visible = false
	var content := VBoxContainer.new()
	content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	content.add_theme_constant_override("separation", 6)
	panel.add_child(content)
	var label := Label.new()
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	label.accessibility_name = "Verified roster details"
	label.accessibility_description = "Roster date, research scope, completeness and source URLs. Player names are listed in the selectable controls below."
	content.add_child(label)
	var status := Label.new()
	status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	status.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	status.accessibility_name = "Starting lineup selection status"
	content.add_child(status)
	var starter_list := VBoxContainer.new()
	starter_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	content.add_child(starter_list)
	parent.add_child(panel)
	if is_home:
		_home_roster_button = button
		_home_roster_panel = panel
		_home_roster_label = label
		_home_starter_status = status
		_home_starter_list = starter_list
	else:
		_away_roster_button = button
		_away_roster_panel = panel
		_away_roster_label = label
		_away_starter_status = status
		_away_starter_list = starter_list
	_update_roster_previews()


func _toggle_roster_panel(side: String) -> void:
	if side == "home":
		_home_roster_expanded = not _home_roster_expanded
		_home_roster_panel.visible = _home_roster_expanded
		_home_roster_button.text = "Collapse home roster and starter choices" if _home_roster_expanded else "Expand home roster and choose starters"
		_home_roster_button.accessibility_name = _home_roster_button.text
	else:
		_away_roster_expanded = not _away_roster_expanded
		_away_roster_panel.visible = _away_roster_expanded
		_away_roster_button.text = "Collapse opponent roster and starter choices" if _away_roster_expanded else "Expand opponent roster and choose starters"
		_away_roster_button.accessibility_name = _away_roster_button.text
	_update_roster_previews()
	call_deferred("_configure_accessibility_flow")


func _update_roster_previews() -> void:
	if _roster_catalog == null or not _roster_data_loaded:
		_update_start_button()
		return
	_ensure_starter_selection("home")
	_ensure_starter_selection("away")
	if _home_roster_label != null:
		var home_roster: Array[Dictionary] = _roster_catalog.roster_for_team(_selected_home_league_id, _selected_home_team_id)
		_home_roster_label.text = _format_roster(_selected_home_league_id, _selected_home_team_id, false)
		_refresh_starter_controls("home", home_roster)
		if _away_roster_label != null:
			var away_roster: Array[Dictionary] = _roster_catalog.roster_for_team(_selected_away_league_id, _selected_away_team_id)
			_away_roster_label.text = _format_roster(_selected_away_league_id, _selected_away_team_id, false)
			_refresh_starter_controls("away", away_roster)
		_update_start_button()
		call_deferred("_configure_accessibility_flow")


func _ensure_starter_selection(side: String) -> void:
	var league_id: String = _selected_home_league_id if side == "home" else _selected_away_league_id
	var team_id: String = _selected_home_team_id if side == "home" else _selected_away_team_id
	var roster: Array[Dictionary] = _roster_catalog.roster_for_team(league_id, team_id)
	var available_names: Array[String] = []
	for player: Dictionary in roster:
		var player_name: String = String(player.get("name", "")).strip_edges()
		if not player_name.is_empty() and not available_names.has(player_name):
			available_names.append(player_name)
	var selected_names: Array[String] = _selected_home_starters.duplicate() if side == "home" else _selected_away_starters.duplicate()
	var required_count: int = mini(_selected_players, available_names.size())
	var normalized: Array[String] = []
	for player_name: String in selected_names:
		if available_names.has(player_name) and not normalized.has(player_name) and normalized.size() < required_count:
			normalized.append(player_name)
	for player_name: String in available_names:
		if normalized.size() >= required_count:
			break
		if not normalized.has(player_name):
			normalized.append(player_name)
	if side == "home":
		_selected_home_starters = normalized
	else:
		_selected_away_starters = normalized


func _refresh_starter_controls(side: String, roster: Array[Dictionary]) -> void:
	var status: Label = _home_starter_status if side == "home" else _away_starter_status
	var starter_list: VBoxContainer = _home_starter_list if side == "home" else _away_starter_list
	if status == null or starter_list == null:
		return
	for child: Node in starter_list.get_children():
		starter_list.remove_child(child)
		child.queue_free()
	var selected_names: Array[String] = _selected_home_starters if side == "home" else _selected_away_starters
	var team_label: String = "home team" if side == "home" else "AI opponent"
	status.text = "%s: %d of %d starters selected. The listed order is not an official starting lineup; uncheck a name before choosing a replacement." % [team_label, selected_names.size(), _selected_players]
	status.accessibility_description = status.text
	if roster.is_empty():
		var empty_label := Label.new()
		empty_label.text = "No player list is available for this selected team."
		empty_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		starter_list.add_child(empty_label)
		return
	var intro := Label.new()
	intro.text = "Choose exactly %d starters. The initial choices are convenience defaults, not reported official starters." % _selected_players
	intro.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	starter_list.add_child(intro)
	for player: Dictionary in roster:
		var player_name: String = String(player.get("name", "")).strip_edges()
		var entry_text := player_name
		var jersey: String = String(player.get("number", ""))
		var position_name: String = String(player.get("position", ""))
		var classification: String = String(player.get("classification", ""))
		if not jersey.is_empty():
			entry_text += " · #%s" % jersey
		if not position_name.is_empty():
			entry_text += " · " + position_name
		if classification in ["two-way", "import"]:
			entry_text += " · " + classification
		var check := CheckButton.new()
		check.text = entry_text
		check.button_pressed = selected_names.has(player_name)
		check.custom_minimum_size = Vector2(0.0, 64.0)
		check.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		check.focus_mode = Control.FOCUS_ALL
		check.accessibility_name = "%s starter: %s" % [team_label.capitalize(), player_name]
		check.accessibility_description = "Toggle this sourced roster player in the starting lineup. This is a user-selected starter, not an official team announcement."
		check.toggled.connect(_on_starter_toggled.bind(side, player_name))
		starter_list.add_child(check)


func _on_starter_toggled(is_selected: bool, side: String, player_name: String) -> void:
	var selected_names: Array[String] = _selected_home_starters.duplicate() if side == "home" else _selected_away_starters.duplicate()
	if is_selected and not selected_names.has(player_name):
		selected_names.append(player_name)
	elif not is_selected:
		selected_names.erase(player_name)
	if side == "home":
		_selected_home_starters = selected_names
	else:
		_selected_away_starters = selected_names
	var status: Label = _home_starter_status if side == "home" else _away_starter_status
	if status != null:
		var team_label: String = "home team" if side == "home" else "AI opponent"
		status.text = "%s: %d of %d starters selected." % [team_label, selected_names.size(), _selected_players]
		status.accessibility_description = status.text
	_update_start_button()


func _update_start_button() -> void:
	if _setup_start_button == null:
		return
	if not _has_league_rosters():
		_setup_start_button.disabled = false
		return
	var home_roster: Array[Dictionary] = _roster_catalog.roster_for_team(_selected_home_league_id, _selected_home_team_id) if _roster_catalog != null else []
	var away_roster: Array[Dictionary] = _roster_catalog.roster_for_team(_selected_away_league_id, _selected_away_team_id) if _roster_catalog != null else []
	var lineups_valid: bool = home_roster.size() >= _selected_players and away_roster.size() >= _selected_players and _selected_home_starters.size() == _selected_players and _selected_away_starters.size() == _selected_players
	_setup_start_button.disabled = not lineups_valid
	_setup_start_button.accessibility_description = "Start when exactly %d starters are selected for both teams." % _selected_players


func _order_roster_with_starters(roster: Array[Dictionary], starter_names: Array[String]) -> Array[Dictionary]:
	var ordered: Array[Dictionary] = []
	var included: Dictionary = {}
	for player_name: String in starter_names:
		for player: Dictionary in roster:
			if String(player.get("name", "")) == player_name and not included.has(player_name):
				ordered.append(player)
				included[player_name] = true
				break
	for player: Dictionary in roster:
		var player_name: String = String(player.get("name", ""))
		if not included.has(player_name):
			ordered.append(player)
	return ordered


func _format_roster(league_id: String, team_id: String, include_players: bool = true) -> String:
	var team: Dictionary = _roster_catalog.team_by_id(league_id, team_id)
	if team.is_empty():
		return "No verified roster data is available for this team."
	var lines: Array[String] = []
	var roster_date: String = String(team.get("as_of_date", _roster_catalog.as_of_date))
	lines.append("%s · %s · roster as of %s" % [_roster_catalog.league_name(league_id), String(team.name), roster_date])
	var league_note: String = _roster_catalog.status_note(league_id)
	if not league_note.is_empty():
		lines.append("Competition/data status: " + league_note)
	var team_note: String = String(team.get("status", ""))
	if not team_note.is_empty() and team_note != "verified":
		lines.append("Roster note: " + team_note)
	var players: Array[Dictionary] = _roster_catalog.roster_for_team(league_id, team_id)
	if players.is_empty():
		lines.append("No player entries were verified in the available sources.")
	elif include_players:
		for player_index in range(players.size()):
			var player: Dictionary = players[player_index]
			var entry := "%d. %s" % [player_index + 1, String(player.get("name", "Unlisted player"))]
			var number := String(player.get("number", ""))
			var position := String(player.get("position", ""))
			if not number.is_empty():
				entry += " · #" + number
			if not position.is_empty():
				entry += " · " + position
			lines.append(entry)
	lines.append("Starting players are selected by the user before tip-off; roster order does not identify official starters.")
	if not bool(team.get("roster_complete", false)):
		lines.append("This roster is marked partial; missing players are not invented.")
	for source_url: String in _roster_catalog.team_sources(league_id, team_id):
		lines.append("Source: " + source_url)
	return "\n".join(lines)


func _show_game() -> void:
	_screen = "game"
	_touch_directions.clear()
	_touch_sprint = false
	_clear_body()
	_top_label.text = "Match in progress · %d on %d" % [_simulation.players_per_side, _simulation.players_per_side]
	var score_row := _new_card()
	score_row.custom_minimum_size.y = 52
	_body.add_child(score_row)
	var score_stack := HBoxContainer.new()
	score_stack.add_theme_constant_override("separation", 14)
	score_row.add_child(score_stack)
	_score_label = Label.new()
	_score_label.add_theme_font_size_override("font_size", 24)
	_score_label.add_theme_color_override("font_color", Color("#FFF7E8"))
	_score_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_score_label.accessibility_name = "Score"
	score_stack.add_child(_score_label)
	_clock_label = Label.new()
	_clock_label.add_theme_font_size_override("font_size", 23)
	_clock_label.add_theme_color_override("font_color", Color("#F47A38"))
	_clock_label.accessibility_name = "Period and match clock"
	score_stack.add_child(_clock_label)
	_shot_label = Label.new()
	_shot_label.add_theme_font_size_override("font_size", 21)
	_shot_label.add_theme_color_override("font_color", Color("#10BDB5"))
	_shot_label.accessibility_name = "Shot clock"
	score_stack.add_child(_shot_label)

	var progress_layout := VBoxContainer.new()
	progress_layout.add_theme_constant_override("separation", 4)
	_progress_label = Label.new()
	_progress_label.text = "Match progress"
	_progress_label.add_theme_font_size_override("font_size", 14)
	_progress_label.accessibility_name = "Match progress"
	_progress_label.accessibility_description = "Elapsed regulation match-clock progress across four quarters."
	progress_layout.add_child(_progress_label)
	_progress_bar = ProgressBar.new()
	_progress_bar.min_value = 0.0
	_progress_bar.max_value = 100.0
	_progress_bar.value = 0.0
	_progress_bar.show_percentage = false
	_progress_bar.custom_minimum_size.y = 16.0
	_progress_bar.accessibility_name = "Regulation game-clock progress"
	_progress_bar.accessibility_description = "Percentage of the selected total game clock completed."
	progress_layout.add_child(_progress_bar)
	_body.add_child(progress_layout)
	_court_view = CourtViewType.new()
	_court_view.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_court_view.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_court_view.custom_minimum_size = Vector2(600, 315)
	_court_view.set_simulation(_simulation)
	_court_view.set_reduced_motion(bool(_settings.reduced_motion))
	_body.add_child(_court_view)
	_event_label = Label.new()
	_event_label.text = _last_event_text if not _last_event_text.is_empty() else "Ball to %s. Use the D-pad or W/A/S/D to move." % _simulation.home_team
	_event_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_event_label.add_theme_font_size_override("font_size", 17)
	_event_label.add_theme_color_override("font_color", Color("#FFE4C4"))
	_event_label.accessibility_name = "Last play announcement"
	_event_label.accessibility_description = "The last basketball play. Press V or Read Status for a complete spoken court description."
	_body.add_child(_event_label)
	var controls := FlowContainer.new()
	controls.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	controls.add_theme_constant_override("h_separation", 7)
	controls.add_theme_constant_override("v_separation", 7)
	_body.add_child(controls)
	_add_sprint_button(controls)
	_add_direction_button(controls, "Up", Vector2.UP)
	_add_direction_button(controls, "Left", Vector2.LEFT)
	_add_direction_button(controls, "Down", Vector2.DOWN)
	_add_direction_button(controls, "Right", Vector2.RIGHT)
	_add_button(controls, "Pass · Space", "Pass to an open teammate. Windows shortcut: Space.", func() -> void: _simulation.pass_ball(Input.get_vector("move_left", "move_right", "move_up", "move_down")))
	_add_button(controls, "Shoot · Enter/J", "Shoot or take a free throw. Windows shortcut: Enter or J.", func() -> void: _simulation.shoot())
	_add_button(controls, "Defend/Steal · F", "Move toward the ball carrier, then attempt a steal. Windows shortcut: F.", func() -> void: _simulation.defend())
	_add_button(controls, "Switch · Tab", "Select the next home player. Windows shortcut: Tab.", func() -> void: _simulation.switch_player())
	_add_button(controls, "Read Status · V", "Speak possession, score, clock and the selected player. Windows shortcut: V.", _read_match_status)
	_add_button(controls, "Substitute · B", "Substitute the selected player. Windows shortcut: B.", func() -> void: _simulation.substitute())
	_add_button(controls, "Timeout · T", "Call a timeout. Windows shortcut: T.", func() -> void: _simulation.call_timeout())
	_add_button(controls, "Pause · Esc", "Pause the match. Windows shortcut: Escape.", _show_pause)
	_add_button(controls, "Help · Ctrl+H", "Review controls, accessibility options and platform guides. Windows shortcut: Ctrl+H.", _open_help)
	_footer.text = "W/A/S/D or arrows move · Space pass · Enter/J shoot · F defend · Tab switch · Shift sprint · V read status · Ctrl+H help"
	_update_game_hud()
	call_deferred("_focus_first_button")


func _add_direction_button(parent: Control, label_text: String, direction: Vector2) -> void:
	var button := _button(label_text, "Hold this touch button to move " + label_text.to_lower() + ".", Callable(), 92.0)
	button.button_down.connect(func() -> void: _touch_directions[button.get_instance_id()] = direction)
	button.button_up.connect(func() -> void: _touch_directions.erase(button.get_instance_id()))
	# Screen-reader activation is a single tap, so it holds the direction briefly (one step).
	button.set_meta("a11y_hold_seconds", 0.35)
	button.set_meta("a11y_hint", "Double tap to move %s one step." % label_text.to_lower())
	parent.add_child(button)


func _add_sprint_button(parent: Control) -> void:
	var button := _button("Sprint · Hold", "Hold to sprint while moving. Windows shortcut: Shift.", Callable(), 138.0)
	button.button_down.connect(func() -> void: _touch_sprint = true)
	button.button_up.connect(func() -> void: _touch_sprint = false)
	# Screen-reader activation sprints for a few seconds so a following direction tap benefits.
	button.set_meta("a11y_hold_seconds", 3.0)
	button.set_meta("a11y_hint", "Double tap to sprint for three seconds, then double tap a direction.")
	parent.add_child(button)


func _show_pause() -> void:
	if _simulation == null or _screen != "game":
		return
	_screen = "pause"
	_audio.set_paused(true)
	_clear_body()
	_top_label.text = "Match paused"
	var card := _new_card()
	_body.add_child(card)
	var stack := VBoxContainer.new()
	stack.add_theme_constant_override("separation", 10)
	card.add_child(stack)
	_add_heading(stack, "Pause", 26)
	_add_text(stack, _simulation.status_summary())
	_add_button(stack, "Resume Match", "Return to the saved court state.", _resume_game)
	_add_button(stack, "Save Match and Return to Menu", "Save the current score, time and player positions to continue later.", _save_and_exit_match)
	_add_button(stack, "Controls and Help · Ctrl+H", "Read every control and device guide.", _open_help)
	_add_button(stack, "Return to Main Menu", "Leave the current match without replacing the last saved match.", _show_home)
	_footer.text = "The game clock is stopped while paused."
	call_deferred("_focus_first_button")


func _resume_game() -> void:
	_screen = "game"
	_audio.set_paused(false)
	_audio.start_arena()
	_show_game()


func _save_and_exit_match() -> void:
	_save_match()
	_audio.set_paused(true)
	_show_home()
	_status_label = null


func _show_results() -> void:
	if _simulation == null:
		return
	_final_recorded = true
	_screen = "results"
	_audio.stop_arena()
	if _career_mode:
		_profile.games = int(_profile.games) + 1
		if _simulation.home_score > _simulation.away_score:
			_profile.wins = int(_profile.wins) + 1
		else:
			_profile.losses = int(_profile.losses) + 1
		_save_profile_and_settings()
	_clear_saved_match()
	_clear_body()
	_top_label.text = "Final score"
	var card := _new_card()
	_body.add_child(card)
	var stack := VBoxContainer.new()
	stack.add_theme_constant_override("separation", 10)
	card.add_child(stack)
	_add_heading(stack, "Game complete", 28)
	_add_heading(stack, _simulation.score_text(), 24)
	_add_text(stack, _simulation.status_summary())
	_add_text(stack, "Career record: %d wins, %d losses, %d games." % [int(_profile.wins), int(_profile.losses), int(_profile.games)])
	_add_button(stack, "Play Another Match", "Choose teams and begin another basketball game.", func() -> void: _show_setup(_career_mode))
	_add_button(stack, "Return to Main Menu", "Open the game menu.", _show_home)
	_footer.text = "The finished score is spoken by the sideline crew. Press Enter to choose the next action."
	call_deferred("_focus_first_button")


func _show_profile() -> void:
	_screen = "profile"
	_clear_body()
	_top_label.text = "Player profile"
	var card := _new_card()
	_body.add_child(card)
	var stack := VBoxContainer.new()
	stack.add_theme_constant_override("separation", 10)
	card.add_child(stack)
	_add_heading(stack, "Local career profile", 24)
	_add_text(stack, "Profile and career results stay on this device.")
	var input := LineEdit.new()
	input.text = String(_profile.name)
	input.placeholder_text = "Player name"
	input.custom_minimum_size.y = 64
	input.accessibility_name = "Player name"
	input.accessibility_description = "Enter the local player or career name."
	input.focus_mode = Control.FOCUS_ALL
	stack.add_child(input)
	_add_button(stack, "Save Player Profile", "Save this display name on this device.", func() -> void:
		var entered := input.text.strip_edges()
		if not entered.is_empty():
			_profile.name = entered.left(24)
		_save_profile_and_settings()
		_show_home()
	)
	_add_text(stack, "Record: %d wins, %d losses, %d games." % [int(_profile.wins), int(_profile.losses), int(_profile.games)])
	_add_button(stack, "Back", "Return to the main menu.", _show_home)
	_footer.text = "Profile data is stored locally; no account or network connection is required."
	call_deferred("_focus_first_button")


func _show_settings() -> void:
	if _screen != "settings":
		_settings_return_screen = _screen
	_screen = "settings"
	_clear_body()
	_top_label.text = "Accessibility, match length and sound options"
	_settings_controls.clear()
	var card := _new_card()
	_body.add_child(card)
	var stack := VBoxContainer.new()
	stack.add_theme_constant_override("separation", 9)
	card.add_child(stack)
	_add_heading(stack, "Match and sound settings", 24)
	_add_slider(stack, "Total match length", "Choose 2 to 12 minutes of regulation game clock across four quarters. Brief breaks and overtime are additional; changing this while a match is paused updates its current quarter clock.", float(_settings.get("match_duration_minutes", 12)), func(value: float) -> void:
		_settings.match_duration_minutes = roundi(value)
		if _simulation != null and not _simulation.game_over:
			_simulation.set_match_duration_minutes(value)
		_save_profile_and_settings()
	, 2.0, 12.0, 1.0, "minutes total · 4 quarters")
	var narration := CheckButton.new()
	narration.text = "Spoken game descriptions and status"
	narration.button_pressed = bool(_settings.get("narration", true))
	narration.accessibility_name = narration.text
	narration.accessibility_description = "Toggle system text-to-speech match status and court descriptions."
	narration.toggled.connect(func(value: bool) -> void:
		_settings.narration = value
		_audio.set_narration_enabled(value)
		_save_profile_and_settings()
	)
	stack.add_child(narration)
	_settings_controls.append(narration)
	var commentary := CheckButton.new()
	commentary.text = "Original sideline reporter and analyst clips"
	commentary.button_pressed = bool(_settings.get("commentary", true))
	commentary.accessibility_name = commentary.text
	commentary.accessibility_description = "Enable the female Sideline Reporter and three distinct humorous male analysts."
	commentary.toggled.connect(func(value: bool) -> void:
		_settings.commentary = value
		_audio.commentary_enabled = value
		_save_profile_and_settings()
	)
	stack.add_child(commentary)
	_settings_controls.append(commentary)
	var crowd := CheckButton.new()
	crowd.text = "Arena ambience and crowd reactions"
	crowd.button_pressed = bool(_settings.get("crowd", true))
	crowd.accessibility_name = crowd.text
	crowd.accessibility_description = "Enable crowd reactions to makes, misses and free throws."
	crowd.toggled.connect(func(value: bool) -> void:
		_settings.crowd = value
		_audio.set_crowd_enabled(value)
		_save_profile_and_settings()
	)
	stack.add_child(crowd)
	_settings_controls.append(crowd)
	var effects := CheckButton.new()
	effects.text = "Basketball, referee and game sound effects"
	effects.button_pressed = bool(_settings.get("effects", true))
	effects.accessibility_name = effects.text
	effects.accessibility_description = "Enable dribbling, ball, whistle, rim and scoring sound effects."
	effects.toggled.connect(func(value: bool) -> void:
		_settings.effects = value
		_audio.set_effects_enabled(value)
		_save_profile_and_settings()
	)
	stack.add_child(effects)
	_settings_controls.append(effects)
	var motion := CheckButton.new()
	motion.text = "Reduce court animation"
	motion.button_pressed = bool(_settings.get("reduced_motion", false))
	motion.accessibility_name = motion.text
	motion.toggled.connect(func(value: bool) -> void:
		_settings.reduced_motion = value
		_save_profile_and_settings()
		if _court_view != null:
			_court_view.set_reduced_motion(value)
	)
	stack.add_child(motion)
	_settings_controls.append(motion)
	_add_slider(stack, "Speech and status voice", "Volume of device text-to-speech used for court and score descriptions.", float(_settings.get("speech_volume", 0.82)), func(value: float) -> void:
		_settings.speech_volume = value
		_audio.set_narration_volume(value)
		_save_profile_and_settings()
	)
	_add_slider(stack, "Reporter and analyst clips", "Volume of original female reporter and three male analyst recordings.", float(_settings.get("commentary_volume", 0.88)), func(value: float) -> void:
		_settings.commentary_volume = value
		_audio.set_commentary_volume(value)
		_save_profile_and_settings()
	)
	_add_slider(stack, "Arena crowd volume", "Volume of the arena bed, cheers and free-throw pressure cues.", float(_settings.get("crowd_volume", 0.25)), func(value: float) -> void:
		_settings.crowd_volume = value
		_audio.set_crowd_volume(value)
		_save_profile_and_settings()
	)
	_add_slider(stack, "Basketball and referee effects", "Volume of ball, rim, whistle and scoring effects.", float(_settings.get("effects_volume", 0.82)), func(value: float) -> void:
		_settings.effects_volume = value
		_audio.set_effects_volume(value)
		_save_profile_and_settings()
	)
	_add_slider(stack, "Interface sounds", "Volume of menu, confirm and pause cues.", float(_settings.get("ui_volume", 0.80)), func(value: float) -> void:
		_settings.ui_volume = value
		_audio.set_ui_volume(value)
		_save_profile_and_settings()
	)
	_add_text(stack, "Match duration is the selected total regulation game-clock time, divided over four periods. All five audio channels can be adjusted independently and are saved on this device.")
	_add_text(stack, "Original synthetic commentary: Abby at courtside, Adam commentating, Michael and Andrei analysing plays, and Lisa and Jamie analysing halftime statistics. Dynamic score and clock updates use device text-to-speech when available.")
	_add_button(stack, "Done / Return", "Save options and return to the previous game, help or menu screen.", _close_settings)
	_footer.text = "Windows menus: Tab / Shift+Tab · Enter chooses · Ctrl+H opens help. Match status can be spoken with V."
	call_deferred("_focus_first_button")


func _close_settings() -> void:
	var previous := _settings_return_screen
	if previous == "game" or (previous == "help" and _help_return_screen == "game"):
		_resume_game()
	elif previous == "pause" or (previous == "help" and _help_return_screen == "pause"):
		_show_pause()
	else:
		_show_home()


func _add_slider(parent: VBoxContainer, title: String, description: String, value: float, changed: Callable, minimum: float = 0.0, maximum: float = 1.0, increment: float = 0.05, unit: String = "percent") -> void:
	var label := Label.new()
	label.text = title
	label.add_theme_font_size_override("font_size", 18)
	label.accessibility_name = title
	label.accessibility_description = description
	parent.add_child(label)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	var slider := HSlider.new()
	slider.min_value = minimum
	slider.max_value = maximum
	slider.step = increment
	slider.value = clampf(value, minimum, maximum)
	slider.custom_minimum_size = Vector2(260, 64)
	slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	slider.focus_mode = Control.FOCUS_ALL
	slider.accessibility_name = title
	slider.accessibility_description = description
	row.add_child(slider)
	var readout := Label.new()
	readout.custom_minimum_size.x = 150.0
	readout.text = _slider_readout(slider.value, unit)
	readout.accessibility_name = title + " current value"
	row.add_child(readout)
	slider.set_meta("a11y_value_label", readout)
	slider.value_changed.connect(func(next_value: float) -> void:
		readout.text = _slider_readout(next_value, unit)
		changed.call(next_value)
	)
	parent.add_child(row)
	_settings_controls.append(slider)


func _slider_readout(value: float, unit: String) -> String:
	if unit == "percent":
		return "%d%%" % roundi(value * 100.0)
	return "%d %s" % [roundi(value), unit]


func _show_about() -> void:
	_screen = "about"
	_clear_body()
	_top_label.text = "Startup guide, About and device controls"
	var card := _new_card()
	_body.add_child(card)
	var stack := VBoxContainer.new()
	stack.add_theme_constant_override("separation", 10)
	card.add_child(stack)
	_add_heading(stack, "Startup guide", 24)
	_add_text(stack, "1. Start Quick Exhibition or Career Match. 2. Pick 2-on-2, 3-on-3 or 5-on-5, choose teams and set a 2–12 minute match in Settings. 3. On the court, move your selected player, pass to a teammate and shoot. The computer controls the other players. Press V or Read Status for a full spoken update. Matches use four timed quarters; a tied score after the fourth period goes to overtime.")
	_add_heading(stack, "Windows play instructions", 21)
	_add_text(stack, "Move: W/A/S/D or arrow keys. Pass: Space. Shoot or take a free throw: Enter or J. Defend/steal: F. Switch selected player: Tab. Sprint: Shift. Substitute: B. Timeout: T. Read court, possession, score, clock and player: V. Pause: Escape. Open help/options: Ctrl+H. Main-menu controls use Tab/Shift+Tab and Enter.")
	_add_heading(stack, "Android play instructions", 21)
	_add_text(stack, "Use the labelled on-screen directional buttons to move; hold a direction to keep moving. Tap Pass, Shoot, Defend/Steal, Switch, Read Status, Substitute, Timeout, Pause or Help. Android opens in portrait mode with large buttons. Touch controls include accessible names and descriptions and follow a left-to-right, then top-to-bottom reading order wherever the device accessibility backend exposes it. Read Status provides a spoken fallback; Android TalkBack integration must still be verified on a real device. Haptic feedback is optional and can be disabled by device settings.")
	_add_heading(stack, "Credits and community", 21)
	_add_text(stack, "Created by " + CREATOR + ". Version " + APP_VERSION + ". Original synthetic crew: Abby courtside; Adam commenting; Michael and Andrei as male analysts; Lisa and Jamie analyse the halftime score, team fouls and leading scorers. No NBA 2K or identifiable person's voice is cloned. The NBA2K dataset README was research guidance only and its data is not bundled.")
	_add_button(stack, "Open Telegram Community", "Open the public Telegram page linked here.", func() -> void: OS.shell_open(TELEGRAM_URL))
	_add_text(stack, "Telegram page checked on 30 October 2026: t.me/gwapokobay1639 resolved publicly as ‘File for visually impaired official telegram channel’ and showed 1,312 subscribers. This verifies the public page exists, not who operates it.")
	_add_button(stack, "Back to Main Menu", "Return to the game menu.", _show_home)
	_footer.text = "You can reopen this guide at any time with Ctrl+H on Windows or the Help button on Android."
	call_deferred("_focus_first_button")


func _open_help() -> void:
	if _screen == "help":
		return
	_help_return_screen = _screen
	if _screen == "game":
		_audio.set_paused(true)
	_screen = "help"
	_clear_body()
	_top_label.text = "Controls and options help"
	var card := _new_card()
	_body.add_child(card)
	var stack := VBoxContainer.new()
	stack.add_theme_constant_override("separation", 10)
	card.add_child(stack)
	_add_heading(stack, "Windows keyboard shortcuts", 24)
	_add_text(stack, "Move: W/A/S/D or arrow keys. Pass: Space. Shoot: Enter/J. Defend or steal: F. Switch player: Tab. Sprint: Shift. Substitute: B. Timeout: T. Speak status: V. Pause: Escape. Reopen this help: Ctrl+H.")
	_add_heading(stack, "Android touch controls", 24)
	_add_text(stack, "Android opens in portrait mode. Use the large labelled on-screen direction buttons and play buttons. Settings control spoken narration, original voice clips, arena crowd reactions, sound effects and reduced motion. TalkBack reading order follows the controls from left to right, then top to bottom wherever Godot exposes the accessibility flow to the platform.")
	_add_button(stack, "Options / Settings", "Open narration, voice, crowd, effect and motion settings.", _show_settings)
	_add_button(stack, "Full Startup Guide and About", "Open separate Windows/Android instructions, credits and community details.", _show_about)
	_add_button(stack, "Close Help", "Return to the previous game screen.", _close_help)
	_footer.text = "Help remains available by Ctrl+H on Windows or the Help touch control."
	call_deferred("_focus_first_button")


func _close_help() -> void:
	var target := _help_return_screen
	if target == "game":
		_audio.set_paused(false)
		_audio.start_arena()
		_show_game()
	elif target == "settings":
		_show_settings()
	elif target == "about":
		_show_about()
	elif target == "pause":
		_show_pause()
	else:
		_show_home()


func _read_match_status() -> void:
	if _simulation == null:
		return
	var selected: Dictionary = _simulation.home_players[_simulation.selected_index]
	var point: Vector2 = selected.position
	var horizontal := "left side" if point.x < 335.0 else "right side" if point.x > 665.0 else "middle of the court"
	var vertical := "near sideline" if point.y < 155.0 else "near baseline" if point.y > 405.0 else "central lane"
	var carrier_name := String(_simulation._carrier().name)
	var carrier_text := "Ball with %s." % carrier_name if int(_simulation.possession_team) == 0 else "Opponent ball carrier: %s." % carrier_name
	_audio.read_status("%s. Selected player %s at the %s, %s. %s" % [_simulation.status_summary(), String(selected.name), horizontal, vertical, carrier_text])
	if _event_label != null:
		_event_label.text = "Spoken status: " + _simulation.score_text()


func _update_game_hud() -> void:
	if _simulation == null or _screen != "game":
		return
	_score_label.text = _simulation.score_text()
	_clock_label.text = "Q%d · %s" % [_simulation.quarter, _simulation.time_text()]
	_shot_label.text = "FT %d" % _simulation.free_throws_remaining if _simulation.free_throws_remaining > 0 else "SHOT %s" % _simulation.shot_clock_text()
	if _progress_bar != null:
		var progress_percent := roundi(_simulation.progress_fraction() * 100.0)
		_progress_bar.value = progress_percent
		_progress_bar.accessibility_description = "Regulation game-clock progress: %d percent of a %d minute total match." % [progress_percent, _simulation.match_duration_minutes]
		_progress_label.text = "Match progress · %d%% · %d minutes total" % [progress_percent, _simulation.match_duration_minutes]
	if _event_label != null and not _last_event_text.is_empty():
		_event_label.text = _last_event_text
	if _court_view != null:
		_court_view.queue_redraw()


func _on_match_event(kind: String, text: String) -> void:
	_last_event_text = text
	if _event_label != null:
		_event_label.text = text
	if _audio != null:
		_audio.handle_event(kind, text)
	if kind == "game_over":
		_final_recorded = false
	if kind in ["foul", "home_score", "away_score", "steal", "free_throw_make", "free_throw_miss"] and _audio != null:
		_audio.unlock()


func _continue_saved_match() -> void:
	if not FileAccess.file_exists(MATCH_PATH):
		_show_home()
		return
	var source := FileAccess.get_file_as_string(MATCH_PATH)
	var parsed: Variant = JSON.parse_string(source)
	if not parsed is Dictionary or not parsed.has("match"):
		_clear_saved_match()
		_show_home()
		return
	_simulation = MatchType.new()
	if not _simulation.restore(parsed.match):
		_clear_saved_match()
		_show_home()
		return
	_career_mode = bool(_simulation.career_mode)
	_final_recorded = false
	_simulation.event_occurred.connect(_on_match_event)
	_show_game()
	_audio.start_arena()
	_on_match_event("resume", "Saved match restored. " + _simulation.status_summary())


func _save_match() -> void:
	if _simulation == null:
		return
	var file := FileAccess.open(MATCH_PATH, FileAccess.WRITE)
	if file == null:
		return
	file.store_string(JSON.stringify({"match": _simulation.to_save_dict()}))
	file.close()
	_last_event_text = "Match saved. You can continue it from the main menu."


func _clear_saved_match() -> void:
	if FileAccess.file_exists(MATCH_PATH):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(MATCH_PATH))


func _load_profile_and_settings() -> void:
	var config := ConfigFile.new()
	if config.load(PROFILE_PATH) == OK:
		_profile = config.get_value("profile", "data", _profile)
		var saved_settings: Variant = config.get_value("settings", "data", {})
		if saved_settings is Dictionary:
			for key: Variant in saved_settings:
				_settings[key] = saved_settings[key]
	_audio.narration_enabled = bool(_settings.get("narration", true))
	_audio.commentary_enabled = bool(_settings.get("commentary", true))
	_audio.set_crowd_enabled(bool(_settings.get("crowd", true)))
	_audio.set_effects_enabled(bool(_settings.get("effects", true)))
	_audio.set_narration_volume(float(_settings.get("speech_volume", 0.82)))
	_audio.set_commentary_volume(float(_settings.get("commentary_volume", 0.88)))
	_audio.set_crowd_volume(float(_settings.get("crowd_volume", 0.25)))
	_audio.set_effects_volume(float(_settings.get("effects_volume", 0.82)))
	_audio.set_ui_volume(float(_settings.get("ui_volume", 0.80)))


func _save_profile_and_settings() -> void:
	var config := ConfigFile.new()
	config.set_value("profile", "data", _profile)
	config.set_value("settings", "data", _settings)
	config.save(PROFILE_PATH)


func _labeled_field(title: String, field: Control) -> Control:
	var row := VBoxContainer.new()
	row.add_theme_constant_override("separation", 3)
	var label := Label.new()
	label.text = title
	label.add_theme_font_size_override("font_size", 17)
	label.accessibility_name = title
	row.add_child(label)
	field.custom_minimum_size.y = 64
	field.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(field)
	return row


func _new_option(items: Array, control_name: String, description: String) -> OptionButton:
	var result := OptionButton.new()
	result.custom_minimum_size.y = 64.0
	for item: Variant in items:
		result.add_item(String(item))
	result.accessibility_name = control_name
	result.accessibility_description = description
	result.focus_mode = Control.FOCUS_ALL
	result.add_theme_font_size_override("font_size", 18)
	return result


func _clear_body() -> void:
	for child: Node in _body.get_children():
		child.queue_free()
	_status_label = null
	_court_view = null
	_score_label = null
	_clock_label = null
	_shot_label = null
	_progress_bar = null
	_progress_label = null
	_event_label = null
	_home_roster_button = null
	_away_roster_button = null
	_home_roster_panel = null
	_away_roster_panel = null
	_home_roster_label = null
	_away_roster_label = null
	_home_starter_status = null
	_away_starter_status = null
	_home_starter_list = null
	_away_starter_list = null
	_mode_option = null
	_home_league_option = null
	_away_league_option = null
	_home_team_option = null
	_away_team_option = null
	_setup_start_button = null
	_home_roster_expanded = false
	_away_roster_expanded = false


func _new_card() -> PanelContainer:
	var panel := PanelContainer.new()
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var style := StyleBoxFlat.new()
	style.bg_color = Color("#17263A")
	style.border_color = Color("#36506E")
	style.set_border_width_all(1)
	style.set_corner_radius_all(8)
	style.content_margin_left = 18.0
	style.content_margin_right = 18.0
	style.content_margin_top = 14.0
	style.content_margin_bottom = 14.0
	panel.add_theme_stylebox_override("panel", style)
	return panel


func _add_heading(parent: Control, text: String, size: int) -> Label:
	var label := Label.new()
	label.text = text
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label.add_theme_font_size_override("font_size", size)
	label.add_theme_color_override("font_color", Color("#FFF7E8"))
	label.accessibility_name = text
	parent.add_child(label)
	return label


func _add_text(parent: Control, text: String) -> Label:
	var label := Label.new()
	label.text = text
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label.add_theme_font_size_override("font_size", 17)
	label.add_theme_color_override("font_color", Color("#D7E3F0"))
	label.custom_minimum_size.y = 24
	label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	parent.add_child(label)
	return label


func _add_button(parent: Control, label: String, description: String, callback: Callable) -> Button:
	var button := _button(label, description, callback)
	parent.add_child(button)
	return button


func _button(label: String, description: String, callback: Callable, min_width: float = 230.0) -> Button:
	var button := Button.new()
	button.text = label
	button.custom_minimum_size = Vector2(min_width, 64.0)
	button.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	button.focus_mode = Control.FOCUS_ALL
	button.accessibility_name = label
	button.accessibility_description = description
	button.add_theme_font_size_override("font_size", 18)
	button.add_theme_color_override("font_color", Color("#FFFFFF"))
	button.add_theme_color_override("font_hover_color", Color("#101A2B"))
	button.add_theme_stylebox_override("normal", _button_style(Color("#23415C"), Color("#4F718E")))
	button.add_theme_stylebox_override("hover", _button_style(Color("#10BDB5"), Color("#E6F5F3")))
	button.add_theme_stylebox_override("pressed", _button_style(Color("#F47A38"), Color("#FFF2E8")))
	button.add_theme_stylebox_override("focus", _button_style(Color("#23415C"), Color("#F47A38")))
	button.pressed.connect(_audio.unlock)
	if callback.is_valid():
		button.pressed.connect(callback)
	return button


func _button_style(fill: Color, outline: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = fill
	style.border_color = outline
	style.set_border_width_all(2)
	style.set_corner_radius_all(6)
	style.content_margin_left = 12.0
	style.content_margin_right = 12.0
	style.content_margin_top = 8.0
	style.content_margin_bottom = 8.0
	return style


func _focus_first_button() -> void:
	_configure_accessibility_flow()
	if _screen == "game":
		return
	var buttons := find_children("*", "Button", false, false)
	for value: Node in buttons:
		var button := value as Button
		if button != null and button.is_visible_in_tree() and button.focus_mode != Control.FOCUS_NONE:
			button.grab_focus()
			return


func _configure_accessibility_flow() -> void:
	var controls: Array[Control] = []
	for node: Node in _body.find_children("*", "Control", true, false):
		var control := node as Control
		if control == null or not control.is_visible_in_tree():
			continue
		if control is Button or control is CheckButton or control is OptionButton or control is HSlider or control is LineEdit:
			controls.append(control)
	for index in range(controls.size()):
		var next_nodes: Array[NodePath] = []
		if index + 1 < controls.size():
			next_nodes.append(controls[index].get_path_to(controls[index + 1]))
		controls[index].accessibility_flow_to_nodes = next_nodes


func _load_match_from_dictionary(_data: Dictionary) -> void:
	# Reserved for a future import route; match resumes use the versioned local JSON snapshot.
	pass
