extends RefCounted
class_name LeagueRosterCatalog

var as_of_date: String = ""
var load_error: String = ""
var _leagues: Dictionary = {}


func load_file(path: String = "res://config/league_rosters.json") -> bool:
	load_error = ""
	var merged_data: Dictionary = {}
	var loaded_any := false
	for source_path: String in [path, "res://config/user_supplied_rosters.json", "res://config/researched_rosters.json"]:
		if not FileAccess.file_exists(source_path):
			continue
		var source: String = FileAccess.get_file_as_string(source_path)
		var parsed: Variant = JSON.parse_string(source)
		if not parsed is Dictionary:
			continue
		if not loaded_any:
			merged_data = (parsed as Dictionary).duplicate(true)
			loaded_any = true
		else:
			merged_data = _merge_supplement(merged_data, parsed as Dictionary)
	if not loaded_any:
		load_error = "No league roster data file is available."
		return false
	return configure(merged_data)


func _merge_supplement(primary: Dictionary, supplement: Dictionary) -> Dictionary:
	var result: Dictionary = primary.duplicate(true)
	var merged_leagues: Array = []
	var primary_value: Variant = primary.get("leagues", [])
	if primary_value is Array:
		merged_leagues = (primary_value as Array).duplicate(true)
	var supplement_value: Variant = supplement.get("leagues", [])
	if supplement_value is Array:
		for incoming_value: Variant in supplement_value:
			if not incoming_value is Dictionary:
				continue
			var incoming: Dictionary = incoming_value
			var incoming_id: String = String(incoming.get("id", "")).strip_edges().to_upper()
			var target_index := -1
			for league_index in range(merged_leagues.size()):
				var existing_value: Variant = merged_leagues[league_index]
				if existing_value is Dictionary and String(existing_value.get("id", "")).strip_edges().to_upper() == incoming_id:
					target_index = league_index
					break
			if target_index < 0:
				merged_leagues.append(incoming.duplicate(true))
				continue
			var existing_league: Dictionary = merged_leagues[target_index]
			var existing_teams: Array = existing_league.get("teams", [])
			var incoming_teams: Variant = incoming.get("teams", [])
			if incoming_teams is Array:
				for incoming_team_value: Variant in incoming_teams:
					if not incoming_team_value is Dictionary:
						continue
					var incoming_team: Dictionary = incoming_team_value
					var incoming_team_id: String = String(incoming_team.get("id", "")).strip_edges()
					var team_exists := false
					for existing_team_value: Variant in existing_teams:
						if existing_team_value is Dictionary and String(existing_team_value.get("id", "")).strip_edges() == incoming_team_id:
							team_exists = true
							break
					if not team_exists:
						existing_teams.append(incoming_team.duplicate(true))
				existing_league["teams"] = existing_teams
			if String(existing_league.get("status_note", "")).is_empty():
				existing_league["status_note"] = String(incoming.get("status_note", ""))
			merged_leagues[target_index] = existing_league
	result["leagues"] = merged_leagues
	if String(result.get("as_of_date", "")).is_empty():
		result["as_of_date"] = String(supplement.get("as_of_date", ""))
	return result


func configure(data: Dictionary) -> bool:
	_leagues.clear()
	as_of_date = String(data.get("as_of_date", "")).strip_edges()
	load_error = ""
	var raw_leagues: Variant = data.get("leagues", [])
	if not raw_leagues is Array:
		load_error = "Roster data has no leagues array."
		return false
	for raw_value: Variant in raw_leagues:
		if not raw_value is Dictionary:
			continue
		var raw_league: Dictionary = raw_value
		var league_id := String(raw_league.get("id", "")).strip_edges().to_upper()
		var league_name := String(raw_league.get("name", league_id)).strip_edges()
		if league_id.is_empty() or league_name.is_empty() or _leagues.has(league_id):
			continue
		var league_teams: Array[Dictionary] = []
		var team_ids: Dictionary = {}
		var raw_teams: Variant = raw_league.get("teams", [])
		if raw_teams is Array:
			for team_value: Variant in raw_teams:
				if not team_value is Dictionary:
					continue
				var raw_team: Dictionary = team_value
				var team_name := String(raw_team.get("name", "")).strip_edges()
				var team_id := String(raw_team.get("id", "")).strip_edges()
				if team_id.is_empty():
					team_id = _slug(team_name)
				if team_name.is_empty() or team_id.is_empty() or team_ids.has(team_id):
					continue
				var players: Array[Dictionary] = []
				var seen_names: Dictionary = {}
				var raw_players: Variant = raw_team.get("players", [])
				if raw_players is Array:
					for player_value: Variant in raw_players:
						if not player_value is Dictionary:
							continue
						var raw_player: Dictionary = player_value
						var player_name := String(raw_player.get("name", raw_player.get("player_name", ""))).strip_edges()
						if player_name.is_empty() or seen_names.has(player_name.to_lower()):
							continue
						seen_names[player_name.to_lower()] = true
						players.append({
							"id": String(raw_player.get("id", _slug(player_name))).strip_edges(),
							"name": player_name,
								"number": str(raw_player.get("number", "")).strip_edges(),
								"position": String(raw_player.get("position", "")).strip_edges(),
								"classification": String(raw_player.get("classification", "")).strip_edges(),
								"source_url": String(raw_player.get("source_url", "")).strip_edges()
						})
					team_ids[team_id] = true
					league_teams.append({
						"id": team_id,
						"name": team_name,
						"as_of_date": String(raw_team.get("as_of_date", as_of_date)).strip_edges(),
						"players": players,
						"roster_complete": bool(raw_team.get("roster_complete", false)),
						"status": String(raw_team.get("status", "verified")).strip_edges(),
						"sources": _string_array(raw_team.get("sources", []))
					})
			_leagues[league_id] = {
			"id": league_id,
			"name": league_name,
			"active": bool(raw_league.get("active", true)),
			"status_note": String(raw_league.get("status_note", "")).strip_edges(),
			"source_url": String(raw_league.get("source_url", "")).strip_edges(),
			"teams": league_teams
		}
	if _leagues.is_empty():
		load_error = "Roster data contains no valid league records."
		return false
	return true


func all_league_ids() -> Array[String]:
	var result: Array[String] = []
	for key: Variant in _leagues.keys():
		result.append(String(key))
	result.sort()
	return result


func active_league_ids() -> Array[String]:
	var result: Array[String] = []
	for league_id: String in all_league_ids():
		var league: Dictionary = _leagues[league_id]
		if bool(league.active) and not league.teams.is_empty():
			result.append(league_id)
	return result


func league_name(league_id: String) -> String:
	var league: Dictionary = _leagues.get(league_id, {})
	return String(league.get("name", league_id))


func league_is_active(league_id: String) -> bool:
	var league: Dictionary = _leagues.get(league_id, {})
	return bool(league.get("active", false)) and not league.get("teams", []).is_empty()


func status_note(league_id: String) -> String:
	var league: Dictionary = _leagues.get(league_id, {})
	return String(league.get("status_note", ""))


func inactive_summary() -> String:
	var lines: Array[String] = []
	for league_id: String in all_league_ids():
		if league_is_active(league_id):
			continue
		var league: Dictionary = _leagues[league_id]
		var note := String(league.get("status_note", "No current roster information is verified."))
		lines.append("%s — %s" % [String(league.name), note])
	return "\n".join(lines)


func teams_for_league(league_id: String) -> Array[Dictionary]:
	var league: Dictionary = _leagues.get(league_id, {})
	var result: Array[Dictionary] = []
	for team: Dictionary in league.get("teams", []):
		result.append(team.duplicate(true))
	return result


func team_by_id(league_id: String, team_id: String) -> Dictionary:
	var league: Dictionary = _leagues.get(league_id, {})
	for team: Dictionary in league.get("teams", []):
		if String(team.id) == team_id:
			return team.duplicate(true)
	return {}


func roster_for_team(league_id: String, team_id: String) -> Array[Dictionary]:
	var team: Dictionary = team_by_id(league_id, team_id)
	var result: Array[Dictionary] = []
	for player: Dictionary in team.get("players", []):
		result.append(player.duplicate(true))
	return result


func matchup_resolves(home_league_id: String, home_team_id: String, away_league_id: String, away_team_id: String) -> bool:
	return not team_by_id(home_league_id, home_team_id).is_empty() and not team_by_id(away_league_id, away_team_id).is_empty()


func team_sources(league_id: String, team_id: String) -> Array[String]:
	var team: Dictionary = team_by_id(league_id, team_id)
	var result: Array[String] = []
	for source: String in team.get("sources", []):
		if not source.is_empty():
			result.append(source)
	return result


func _string_array(value: Variant) -> Array[String]:
	var result: Array[String] = []
	if value is Array:
		for item: Variant in value:
			var entry: String = str(item).strip_edges()
			if not entry.is_empty() and not result.has(entry):
				result.append(entry)
	elif value is String and not str(value).strip_edges().is_empty():
		result.append(str(value).strip_edges())
	return result


func _slug(value: String) -> String:
	var result := value.to_lower().strip_edges()
	for character: String in [" ", "'", "’", ".", ",", "&", "/", "\\"]:
		result = result.replace(character, "-")
	while result.contains("--"):
		result = result.replace("--", "-")
	return result.trim_prefix("-").trim_suffix("-")
