extends Node
## Android TalkBack bridge.
##
## Godot draws every Control itself, so Android's screen reader (TalkBack) sees one
## unlabeled surface and cannot read or activate the game's buttons. This autoload
## mirrors the visible Controls as invisible native Android views (Button, CheckBox,
## SeekBar, TextView) laid over the game surface. TalkBack reads their content
## descriptions, swipes through them in screen order, and a double tap on one is sent
## back here and performed on the real Godot control.
##
## It only runs on Android and only while Android touch exploration (TalkBack or a
## compatible screen reader) is on. Everywhere else it does nothing.
## Requires Godot 4.4+ (JavaClassWrapper proxies and the AndroidRuntime singleton).
## Set ENABLED to false to switch the bridge off completely.

const ENABLED := true
const POLL_SECONDS := 0.25
const STATE_CHECK_SECONDS := 1.0
const MIN_VISIBLE_FRACTION := 0.25
const PARKED_STRIP_PX := 3.0
const DEFAULT_HOLD_SECONDS := 0.4
const LOG_PREFIX := "[a11y-bridge] "

var _supported := false
var _screen_reader_on := false
var _poll_timer := 0.0
var _state_timer := 0.0
var _runtime: Variant
var _activity: Variant
var _manager: Variant
var _ui: UiLayer
var _targets: Dictionary = {}
var _action_mutex := Mutex.new()
var _actions: Array[Dictionary] = []


# ---------------------------------------------------------------------------
# Lifecycle
# ---------------------------------------------------------------------------

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	if not ENABLED or OS.get_name() != "Android":
		set_process(false)
		return
	_supported = _setup_android()
	if not _supported:
		push_warning(LOG_PREFIX + "Android accessibility bridge unavailable; the game keeps its built-in spoken status.")
		set_process(false)
		return
	print(LOG_PREFIX + "ready")


func _process(delta: float) -> void:
	_state_timer += delta
	if _state_timer >= STATE_CHECK_SECONDS:
		_state_timer = 0.0
		_refresh_screen_reader_state()
	if not _screen_reader_on:
		return
	_drain_actions()
	_poll_timer += delta
	if _poll_timer < POLL_SECONDS:
		return
	_poll_timer = 0.0
	var snapshot := _build_snapshot()
	_targets.clear()
	for entry: Dictionary in snapshot:
		_targets[String(entry["id"])] = {"instance_id": int(entry["instance_id"]), "kind": String(entry["kind"])}
		entry.erase("instance_id")
	_post_ui(Callable(_ui, "apply").bind(snapshot))


func _exit_tree() -> void:
	if _supported and _ui != null and _screen_reader_on:
		_post_ui(Callable(_ui, "clear"))


## Public helper: speak text through the screen reader (no-op when it is off).
func announce(text: String) -> void:
	if _supported and _screen_reader_on and _ui != null and not text.is_empty():
		_post_ui(Callable(_ui, "announce").bind(text))


## True while the overlay is actively serving a screen reader.
func is_active() -> bool:
	return _supported and _screen_reader_on


# ---------------------------------------------------------------------------
# Android setup
# ---------------------------------------------------------------------------

func _setup_android() -> bool:
	if not Engine.has_singleton("AndroidRuntime"):
		return false
	if not JavaClassWrapper.has_method("create_proxy"):
		return false
	_runtime = Engine.get_singleton("AndroidRuntime")
	if _runtime == null:
		return false
	_activity = _runtime.getActivity()
	if _activity == null:
		return false
	_manager = _activity.getSystemService("accessibility")
	if _manager == null:
		return false
	var classes := {}
	for class_name_value: String in ["android.widget.FrameLayout", "android.widget.FrameLayout$LayoutParams", "android.widget.Button", "android.widget.CheckBox", "android.widget.SeekBar", "android.widget.TextView", "android.view.View", "android.os.Build$VERSION"]:
		var wrapped: Variant = JavaClassWrapper.wrap(class_name_value)
		if wrapped == null:
			push_warning(LOG_PREFIX + "could not wrap " + class_name_value)
			return false
		classes[class_name_value] = wrapped
	_ui = UiLayer.new()
	_ui.setup(self, _activity, classes)
	return true


func _refresh_screen_reader_state() -> void:
	var active := false
	if _manager != null:
		active = bool(_manager.isTouchExplorationEnabled())
	if active == _screen_reader_on:
		return
	_screen_reader_on = active
	_poll_timer = POLL_SECONDS
	print(LOG_PREFIX + ("screen reader detected" if active else "screen reader off"))
	if not active:
		_targets.clear()
		_post_ui(Callable(_ui, "clear"))


func _post_ui(callable: Callable) -> void:
	if _runtime == null or _activity == null:
		return
	_activity.runOnUiThread(_runtime.createRunnableFromGodotCallable(callable))


# ---------------------------------------------------------------------------
# Native -> Godot actions (queued from the Android UI thread)
# ---------------------------------------------------------------------------

func queue_action(entry_id: String, action: String, value: Variant) -> void:
	_action_mutex.lock()
	if _actions.size() < 64:
		_actions.append({"id": entry_id, "action": action, "value": value})
	_action_mutex.unlock()


func _drain_actions() -> void:
	_action_mutex.lock()
	var pending := _actions.duplicate()
	_actions.clear()
	_action_mutex.unlock()
	for item: Dictionary in pending:
		_perform(String(item["id"]), String(item["action"]), item["value"])


func _perform(entry_id: String, action: String, value: Variant) -> void:
	if not _targets.has(entry_id):
		return
	var target: Dictionary = _targets[entry_id]
	var control := instance_from_id(int(target["instance_id"])) as Control
	if control == null or not is_instance_valid(control) or control.is_queued_for_deletion():
		return
	_reveal(control)
	match action:
		"click":
			_activate(control)
		"progress":
			_set_slider_from_progress(control, int(value))


func _activate(control: Control) -> void:
	if control.has_meta("a11y_hold_seconds"):
		_hold_button(control as BaseButton, float(control.get_meta("a11y_hold_seconds", DEFAULT_HOLD_SECONDS)))
	elif control is OptionButton:
		_cycle_option(control as OptionButton)
	elif control is BaseButton:
		var button := control as BaseButton
		if button.disabled:
			return
		if button.toggle_mode:
			button.button_pressed = not button.button_pressed
		else:
			button.pressed.emit()
	elif control is LineEdit:
		var edit := control as LineEdit
		edit.grab_focus()
		if edit.has_method("edit"):
			edit.call("edit")
		if DisplayServer.has_feature(DisplayServer.FEATURE_VIRTUAL_KEYBOARD):
			DisplayServer.virtual_keyboard_show(edit.text, edit.get_global_rect(), DisplayServer.KEYBOARD_TYPE_DEFAULT, edit.max_length, edit.caret_column)
	elif control is TextEdit:
		control.grab_focus()


func _hold_button(button: BaseButton, seconds: float) -> void:
	if button == null or button.disabled:
		return
	button.button_down.emit()
	await get_tree().create_timer(maxf(seconds, 0.05), true).timeout
	if is_instance_valid(button):
		button.button_up.emit()


func _cycle_option(option: OptionButton) -> void:
	var count := option.item_count
	if count <= 0 or option.disabled:
		return
	var start := maxi(option.selected, 0)
	for step in range(1, count + 1):
		var index := (start + step) % count
		if option.is_item_disabled(index):
			continue
		option.select(index)
		option.item_selected.emit(index)
		announce(_option_text(option))
		return


func _set_slider_from_progress(control: Control, progress: int) -> void:
	var slider := control as Slider
	if slider == null or not slider.editable:
		return
	var step := slider.step if slider.step > 0.0 else 1.0
	slider.value = clampf(slider.min_value + float(progress) * step, slider.min_value, slider.max_value)


## Scrolls every ScrollContainer above the control so the control is on screen.
func _reveal(control: Control) -> void:
	var node: Node = control.get_parent()
	while node != null:
		if node is ScrollContainer:
			(node as ScrollContainer).ensure_control_visible(control)
		node = node.get_parent()


# ---------------------------------------------------------------------------
# Godot -> native snapshot (main thread only)
# ---------------------------------------------------------------------------

func _build_snapshot() -> Array:
	var window_size := Vector2(DisplayServer.window_get_size())
	var entries: Array[Dictionary] = []
	_collect(get_tree().root, entries, window_size)
	return order_entries(entries)


func _collect(node: Node, out: Array[Dictionary], window_size: Vector2) -> void:
	if node is Window and node != get_tree().root:
		return
	if node is CanvasItem and not (node as CanvasItem).visible:
		return
	if node.is_queued_for_deletion():
		return
	var control := node as Control
	if control != null:
		var entry := _describe(control, window_size)
		if not entry.is_empty():
			out.append(entry)
	for child: Node in node.get_children():
		_collect(child, out, window_size)


func _describe(control: Control, window_size: Vector2) -> Dictionary:
	var kind := ""
	var content := ""
	var checked := false
	var enabled := true
	var progress := 0
	var progress_max := 0
	var state_text := ""
	var name_text := clean_name(control.accessibility_name)
	var desc_text := clean_description(control.accessibility_description)
	var hint := String(control.get_meta("a11y_hint", ""))
	if not hint.is_empty():
		desc_text = hint

	if control is OptionButton:
		var option := control as OptionButton
		kind = "option"
		enabled = not option.disabled
		var label_name := name_text if not name_text.is_empty() else clean_name(option.text)
		content = "%s, %s. Double tap to choose the next option." % [label_name, _option_text(option)]
	elif control is CheckButton or control is CheckBox:
		var toggle := control as BaseButton
		kind = "toggle"
		checked = toggle.button_pressed
		enabled = not toggle.disabled
		var toggle_name := name_text if not name_text.is_empty() else clean_name((control as Button).text)
		content = toggle_name if desc_text.is_empty() else toggle_name + ". " + desc_text
	elif control is BaseButton:
		var button := control as BaseButton
		kind = "button"
		enabled = not button.disabled
		var button_name := name_text
		if button_name.is_empty() and control is Button:
			button_name = clean_name((control as Button).text)
		if button_name.is_empty():
			button_name = clean_name(button.tooltip_text)
		content = button_name if desc_text.is_empty() else button_name + ". " + desc_text
	elif control is Slider:
		var slider := control as Slider
		kind = "slider"
		enabled = slider.editable
		var step := slider.step if slider.step > 0.0 else 1.0
		progress_max = maxi(roundi((slider.max_value - slider.min_value) / step), 1)
		progress = clampi(roundi((slider.value - slider.min_value) / step), 0, progress_max)
		var slider_name := name_text if not name_text.is_empty() else "Slider"
		content = slider_name if desc_text.is_empty() else slider_name + ". " + desc_text
		var readout_value: Variant = control.get_meta("a11y_value_label", null)
		if readout_value != null and is_instance_valid(readout_value) and readout_value is Label:
			state_text = (readout_value as Label).text
		else:
			var span := slider.max_value - slider.min_value
			var percent := roundi((slider.value - slider.min_value) / span * 100.0) if span > 0.0 else 0
			state_text = "%d percent" % percent
	elif control is LineEdit:
		var edit := control as LineEdit
		kind = "edit"
		enabled = edit.editable
		var edit_name := name_text if not name_text.is_empty() else clean_name(edit.placeholder_text)
		var current := edit.text if not edit.text.is_empty() else "empty"
		content = "%s, edit box, %s. Double tap to edit." % [edit_name, current]
	elif control is TextEdit:
		var multi := control as TextEdit
		kind = "edit"
		content = "%s, edit box, %s. Double tap to edit." % [name_text, multi.text if not multi.text.is_empty() else "empty"]
	elif control is ProgressBar:
		var bar := control as ProgressBar
		kind = "text"
		var span_value := bar.max_value - bar.min_value
		var bar_percent := roundi((bar.value - bar.min_value) / span_value * 100.0) if span_value > 0.0 else 0
		content = "%s: %d percent" % [name_text if not name_text.is_empty() else "Progress", bar_percent]
	elif control is Label or control is RichTextLabel:
		var body := ""
		if control is Label:
			body = (control as Label).text.strip_edges()
		else:
			body = (control as RichTextLabel).get_parsed_text().strip_edges()
		if body.is_empty() and name_text.is_empty():
			return {}
		kind = "text"
		if body.is_empty():
			content = name_text
		elif name_text.is_empty() or name_text == body:
			content = body
		else:
			content = "%s: %s" % [name_text, body]
		if not desc_text.is_empty() and desc_text != body and desc_text != name_text:
			content += ". " + desc_text
	elif not (control is Container) and not name_text.is_empty():
		kind = "text"
		content = name_text if desc_text.is_empty() else name_text + ". " + desc_text
	else:
		return {}

	var canvas_rect := control.get_global_rect()
	if canvas_rect.size.x < 1.0 or canvas_rect.size.y < 1.0:
		return {}
	var visible_canvas := canvas_rect
	var clip_node: Node = control.get_parent()
	while clip_node != null:
		if clip_node is Control and (clip_node as Control).clip_contents:
			visible_canvas = visible_canvas.intersection((clip_node as Control).get_global_rect())
		clip_node = clip_node.get_parent()
	var to_screen := get_viewport().get_screen_transform() * control.get_canvas_transform()
	var full_rect: Rect2 = to_screen * canvas_rect
	var shown_rect: Rect2 = to_screen * visible_canvas if visible_canvas.has_area() else Rect2()
	shown_rect = shown_rect.intersection(Rect2(Vector2.ZERO, window_size))
	var fraction := 0.0
	if full_rect.has_area() and shown_rect.has_area():
		fraction = (shown_rect.size.x * shown_rect.size.y) / (full_rect.size.x * full_rect.size.y)
	var parked := fraction < MIN_VISIBLE_FRACTION
	var rect := shown_rect
	var sort_rect := shown_rect
	if parked:
		# Off-screen controls stay reachable by swiping: park a thin strip at the
		# screen edge nearest to them. Activating one scrolls it into view first.
		var above := full_rect.get_center().y < window_size.y * 0.5
		var strip_y := 0.0 if above else maxf(window_size.y - PARKED_STRIP_PX, 0.0)
		rect = Rect2(0.0, strip_y, maxf(window_size.x, 1.0), PARKED_STRIP_PX)
		sort_rect = Rect2(full_rect.position, full_rect.size)
	return {
		"id": "c%d" % control.get_instance_id(),
		"instance_id": control.get_instance_id(),
		"kind": kind,
		"content": content.strip_edges(),
		"rect": rect,
		"sort_rect": sort_rect,
		"checked": checked,
		"enabled": enabled,
		"progress": progress,
		"progress_max": progress_max,
		"state_text": state_text,
	}


static func _option_text(option: OptionButton) -> String:
	if option.selected < 0 or option.selected >= option.item_count:
		return "nothing selected"
	return option.get_item_text(option.selected)


## Reading order: top to bottom by row, left to right inside each row.
static func order_entries(entries: Array[Dictionary]) -> Array:
	var sorted_entries := entries.duplicate()
	sorted_entries.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
		var ra: Rect2 = a["sort_rect"]
		var rb: Rect2 = b["sort_rect"]
		return ra.position.y < rb.position.y
	)
	var rows: Array[Dictionary] = []
	for entry: Dictionary in sorted_entries:
		var placed := false
		if not rows.is_empty():
			var row: Dictionary = rows.back()
			if _same_row(row["reference"], entry["sort_rect"]):
				(row["items"] as Array).append(entry)
				placed = true
		if not placed:
			rows.append({"reference": entry["sort_rect"], "items": [entry]})
	var result: Array = []
	for row: Dictionary in rows:
		var items: Array = row["items"]
		items.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
			var ra: Rect2 = a["sort_rect"]
			var rb: Rect2 = b["sort_rect"]
			return ra.position.x < rb.position.x
		)
		result.append_array(items)
	return result


static func _same_row(a: Rect2, b: Rect2) -> bool:
	var overlap := minf(a.end.y, b.end.y) - maxf(a.position.y, b.position.y)
	return overlap >= 0.5 * minf(a.size.y, b.size.y)


## "Pass · Space" -> "Pass".
static func clean_name(raw: String) -> String:
	var text := raw.strip_edges()
	var cut := text.find(" · ")
	if cut > 0:
		text = text.substr(0, cut)
	return text.strip_edges()


## Drops sentences that only describe Windows keyboard shortcuts.
static func clean_description(raw: String) -> String:
	var kept: PackedStringArray = PackedStringArray()
	for part: String in raw.split(". "):
		var sentence := part.strip_edges().trim_suffix(".")
		if sentence.is_empty() or sentence.contains("Windows shortcut") or sentence.begins_with("Windows:"):
			continue
		kept.append(sentence)
	if kept.is_empty():
		return ""
	return ". ".join(kept) + "."


# ---------------------------------------------------------------------------
# Native view management (runs on the Android UI thread only)
# ---------------------------------------------------------------------------

class ClickProxy extends RefCounted:
	var bridge: Variant
	var entry_id := ""

	func onClick(_view: Variant) -> void:
		if bridge != null:
			bridge.queue_action(entry_id, "click", null)


class SeekProxy extends RefCounted:
	var bridge: Variant
	var entry_id := ""

	func onProgressChanged(_seek_bar: Variant, progress: int, from_user: bool) -> void:
		if from_user and bridge != null:
			bridge.queue_action(entry_id, "progress", progress)

	func onStartTrackingTouch(_seek_bar: Variant) -> void:
		pass

	func onStopTrackingTouch(_seek_bar: Variant) -> void:
		pass


class UiLayer extends RefCounted:
	const CONTENT_VIEW_ID := 16908290 # android.R.id.content
	const ALPHA := 0.01 # must stay above zero or Android treats the view as invisible

	var _bridge: Variant
	var _activity: Variant
	var _classes: Dictionary = {}
	var _container: Variant
	var _views: Dictionary = {}
	var _sdk_int := 0
	var _lp_name := ""
	var _last_order: PackedStringArray = PackedStringArray()

	func setup(bridge: Variant, activity: Variant, classes: Dictionary) -> void:
		_bridge = bridge
		_activity = activity
		_classes = classes
		var version: Variant = classes["android.os.Build$VERSION"]
		_sdk_int = int(version.SDK_INT)
		_lp_name = _constructor_name(classes["android.widget.FrameLayout$LayoutParams"], "android.widget.FrameLayout$LayoutParams")

	func apply(snapshot: Array) -> void:
		if not _ensure_container():
			return
		var seen: Dictionary = {}
		var order: PackedStringArray = PackedStringArray()
		for entry: Dictionary in snapshot:
			var entry_id := String(entry["id"])
			seen[entry_id] = true
			order.append(entry_id)
			var record: Dictionary = _views.get(entry_id, {})
			if record.is_empty() or String(record["kind"]) != String(entry["kind"]):
				if not record.is_empty():
					_remove_view(entry_id)
				record = _create_view(entry_id, entry)
				if record.is_empty():
					continue
				_views[entry_id] = record
			_update_view(record, entry)
		for stale_id: String in _views.keys():
			if not seen.has(stale_id):
				_remove_view(stale_id)
		if order != _last_order:
			_last_order = order
			_apply_traversal(order)

	func clear() -> void:
		for view_id: String in _views.keys():
			_remove_view(view_id)
		_views.clear()
		_last_order = PackedStringArray()
		if _container != null:
			var parent: Variant = _container.getParent()
			if parent != null:
				parent.removeView(_container)
			_container = null

	func announce(text: String) -> void:
		if _container != null:
			_container.announceForAccessibility(text)

	func _ensure_container() -> bool:
		if _container != null:
			return true
		var content: Variant = _activity.findViewById(CONTENT_VIEW_ID)
		if content == null:
			return false
		var frame: Variant = _construct("android.widget.FrameLayout", _activity)
		if frame == null:
			return false
		frame.setClickable(false)
		frame.setFocusable(false)
		content.addView(frame)
		_container = frame
		return true

	func _create_view(entry_id: String, entry: Dictionary) -> Dictionary:
		var kind := String(entry["kind"])
		var class_name_value := "android.widget.Button"
		match kind:
			"toggle":
				class_name_value = "android.widget.CheckBox"
			"slider":
				class_name_value = "android.widget.SeekBar"
			"text":
				class_name_value = "android.widget.TextView"
		var view: Variant = _construct(class_name_value, _activity)
		if view == null:
			return {}
		view.setAlpha(ALPHA)
		view.setImportantForAccessibility(1)
		_assign_view_id(view)
		var record := {"view": view, "kind": kind, "cache": {}, "view_id": int(view.getId()), "proxies": []}
		if kind == "button" or kind == "option" or kind == "edit" or kind == "toggle":
			var click := ClickProxy.new()
			click.bridge = _bridge
			click.entry_id = entry_id
			var click_proxy: Variant = JavaClassWrapper.create_proxy(click, ["android.view.View$OnClickListener"])
			view.setOnClickListener(click_proxy)
			(record["proxies"] as Array).append(click)
			(record["proxies"] as Array).append(click_proxy)
		elif kind == "slider":
			var seek := SeekProxy.new()
			seek.bridge = _bridge
			seek.entry_id = entry_id
			var seek_proxy: Variant = JavaClassWrapper.create_proxy(seek, ["android.widget.SeekBar$OnSeekBarChangeListener"])
			view.setOnSeekBarChangeListener(seek_proxy)
			(record["proxies"] as Array).append(seek)
			(record["proxies"] as Array).append(seek_proxy)
		_container.addView(view)
		return record

	func _assign_view_id(view: Variant) -> void:
		var view_class: Object = _classes["android.view.View"]
		view.setId(view_class.call("generateViewId"))

	func _update_view(record: Dictionary, entry: Dictionary) -> void:
		var view: Variant = record["view"]
		var cache: Dictionary = record["cache"]
		var rect: Rect2 = entry["rect"]
		var geometry := [roundi(rect.position.x), roundi(rect.position.y), maxi(roundi(rect.size.x), 1), maxi(roundi(rect.size.y), 1)]
		if cache.get("geometry", []) != geometry:
			cache["geometry"] = geometry
			var params: Variant = _layout_params(geometry[2], geometry[3])
			if params != null:
				view.setLayoutParams(params)
			view.setX(float(geometry[0]))
			view.setY(float(geometry[1]))
		var content := String(entry["content"])
		if cache.get("content", "") != content:
			cache["content"] = content
			view.setContentDescription(content)
		var enabled := bool(entry["enabled"])
		if cache.get("enabled", true) != enabled:
			cache["enabled"] = enabled
			view.setEnabled(enabled)
		match String(record["kind"]):
			"toggle":
				var checked := bool(entry["checked"])
				if cache.get("checked", null) != checked:
					cache["checked"] = checked
					view.setChecked(checked)
			"slider":
				var maximum := int(entry["progress_max"])
				if cache.get("max", -1) != maximum:
					cache["max"] = maximum
					view.setMax(maximum)
				var progress := int(entry["progress"])
				if cache.get("progress", -1) != progress:
					cache["progress"] = progress
					view.setProgress(progress)
				var state_text := String(entry["state_text"])
				if _sdk_int >= 30 and cache.get("state_text", "") != state_text:
					cache["state_text"] = state_text
					view.setStateDescription(state_text)

	func _apply_traversal(order: PackedStringArray) -> void:
		var previous_view_id := -1
		for entry_id: String in order:
			var record: Dictionary = _views.get(entry_id, {})
			if record.is_empty():
				continue
			(record["view"] as Variant).setAccessibilityTraversalAfter(previous_view_id)
			previous_view_id = int(record["view_id"])

	func _remove_view(entry_id: String) -> void:
		var record: Dictionary = _views.get(entry_id, {})
		if not record.is_empty() and _container != null:
			_container.removeView(record["view"])
		_views.erase(entry_id)

	func _layout_params(width: int, height: int) -> Variant:
		if _lp_name.is_empty():
			return null
		var params_class: Object = _classes["android.widget.FrameLayout$LayoutParams"]
		return params_class.call(_lp_name, width, height)

	func _construct(class_name_value: String, argument: Variant) -> Variant:
		var java_class: Object = _classes[class_name_value]
		var constructor := _constructor_name(java_class, class_name_value)
		if constructor.is_empty():
			return null
		return java_class.call(constructor, argument)

	static func _constructor_name(java_class: Object, full_name: String) -> String:
		var after_dot := full_name.get_slice(".", full_name.get_slice_count(".") - 1)
		var after_dollar := after_dot.get_slice("$", after_dot.get_slice_count("$") - 1)
		for candidate: String in [after_dollar, after_dot, "<init>", "new"]:
			if java_class.has_method("has_java_method") and bool(java_class.call("has_java_method", candidate)):
				return candidate
		# Older wrappers do not report constructors; the documented name is the simple class name.
		return after_dollar
