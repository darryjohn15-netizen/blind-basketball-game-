# Blind Basketball Game — Implementation Plan

## Product and gameplay

Port the supplied AndroLua basketball project into a lightweight Godot 4.7.2 game for Windows and Android. Keep the existing 1.0.1 lineage and creator credit, with the working project version set to 1.0.2. The playable game is offline and uses an authoritative GDScript match simulator for 2-on-2, 3-on-3 and 5-on-5 matches against AI. Preserve exhibition and career flows, player/team/profile selection, quarter and shot clocks, passing, shooting, defense, fouls, free throws, substitutions, timeouts and save/resume behavior where supported by the supplied project.

Allow a 2–12 minute total match duration, divided across four periods; do not add a separate 48-minute/quarter-count selector. Keep individual sound-volume settings and clear in-game match progress. A full match must remain playable without vision through spoken state, focusable controls and accessible touch input, not merely through a visually readable court.

## Current and historical roster data

The current roster catalog stores leagues, teams, player names, numbers, positions, source URLs, roster dates and status notes. Exhibition has independent home and opponent league/team selectors so mixed-league matches are possible. The pregame selector allows exactly 2, 3 or 5 user-chosen starters from each verified roster. Those selected players are placed on court; remaining sourced players are placed on the bench. Convenience defaults remain editable and are never described as official starters.

Keep historical Classics data in a separate catalog, not mixed into current active rosters. The user selected one representative lineup per decade. Add a representative championship-era starting five for each included franchise/team and decade where it has championship history, with the exact season, league/competition, status and source URLs. Select a season only when the evidence supports the lineup; call it “official” only if a reliable source establishes that status. If no adequately sourced five is available, mark the entry unavailable rather than inventing players. Treat FIBA Asia as national-team tournament history, not as a club league. Retain the dated 2025 Philippines FIBA Asia Cup roster as a separate national-team entry. Use the earlier requested leagues—NBA, PBA, MPBL and historical PBL—while clearly identifying inactive or unavailable competitions.

## Accessibility, readable controls and audio

Use Godot Control semantic names and descriptions, explicit accessibility flow links, visible text, keyboard focus, and focus-neighbor navigation. Accessibility flow must follow visible order: left-to-right across each row, then top-to-bottom to the next row. Menus remain a simple vertical reading path. Buttons must have high-contrast text, a large tap target (minimum 64 logical units tall before responsive scaling), visible action/shortcut labels and a real working callback. No essential action may be communicated by color or an icon alone. Keep text and action labels fully readable at small portrait phone widths; allow scrolling instead of clipping.

Lock the Android app to portrait at a 720×1280 logical base, using canvas-item scaling and expanded aspect behavior for varied phone/tablet ratios. The court drawing adapts to portrait by placing the two hoops at the top and bottom, without rotating live text or controls. Windows retains a standard landscape startup window but its UI adapts to tall/resized windows. Menu, roster and match buttons stay ordered consistently for screen-reader swipe traversal and keyboard users. The controls read visibly in the same row-major order; explicit `Control.accessibility_flow_to_nodes` links reinforce this order where the OS accessibility backend supports them.

Godot's official AccessKit-based screen-reader integration is experimental, and the reviewed API documentation does not establish Android TalkBack support for this 4.7.2 build. Use the engine's screen-reader metadata where available, preserve spoken status through `DisplayServer.tts_speak` and the app's audio narration, and verify Windows Narrator/NVDA and TalkBack on real devices before claiming those specific combinations or all-screen-reader compatibility. Include a clear fallback when the native accessibility backend is unavailable; do not misrepresent a game-generated voice as native TalkBack output.

Windows has keyboard controls, Ctrl+H help and V for spoken status. Android uses visible, clearly named touch buttons with large targets, TalkBack metadata where exposed by Godot, and vibration when available. Announce possession, selected player, score, match/shot clocks, fouls, substitutions and outcomes without requiring vision. Retain and correctly mix the supplied game effects where practical. Use original synthesized voices only: one female courtside reporter and three distinct humorous male analysts; never clone NBA 2K talent or another identifiable person. Queue event-led commentary, prioritize critical accessibility speech, route separate home/opponent crowd reactions for makes, misses and free-throw pressure, and expose independent sound levels in Settings.

## User interface and flow

Start at a clear main menu with Exhibition, Career, Settings, About and Help. Keep Settings immediately before About. Pregame setup contains match size, independent league/team selectors and two expandable, keyboard- and touch-accessible roster panels. Each panel reports sourced roster status and selected starter count. The live match screen has clear pause, player selection, pass, shoot, defend, substitution, timeout and spoken-status controls. Match results support replay and return to menu. About preserves “Created by Darry John Sarmiento,” the user's Telegram link after checking its availability, and distinct Windows and Android startup/control instructions. Every visible button, selector and slider has an explicit purpose, an accurate accessible name/description and a tested action or value change.

## Architecture and project structure

- `scripts/basketball_app.gd`: menus, setup, settings, About/help, accessible input, responsive layouts, explicit button traversal and callback wiring, roster and starter UI, match routing.
- `scripts/game/basketball_match.gd`: authoritative clocks, possessions, score, AI, fouls, substitutions, save/restore and player/bench state.
- `scripts/game/court_view.gd`: top-down court and entities; portrait/landscape mapping that keeps text/control orientation readable.
- `scripts/data/league_roster_catalog.gd`: validation and lookup for current leagues, teams and players.
- `scripts/data/classic_roster_catalog.gd` and `config/classic_rosters.json`: separate historical team/decade/season entries with player-level evidence.
- `scripts/audio/game_audio.gd`: original narration/commentary, spoken status fallback, crowd routing, sound prioritization and saved mixes.
- `config/league_rosters.json` and `config/user_supplied_rosters.json`: current/source-supplied roster records.
- `tests/basketball_checks.gd`: bounded checks for core match flow, accessible focus/swipe order, visible button sizing/labels/callbacks, portrait behavior, cross-league selection, chosen starters/bench ordering, saves and audio routing.
- `docs/`: accessibility evidence, separate player instructions and source/build notes for Windows and Android.

Avoid new online services and unnecessary runtime dependencies. Keep source/build tools and research files out of the playable export. The same game source feeds the Windows and Android builds, with separate platform source archives and build notes.

## Visual direction

Design movement: a high-contrast sports broadcast console over a clearly marked, top-down court. Core principles: audio leads; focus is unmistakable; controls use plain verbs; motion stays restrained. Color philosophy: deep navy supports warm amber and teal team accents with bright white lines/text; selection uses a double white/amber ring and not color alone. Layout paradigm: portrait-first on Android with a vertical screen hierarchy, compact court in the upper match area and action controls below; containers wrap controls left-to-right and then downward; Windows expands the same reading path in its landscape window. Signature elements: court-line geometry, a two-tone selected-player ring and the amber ball. Interaction philosophy: every control states its action and shortcut visibly, has a semantic name/description, a clear focus state and a functional action; touch targets are large and repeatable. Animation: subtle ball movement only, no flashing; reduced-motion removes pulsing. Typography: use the bundled template font chain; use 28+ logical units for titles and at least 18 for control text, with wrapping instead of clipping. Keep score, clocks and button wording as live text.

Brand essence: accessible basketball for blind and low-vision players, with a navigable sound-led court. Personality: energetic, direct and welcoming. Brand voice: short, practical play calls; examples: “Pass is ready. Choose a teammate.” and “Clock is running. Read status any time.” Wordmark/logo: the full “Blind Basketball Game” name with a court-line and ball mark. Signature brand color: vivid amber against deep navy.

## Platform release constraints

Use Godot's official export workflow where the installed toolchain supports it. Deliver a single Android APK and a straightforward Windows release/installable set, plus separate Windows and Android source archives with instructions. Measure each output and aim for under 90 MB; disclose actual sizes and any missing exporter, signing or SDK requirement. Do not download additional native export toolchains without the user's explicit approval. Verify exported builds rather than claiming success from source checks alone.
