extends SceneTree

const MatchType = preload("res://scripts/game/basketball_match.gd")
const RosterType = preload("res://scripts/data/league_roster_catalog.gd")

var _failures: Array[String] = []
var _checks := 0


func _initialize() -> void:
	call_deferred("_run")


func _run() -> void:
	for mode: int in [2, 3, 5]:
		var game_state = MatchType.new()
		game_state.start(mode, "Home Test", "Away Test", false, 2)
		_check(game_state.home_players.size() == mode, "%d-on-%d home lineup" % [mode, mode])
		_check(game_state.away_players.size() == mode, "%d-on-%d away lineup" % [mode, mode])
		_check(is_equal_approx(game_state.game_seconds, 30.0), "%d-on-%d period clock for two-minute game" % [mode, mode])
		game_state.tick(1.0)
		_check(is_equal_approx(game_state.game_seconds, 29.0), "%d-on-%d game clock advances" % [mode, mode])
		_check(is_equal_approx(game_state.progress_fraction(), 1.0 / 120.0), "%d-on-%d total match progress advances" % [mode, mode])
		_check(game_state.home_players.all(func(player: Dictionary) -> bool: return int(player.get("points", -1)) == 0), "%d-on-%d player scoring starts at zero" % [mode, mode])
		var saved: Dictionary = game_state.to_save_dict()
		var resumed = MatchType.new()
		_check(resumed.restore(saved), "%d-on-%d saved match restores" % [mode, mode])
		_check(resumed.home_score == game_state.home_score and is_equal_approx(resumed.game_seconds, game_state.game_seconds), "%d-on-%d score and clock survive resume" % [mode, mode])

	var bridge_script: Script = load("res://autoload/android_accessibility_bridge.gd")
	_check(bridge_script != null, "Android TalkBack bridge script loads")
	if bridge_script != null:
		_check(String(bridge_script.call("clean_name", "Pass · Space")) == "Pass", "bridge speaks button names without keyboard shortcut suffixes")
		_check(String(bridge_script.call("clean_name", "Resume Match")) == "Resume Match", "bridge keeps plain button names unchanged")
		_check(String(bridge_script.call("clean_description", "Pass to an open teammate. Windows shortcut: Space.")) == "Pass to an open teammate.", "bridge drops Windows-only shortcut sentences")
		var left_entry := {"id": "c1", "sort_rect": Rect2(10.0, 100.0, 80.0, 60.0)}
		var right_entry := {"id": "c2", "sort_rect": Rect2(120.0, 104.0, 80.0, 60.0)}
		var lower_entry := {"id": "c3", "sort_rect": Rect2(10.0, 200.0, 80.0, 60.0)}
		var ordered_entries: Array = bridge_script.call("order_entries", [lower_entry, right_entry, left_entry])
		var ordered_ids: Array = []
		for ordered_entry: Dictionary in ordered_entries:
			ordered_ids.append(String(ordered_entry["id"]))
		_check(ordered_ids == ["c1", "c2", "c3"], "bridge orders controls left-to-right within a row, then top-to-bottom")

	var adjustable = MatchType.new()
	adjustable.start(5, "Home Test", "Away Test", false, 12)
	adjustable.tick(5.0)
	adjustable.set_match_duration_minutes(6)
	_check(adjustable.match_duration_minutes == 6, "match duration changes to six minutes")
	_check(is_equal_approx(adjustable.game_seconds, 85.0), "live duration change preserves elapsed time in the current quarter")
	_check(is_equal_approx(adjustable.progress_fraction(), 5.0 / 360.0), "live progress reflects selected total match duration")
	_check(not adjustable.restore({}), "empty save data is rejected safely")
	var halftime = MatchType.new()
	halftime.start(5, "Home Test", "Away Test", false, 12)
	halftime._add_player_points(0, str(halftime.home_players[0].get("name", "")), 7)
	halftime._add_player_points(1, str(halftime.away_players[0].get("name", "")), 4)
	halftime.fouls_home = 2
	halftime.fouls_away = 3
	var halftime_report: String = halftime.halftime_statistics()
	_check(halftime_report.contains(str(halftime.home_players[0].get("name", "")) + " with 7 points"), "halftime report identifies the real leading scorer")
	_check(halftime_report.contains("Team fouls: Home Test 2, Away Test 3"), "halftime report includes current team foul totals")
	var halftime_resume = MatchType.new()
	_check(halftime_resume.restore(halftime.to_save_dict()), "halftime match restores")
	_check(int(halftime_resume.home_players[0].get("points", -1)) == 7, "player points survive match save and resume")
	var audited_rosters = RosterType.new()
	_check(audited_rosters.load_file(), "user-supplied and retained research roster files load together")
	var dallas_roster: Array[Dictionary] = audited_rosters.roster_for_team("NBA", "nba-dallas-mavericks")
	_check(dallas_roster.size() == 18 and audited_rosters.team_by_id("NBA", "nba-dallas-mavericks").roster_complete, "audited Dallas Mavericks roster includes 18 as-of players and completeness status")
	_check(dallas_roster.back().name == "Walter Clayton Jr." and dallas_roster.back().classification == "two-way", "officially announced late two-way signing retains its source-backed classification")
	var ginebra: Dictionary = audited_rosters.team_by_id("PBA", "pba-barangay-ginebra-san-miguel")
	_check(not ginebra.is_empty() and not bool(ginebra.roster_complete) and ginebra.sources.size() >= 3, "Ginebra audit carries source links and an explicit incomplete-roster caveat")
	_check(int(ProjectSettings.get_setting("display/window/handheld/orientation", 0)) == 1, "Android handheld orientation is portrait")
	var project_config_text := FileAccess.get_file_as_string("res://project.godot")
	_check(project_config_text.contains("window/size/viewport_width.android=720") and project_config_text.contains("window/size/viewport_height.android=1280"), "Android viewport has feature-specific 720 by 1280 portrait overrides")
	var roster_fixture: Dictionary = _make_roster_fixture()

	var packed_scene := load("res://scenes/main.tscn") as PackedScene
	_check(packed_scene != null, "basketball main scene loads")
	if packed_scene != null:
		var app := packed_scene.instantiate() as Control
		_check(app != null, "basketball app scene instantiates")
		if app != null:
			root.add_child(app)
			await process_frame
			await process_frame
			_check(String(app.get("_screen")) == "home", "game starts on the Blind Basketball Game menu")
			var home_buttons: Array[Node] = app.find_children("*", "Button", true, false)
			_check(not home_buttons.is_empty() and (home_buttons[0] as Button).custom_minimum_size.y >= 64.0, "menu buttons meet the large touch-target size")
			var first_flow: Array[NodePath] = (home_buttons[0] as Control).accessibility_flow_to_nodes
			_check(not first_flow.is_empty(), "first menu button provides an explicit screen-reader flow target")
			if not first_flow.is_empty():
				var next_control := (home_buttons[0] as Control).get_node_or_null(first_flow[0]) as Control
				var first_rect := (home_buttons[0] as Control).get_global_rect()
				var next_rect := next_control.get_global_rect() if next_control != null else Rect2()
				var row_major := next_rect.position.y > first_rect.position.y or (is_equal_approx(next_rect.position.y, first_rect.position.y) and next_rect.position.x >= first_rect.position.x)
				_check(next_control != null and row_major, "screen-reader traversal proceeds left-to-right, then top-to-bottom")
			app.call("_show_settings")
			_check(String(app.get("_screen")) == "settings", "dedicated settings screen opens")
			app.call("_show_home")
			var help_key := InputEventKey.new()
			help_key.keycode = KEY_H
			help_key.ctrl_pressed = true
			help_key.pressed = true
			app.call("_unhandled_key_input", help_key)
			_check(String(app.get("_screen")) == "help", "Windows Ctrl+H opens help")
			app.call("_close_help")
			_check(bool(app.call("_configure_roster_data", roster_fixture)), "active test-league roster data loads")
			app.call("_show_setup", false)
			var setup_options: Array[Node] = app.find_children("*", "OptionButton", true, false)
			var selectors_are_large := not setup_options.is_empty()
			for setup_option: Node in setup_options:
				selectors_are_large = selectors_are_large and (setup_option as OptionButton).custom_minimum_size.y >= 64.0
			_check(selectors_are_large, "setup league/team selectors meet the large portrait touch target")
			_check((app.get("_home_roster_button") as Button).custom_minimum_size.y >= 64.0, "roster expansion control meets the large touch target")
			var home_league_option: OptionButton = app.get("_home_league_option")
			var away_league_option: OptionButton = app.get("_away_league_option")
			var nba_index: int = int(app.call("_option_index_for_id", home_league_option, "NBA"))
			home_league_option.select(nba_index)
			app.call("_on_home_league_selected", nba_index)
			var pba_index: int = int(app.call("_option_index_for_id", away_league_option, "PBA"))
			away_league_option.select(pba_index)
			app.call("_on_away_league_selected", pba_index)
			var home_roster_summary: String = String(app.call("_format_roster", "NBA", "nba-test"))
			_check(home_roster_summary.contains("NBA Test Player 1") and home_roster_summary.contains("#3") and home_roster_summary.contains("Point guard"), "expanded roster text includes verified name, number, position and sources")
			app.call("_toggle_roster_panel", "home")
			var home_roster_panel: ScrollContainer = app.get("_home_roster_panel")
			_check(home_roster_panel.visible, "home team roster expands accessibly")
			var starter_checks := home_roster_panel.find_children("*", "CheckButton", true, false)
			_check(not starter_checks.is_empty() and (starter_checks[0] as CheckButton).custom_minimum_size.y >= 64.0 and not (starter_checks[0] as CheckButton).accessibility_name.is_empty(), "starter choices have large targets and readable screen-reader labels")
			var first_starter := starter_checks[0] as CheckButton
			var sixth_starter := starter_checks[5] as CheckButton
			first_starter.button_pressed = false
			_check(app.get("_selected_home_starters").size() == 4 and (app.get("_setup_start_button") as Button).disabled, "removing a starter disables tip-off until a replacement is chosen")
			sixth_starter.button_pressed = true
			_check(app.get("_selected_home_starters").size() == 5 and not (app.get("_setup_start_button") as Button).disabled, "selecting a replacement restores a complete five-player lineup")
			var audio_manager: Node = app.get("_audio")
			audio_manager.call("set_narration_enabled", false)
			audio_manager.set("commentary_enabled", false)
			var crowd_reaction: AudioStreamPlayer = audio_manager.get("_crowd_reaction_player")
			audio_manager.call("handle_event", "home_score", "Home basket.")
			_check(crowd_reaction.stream.resource_path.ends_with("crowd_cheer_home.mp3"), "home score triggers the home-crowd reaction")
			audio_manager.call("handle_event", "foul", "Shooting foul.")
			_check(crowd_reaction.stream.resource_path.ends_with("crowd_cheer_home.mp3"), "ordinary foul does not trigger free-throw booing")
			audio_manager.call("handle_event", "away_score", "Opponent basket.")
			_check(crowd_reaction.stream.resource_path.ends_with("crowd_room.mp3"), "opponent score triggers its separate crowd reaction")
			audio_manager.call("handle_event", "free_throw_start", "Free-throw pressure rises.")
			_check(crowd_reaction.stream.resource_path.ends_with("crowd_free_throw_boo.mp3"), "free-throw start triggers the boo cue")
			audio_manager.call("handle_event", "home_free_throw_make", "Home free throw made.")
			_check(crowd_reaction.stream.resource_path.ends_with("crowd_cheer_home.mp3"), "home free throw make triggers the home crowd")
			audio_manager.call("handle_event", "away_free_throw_make", "Away free throw made.")
			_check(crowd_reaction.stream.resource_path.ends_with("crowd_room.mp3"), "away free throw make triggers the opponent crowd")
			app.call("_begin_match")
			await process_frame
			_check(String(app.get("_screen")) == "game", "quick exhibition starts a live match")
			var live_match: Variant = app.get("_simulation")
			_check(live_match != null and live_match.home_players.size() == 5 and live_match.away_players.size() == 5, "live match starts with both full lineups")
			_check(live_match.home_team == "NBA · NBA Test Club" and live_match.away_team == "PBA · PBA Test Club", "Exhibition accepts independent NBA and PBA opponent leagues")
			_check(live_match.home_players[0].name == "NBA Test Player 2" and live_match.home_players[4].name == "NBA Test Player 6" and live_match.away_players[0].name == "PBA Test Player 1", "user-selected starters from independent league rosters are active at tip-off")
			_check(live_match.home_bench.size() == 2 and live_match.home_bench[0].name == "NBA Test Player 1", "non-selected roster players begin on the playable bench")
			live_match.substitute()
			_check(live_match.home_players[0].name == "NBA Test Player 1", "substitution checks in the selected-team reserve")
			var roster_save: Dictionary = live_match.to_save_dict()
			var roster_resume = MatchType.new()
			_check(roster_resume.restore(roster_save), "cross-league match with rosters resumes")
			_check(roster_resume.home_players[0].name == "NBA Test Player 1" and roster_resume.home_players[0].jersey_number == "1" and roster_resume.home_bench.back().name == "NBA Test Player 2", "selected starters, player numbers and rotated bench survive resume")
			app.call("_show_pause")
			_check(String(app.get("_screen")) == "pause", "live match can be paused")
			app.call("_resume_game")
			_check(String(app.get("_screen")) == "game", "paused match resumes")
			app.call("_show_home")
			app.queue_free()
			await process_frame

	if _failures.is_empty():
		print("[blind-basketball-tests] PASS: %d checks" % _checks)
		quit(0)
		return
	for failure: String in _failures:
		push_error("[blind-basketball-tests] " + failure)
	print("[blind-basketball-tests] FAIL: %d failures across %d checks" % [_failures.size(), _checks])
	quit(1)


func _check(condition: bool, context: String) -> void:
	_checks += 1
	if not condition:
		_failures.append(context)


func _make_roster_fixture() -> Dictionary:
	var nba_players: Array[Dictionary] = []
	var pba_players: Array[Dictionary] = []
	for index in range(7):
		var position := "Point guard" if index == 0 else "Guard" if index == 1 else "Forward" if index < 5 else "Reserve"
		nba_players.append({"name": "NBA Test Player %d" % (index + 1), "number": index + 1, "position": position, "source_url": "https://example.invalid/nba-test"})
		pba_players.append({"name": "PBA Test Player %d" % (index + 1), "number": index + 1, "position": position, "source_url": "https://example.invalid/pba-test"})
	return {
		"as_of_date": "2026-10-25",
		"leagues": [
			{"id": "NBA", "name": "NBA", "active": true, "teams": [{"id": "nba-test", "name": "NBA Test Club", "roster_complete": true, "players": nba_players, "sources": ["https://example.invalid/nba-test"]}]},
			{"id": "PBA", "name": "PBA", "active": true, "teams": [{"id": "pba-test", "name": "PBA Test Club", "roster_complete": true, "players": pba_players, "sources": ["https://example.invalid/pba-test"]}]},
			{"id": "PBL", "name": "PBL", "active": false, "status_note": "No active roster in this test fixture.", "teams": []}
		]
	}
